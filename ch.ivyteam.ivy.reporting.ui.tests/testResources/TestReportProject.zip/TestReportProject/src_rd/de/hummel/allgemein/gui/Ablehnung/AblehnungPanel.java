package de.hummel.allgemein.gui.Ablehnung;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RComboBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextArea;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;

/**
 * <p>PepGenehmigungPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class AblehnungPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel ablehnungLabel = null;
private RLabel grundLabel = null;
private RComboBox grundComboBox = null;
private RLabel sonstigesLabel = null;
private RTextArea bemerkungTextArea = null;
private RLabel referenzLabel = null;
private RTextField referenzTextField = null;
private RScrollPane anlehnungsgrundSonstigesScrollPane = null;
private RFlowLayoutPane buttonFlowLayoutPane = null;
private RButton abbrechenButton = null;
private RButton okButton = null;
/**
   * Create a new instance of PepGenehmigungPanel
   */
  public AblehnungPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepGenehmigungPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(449,166));
        this.add(getAblehnungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGrundLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGrundComboBox(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSonstigesLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getReferenzLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getReferenzTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAnlehnungsgrundSonstigesScrollPane(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getButtonFlowLayoutPane(), new com.ulcjava.base.application.GridBagConstraints(1, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes ablehnungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAblehnungLabel() {
	if (ablehnungLabel == null) {
		ablehnungLabel = new RLabel();
		ablehnungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/ablehnung\") %>");
		ablehnungLabel.setStyle("ueberschrift");
		ablehnungLabel.setName("ablehnungLabel");
	}
	return ablehnungLabel;
}

/**
 * This method initializes grundLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getGrundLabel() {
	if (grundLabel == null) {
		grundLabel = new RLabel();
		grundLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/ablehnungsGrund\") %>");
		grundLabel.setName("grundLabel");
	}
	return grundLabel;
}

/**
 * This method initializes grundComboBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RComboBox	
 */
private RComboBox getGrundComboBox() {
	if (grundComboBox == null) {
		grundComboBox = new RComboBox();
		grundComboBox.setName("grundComboBox");
		grundComboBox.setModelConfiguration("{/result \"result=entry\"/version \"3.0\"/icon \"\"/tooltip \"\"}");
	}
	return grundComboBox;
}

/**
 * This method initializes sonstigesLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getSonstigesLabel() {
	if (sonstigesLabel == null) {
		sonstigesLabel = new RLabel();
		sonstigesLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/bemerkungSonst\") %>");
		sonstigesLabel.setName("sonstigesLabel");
	}
	return sonstigesLabel;
}

/**
 * This method initializes bemerkungTextArea	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextArea	
 */
private RTextArea getBemerkungTextArea() {
	if (bemerkungTextArea == null) {
		bemerkungTextArea = new RTextArea();
		bemerkungTextArea.setText("sonstigesTextArea");
		bemerkungTextArea.setStyleProperties("{/fill \"BOTH\"/weightY \"1\"/weightX \"1\"}");
		bemerkungTextArea.setName("bemerkungTextArea");
	}
	return bemerkungTextArea;
}

/**
 * This method initializes referenzLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getReferenzLabel() {
	if (referenzLabel == null) {
		referenzLabel = new RLabel();
		referenzLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/referenz\") %>");
		referenzLabel.setName("referenzLabel");
	}
	return referenzLabel;
}

/**
 * This method initializes referenzTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getReferenzTextField() {
	if (referenzTextField == null) {
		referenzTextField = new RTextField();
		referenzTextField.setText("referenzTextField");
		referenzTextField.setStyleProperties("{/foregroundColor {/b \"51\"/r \"255\"/g \"51\"}}");
		referenzTextField.setName("referenzTextField");
	}
	return referenzTextField;
}

/**
 * This method initializes anlehnungsgrundSonstigesScrollPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getAnlehnungsgrundSonstigesScrollPane() {
	if (anlehnungsgrundSonstigesScrollPane == null) {
		anlehnungsgrundSonstigesScrollPane = new RScrollPane();
		anlehnungsgrundSonstigesScrollPane.setName("anlehnungsgrundSonstigesScrollPane");
		anlehnungsgrundSonstigesScrollPane.setStyleProperties("{/fill \"BOTH\"/weightY \"1\"/weightX \"1\"}");
		anlehnungsgrundSonstigesScrollPane.setViewPortView(getBemerkungTextArea());
	}
	return anlehnungsgrundSonstigesScrollPane;
}

/**
 * This method initializes buttonFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getButtonFlowLayoutPane() {
	if (buttonFlowLayoutPane == null) {
		buttonFlowLayoutPane = new RFlowLayoutPane();
		buttonFlowLayoutPane.setName("buttonFlowLayoutPane");
		buttonFlowLayoutPane.setStyle("buttonleiste");
		buttonFlowLayoutPane.add(getAbbrechenButton());
		buttonFlowLayoutPane.add(getOkButton());
	}
	return buttonFlowLayoutPane;
}

/**
 * This method initializes abbrechenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAbbrechenButton() {
	if (abbrechenButton == null) {
		abbrechenButton = new RButton();
		abbrechenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/abbrechen\") %>");
		abbrechenButton.setName("abbrechenButton");
	}
	return abbrechenButton;
}

/**
 * This method initializes okButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getOkButton() {
	if (okButton == null) {
		okButton = new RButton();
		okButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ok\") %>");
		okButton.setName("okButton");
	}
	return okButton;
}
}  //  @jve:decl-index=0:visual-constraint="24,24"