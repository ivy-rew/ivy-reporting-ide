package de.hummel.allgemein.gui.x2000_artikel;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RTable;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;

/**
 * <p>x2000_artikelPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class x2000_artikelPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel artikelnummerLabel = null;
private RTextField artikelnummerTextField = null;
private RScrollPane artikelScrollPane = null;
private RTable artikelTable = null;
  
  /**
   * Create a new instance of x2000_artikelPanel
   */
  public x2000_artikelPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes x2000_artikelPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(385,197));
        this.add(getArtikelnummerLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getArtikelnummerTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getArtikelScrollPane(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 2, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes artikelnummerLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getArtikelnummerLabel() {
	if (artikelnummerLabel == null) {
		artikelnummerLabel = new RLabel();
		artikelnummerLabel.setText("artikelnummer");
		artikelnummerLabel.setName("artikelnummerLabel");
	}
	return artikelnummerLabel;
}

/**
 * This method initializes artikelnummerTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getArtikelnummerTextField() {
	if (artikelnummerTextField == null) {
		artikelnummerTextField = new RTextField();
		artikelnummerTextField.setText("TextField");
		artikelnummerTextField.setName("artikelnummerTextField");
	}
	return artikelnummerTextField;
}

/**
 * This method initializes artikelScrollPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getArtikelScrollPane() {
	if (artikelScrollPane == null) {
		artikelScrollPane = new RScrollPane();
		artikelScrollPane.setName("artikelScrollPane");
		artikelScrollPane.setStyle("fill-both");
		artikelScrollPane.setViewPortView(getArtikelTable());
	}
	return artikelScrollPane;
}

/**
 * This method initializes artikelTable	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTable	
 */
private RTable getArtikelTable() {
	if (artikelTable == null) {
		artikelTable = new RTable();
		artikelTable.setName("artikelTable");
	}
	return artikelTable;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"