package de.hummel.allgemein.gui.Genehmigung;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RComboBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextArea;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;

/**
 * <p>PepGenehmigungPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class GenehmigungPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel genhmigungLabel = null;
private RLabel bemerkungLabel = null;
private RTextArea bemerkungTextArea = null;
private RLabel referenzLabel = null;
private RTextField referenzTextField = null;
private RButton okButton = null;
private RFlowLayoutPane buttonsFlowLayoutPane = null;
private RScrollPane bemerkungScrollPane = null;
private RButton abbrechenButton = null;
  
  /**
   * Create a new instance of PepGenehmigungPanel
   */
  public GenehmigungPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepGenehmigungPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(449,145));
        this.add(getGenhmigungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getBemerkungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getReferenzLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getReferenzTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getButtonsFlowLayoutPane(), new com.ulcjava.base.application.GridBagConstraints(1, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getBemerkungScrollPane(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes genhmigungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getGenhmigungLabel() {
	if (genhmigungLabel == null) {
		genhmigungLabel = new RLabel();
		genhmigungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/genehmigung\") %>");
		genhmigungLabel.setStyle("ueberschrift");
		genhmigungLabel.setName("genhmigungLabel");
	}
	return genhmigungLabel;
}

/**
 * This method initializes bemerkungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getBemerkungLabel() {
	if (bemerkungLabel == null) {
		bemerkungLabel = new RLabel();
		bemerkungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/bemerkungSonst\") %>");
		bemerkungLabel.setName("bemerkungLabel");
	}
	return bemerkungLabel;
}

/**
 * This method initializes bemerkungTextArea	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextArea	
 */
private RTextArea getBemerkungTextArea() {
	if (bemerkungTextArea == null) {
		bemerkungTextArea = new RTextArea();
		bemerkungTextArea.setText("sonstigesTextArea");
		bemerkungTextArea.setStyle("fill-horiz-north");
		bemerkungTextArea.setStyleProperties("{/fill \"BOTH\"/weightY \"1\"/weightX \"1\"}");
		bemerkungTextArea.setName("bemerkungTextArea");
	}
	return bemerkungTextArea;
}

/**
 * This method initializes referenzLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getReferenzLabel() {
	if (referenzLabel == null) {
		referenzLabel = new RLabel();
		referenzLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/referenz\") %>");
		referenzLabel.setName("referenzLabel");
	}
	return referenzLabel;
}

/**
 * This method initializes referenzTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getReferenzTextField() {
	if (referenzTextField == null) {
		referenzTextField = new RTextField();
		referenzTextField.setText("referenzTextField");
		referenzTextField.setStyleProperties("{/foregroundColor {/b \"51\"/r \"255\"/g \"51\"}}");
		referenzTextField.setName("referenzTextField");
	}
	return referenzTextField;
}

/**
 * This method initializes okButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getOkButton() {
	if (okButton == null) {
		okButton = new RButton();
		okButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ok\") %>");
		okButton.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/ok_16\") %>");
		okButton.setName("okButton");
	}
	return okButton;
}

/**
 * This method initializes buttonsFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getButtonsFlowLayoutPane() {
	if (buttonsFlowLayoutPane == null) {
		buttonsFlowLayoutPane = new RFlowLayoutPane();
		buttonsFlowLayoutPane.setName("buttonsFlowLayoutPane");
		buttonsFlowLayoutPane.setStyle("buttonleiste");
		buttonsFlowLayoutPane.add(getOkButton());
		buttonsFlowLayoutPane.add(getAbbrechenButton());
	}
	return buttonsFlowLayoutPane;
}

/**
 * This method initializes bemerkungScrollPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getBemerkungScrollPane() {
	if (bemerkungScrollPane == null) {
		bemerkungScrollPane = new RScrollPane();
		bemerkungScrollPane.setName("bemerkungScrollPane");
		bemerkungScrollPane.setStyleProperties("{/fill \"BOTH\"/weightY \"1\"/weightX \"1\"}");
		bemerkungScrollPane.setViewPortView(getBemerkungTextArea());
	}
	return bemerkungScrollPane;
}

/**
 * This method initializes abbrechenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAbbrechenButton() {
	if (abbrechenButton == null) {
		abbrechenButton = new RButton();
		abbrechenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/abbrechen\") %>");
		abbrechenButton.setName("abbrechenButton");
	}
	return abbrechenButton;
}
}  //  @jve:decl-index=0:visual-constraint="24,24"