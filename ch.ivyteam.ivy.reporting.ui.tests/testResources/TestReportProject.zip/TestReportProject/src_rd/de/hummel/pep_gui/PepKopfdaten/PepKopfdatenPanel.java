package de.hummel.pep_gui.PepKopfdaten;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RComboBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RLookupTextField;

/**
 * <p>PepKopfdatenPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepKopfdatenPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel antragstellerLabel = null;
private RTextField antragstellerTextField = null;
private RLabel antragsdatumLabel = null;
private RTextField antragsdatumTextField = null;
private RLabel geschaeftsbereichLabel = null;
private RLabel warengruppeLabel = null;
private RComboBox geschaeftsbereichComboBox = null;
private RComboBox warengruppeComboBox = null;
private RLabel entwicklungstypLabel = null;
private RLookupTextField entwicklungstypLookupTextField = null;
private RLabel referenzeProjektnummerLabel = null;
private RLabel prioritaetLabel = null;
private RTextField referenzProjektnummerTextField = null;
private RTextField prioritetTextField = null;
private RLabel ansprechpartnerLabel = null;
private RLabel mengeLabel = null;
private RTextField ansprechpartnerTextField = null;
private RTextField mengeTextField = null;
/**
   * Create a new instance of PepKopfdatenPanel
   */
  public PepKopfdatenPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepKopfdatenPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(null);
        this.add(getAntragstellerLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAntragstellerTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAntragsdatumLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAntragsdatumTextField(), new com.ulcjava.base.application.GridBagConstraints(3, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGeschaeftsbereichLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWarengruppeLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGeschaeftsbereichComboBox(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWarengruppeComboBox(), new com.ulcjava.base.application.GridBagConstraints(3, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getEntwicklungstypLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getEntwicklungstypLookupTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getReferenzeProjektnummerLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPrioritaetLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getReferenzProjektnummerTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPrioritetTextField(), new com.ulcjava.base.application.GridBagConstraints(3, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAnsprechpartnerLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMengeLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAnsprechpartnerTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMengeTextField(), new com.ulcjava.base.application.GridBagConstraints(3, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes antragstellerLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAntragstellerLabel() {
	if (antragstellerLabel == null) {
		antragstellerLabel = new RLabel();
		antragstellerLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/antragsteller\") %>");
		antragstellerLabel.setName("antragstellerLabel");
	}
	return antragstellerLabel;
}

/**
 * This method initializes antragstellerTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getAntragstellerTextField() {
	if (antragstellerTextField == null) {
		antragstellerTextField = new RTextField();
		antragstellerTextField.setText("antragstellerTextField");
		antragstellerTextField.setEditable(false);
		antragstellerTextField.setName("antragstellerTextField");
	}
	return antragstellerTextField;
}

/**
 * This method initializes antragsdatumLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAntragsdatumLabel() {
	if (antragsdatumLabel == null) {
		antragsdatumLabel = new RLabel();
		antragsdatumLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/antragsdatum\") %>");
		antragsdatumLabel.setName("antragsdatumLabel");
	}
	return antragsdatumLabel;
}

/**
 * This method initializes antragsdatumTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getAntragsdatumTextField() {
	if (antragsdatumTextField == null) {
		antragsdatumTextField = new RTextField();
		antragsdatumTextField.setText("antragsdatumTextField");
		antragsdatumTextField.setEditable(false);
		antragsdatumTextField.setName("antragsdatumTextField");
	}
	return antragsdatumTextField;
}

/**
 * This method initializes geschaeftsbereichLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getGeschaeftsbereichLabel() {
	if (geschaeftsbereichLabel == null) {
		geschaeftsbereichLabel = new RLabel();
		geschaeftsbereichLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/geschaeftsbereich\") %>");
		geschaeftsbereichLabel.setName("geschaeftsbereichLabel");
	}
	return geschaeftsbereichLabel;
}

/**
 * This method initializes warengruppeLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getWarengruppeLabel() {
	if (warengruppeLabel == null) {
		warengruppeLabel = new RLabel();
		warengruppeLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/warengruppe\") %>");
		warengruppeLabel.setName("warengruppeLabel");
	}
	return warengruppeLabel;
}

/**
 * This method initializes geschaeftsbereichComboBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RComboBox	
 */
private RComboBox getGeschaeftsbereichComboBox() {
	if (geschaeftsbereichComboBox == null) {
		geschaeftsbereichComboBox = new RComboBox();
		geschaeftsbereichComboBox.setName("geschaeftsbereichComboBox");
		geschaeftsbereichComboBox.setMandatory(true);
		geschaeftsbereichComboBox.setModelConfiguration("{/result \"result=entry\"/version \"3.0\"/icon \"\"/tooltip \"\"}");
	}
	return geschaeftsbereichComboBox;
}

/**
 * This method initializes warengruppeComboBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RComboBox	
 */
private RComboBox getWarengruppeComboBox() {
	if (warengruppeComboBox == null) {
		warengruppeComboBox = new RComboBox();
		warengruppeComboBox.setName("warengruppeComboBox");
		warengruppeComboBox.setEnabler(getGeschaeftsbereichComboBox());
		warengruppeComboBox.setModelConfiguration("{/result \"result=entry\"/version \"3.0\"/icon \"\"/tooltip \"\"}");
	}
	return warengruppeComboBox;
}

/**
 * This method initializes entwicklungstypLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getEntwicklungstypLabel() {
	if (entwicklungstypLabel == null) {
		entwicklungstypLabel = new RLabel();
		entwicklungstypLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/entwicklungstyp\") %>");
		entwicklungstypLabel.setName("entwicklungstypLabel");
	}
	return entwicklungstypLabel;
}

/**
 * This method initializes entwicklungstypLookupTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLookupTextField	
 */
private RLookupTextField getEntwicklungstypLookupTextField() {
	if (entwicklungstypLookupTextField == null) {
		entwicklungstypLookupTextField = new RLookupTextField();
		entwicklungstypLookupTextField.setText("");
		entwicklungstypLookupTextField.setName("entwicklungstypLookupTextField");
	}
	return entwicklungstypLookupTextField;
}

/**
 * This method initializes referenzeProjektnummerLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getReferenzeProjektnummerLabel() {
	if (referenzeProjektnummerLabel == null) {
		referenzeProjektnummerLabel = new RLabel();
		referenzeProjektnummerLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/referenzProjektnummer\") %>");
		referenzeProjektnummerLabel.setName("referenzeProjektnummerLabel");
	}
	return referenzeProjektnummerLabel;
}

/**
 * This method initializes prioritaetLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getPrioritaetLabel() {
	if (prioritaetLabel == null) {
		prioritaetLabel = new RLabel();
		prioritaetLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/prioritaet\") %>");
		prioritaetLabel.setName("prioritaetLabel");
	}
	return prioritaetLabel;
}

/**
 * This method initializes referenzProjektnummerTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getReferenzProjektnummerTextField() {
	if (referenzProjektnummerTextField == null) {
		referenzProjektnummerTextField = new RTextField();
		referenzProjektnummerTextField.setText("referenzProjektnummerTextField");
		referenzProjektnummerTextField.setName("referenzProjektnummerTextField");
	}
	return referenzProjektnummerTextField;
}

/**
 * This method initializes prioritetTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getPrioritetTextField() {
	if (prioritetTextField == null) {
		prioritetTextField = new RTextField();
		prioritetTextField.setText("prioritetTextField");
		prioritetTextField.setName("prioritetTextField");
	}
	return prioritetTextField;
}

/**
 * This method initializes ansprechpartnerLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAnsprechpartnerLabel() {
	if (ansprechpartnerLabel == null) {
		ansprechpartnerLabel = new RLabel();
		ansprechpartnerLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/ansprechpartner\") %>");
		ansprechpartnerLabel.setName("ansprechpartnerLabel");
	}
	return ansprechpartnerLabel;
}

/**
 * This method initializes mengeLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getMengeLabel() {
	if (mengeLabel == null) {
		mengeLabel = new RLabel();
		mengeLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/menge\") %>");
		mengeLabel.setName("mengeLabel");
	}
	return mengeLabel;
}

/**
 * This method initializes ansprechpartnerTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getAnsprechpartnerTextField() {
	if (ansprechpartnerTextField == null) {
		ansprechpartnerTextField = new RTextField();
		ansprechpartnerTextField.setText("ansprechpartnerTextField");
		ansprechpartnerTextField.setName("ansprechpartnerTextField");
	}
	return ansprechpartnerTextField;
}

/**
 * This method initializes mengeTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getMengeTextField() {
	if (mengeTextField == null) {
		mengeTextField = new RTextField();
		mengeTextField.setText("mengeTextField");
		mengeTextField.setName("mengeTextField");
	}
	return mengeTextField;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"