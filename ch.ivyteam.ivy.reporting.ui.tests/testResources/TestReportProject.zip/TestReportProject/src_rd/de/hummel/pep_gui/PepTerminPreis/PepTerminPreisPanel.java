package de.hummel.pep_gui.PepTerminPreis;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import com.ulcjava.base.application.util.Font;

/**
 * <p>PepTerminPreisPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepTerminPreisPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel angebotBisLabel = null;
private RDatePicker angebotBisDatePicker = null;
private RLabel kdZeichnungBisLabel = null;
private RDatePicker kdZeichnungBisDatePicker = null;
private RLabel musterBisLabel = null;
private RLabel lieferungBisLabel = null;
private RDatePicker musterBisDatePicker = null;
private RDatePicker lieferungBisDatePicker = null;
private RLabel Preise = null;
private RLabel terminplanungLabel = null;
private RLabel zielpreisLabel = null;
private RLabel wettbewerbspreisLabel = null;
private RTextField zielpreisTextField = null;
private RTextField wettbewerbspreisTextField = null;
private RCheckBox kundenfreigabeCheckBox = null;
/**
   * Create a new instance of PepTerminPreisPanel
   */
  public PepTerminPreisPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepTerminPreisPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(null);
        this.add(getAngebotBisLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAngebotBisDatePicker(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKdZeichnungBisLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKdZeichnungBisDatePicker(), new com.ulcjava.base.application.GridBagConstraints(3, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMusterBisLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLieferungBisLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMusterBisDatePicker(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLieferungBisDatePicker(), new com.ulcjava.base.application.GridBagConstraints(3, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPreise(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getTerminplanungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getZielpreisLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWettbewerbspreisLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getZielpreisTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWettbewerbspreisTextField(), new com.ulcjava.base.application.GridBagConstraints(3, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKundenfreigabeCheckBox(), new com.ulcjava.base.application.GridBagConstraints(0, 6, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes angebotBisLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAngebotBisLabel() {
	if (angebotBisLabel == null) {
		angebotBisLabel = new RLabel();
		angebotBisLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/angebotBis\") %>");
		angebotBisLabel.setName("angebotBisLabel");
	}
	return angebotBisLabel;
}

/**
 * This method initializes angebotBisDatePicker	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker	
 */
private RDatePicker getAngebotBisDatePicker() {
	if (angebotBisDatePicker == null) {
		angebotBisDatePicker = new RDatePicker();
		angebotBisDatePicker.setName("angebotBisDatePicker");
	}
	return angebotBisDatePicker;
}

/**
 * This method initializes kdZeichnungBisLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getKdZeichnungBisLabel() {
	if (kdZeichnungBisLabel == null) {
		kdZeichnungBisLabel = new RLabel();
		kdZeichnungBisLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/kdZeichnungBis\") %>");
		kdZeichnungBisLabel.setName("kdZeichnungBisLabel");
	}
	return kdZeichnungBisLabel;
}

/**
 * This method initializes kdZeichnungBisDatePicker	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker	
 */
private RDatePicker getKdZeichnungBisDatePicker() {
	if (kdZeichnungBisDatePicker == null) {
		kdZeichnungBisDatePicker = new RDatePicker();
		kdZeichnungBisDatePicker.setName("kdZeichnungBisDatePicker");
	}
	return kdZeichnungBisDatePicker;
}

/**
 * This method initializes musterBisLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getMusterBisLabel() {
	if (musterBisLabel == null) {
		musterBisLabel = new RLabel();
		musterBisLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/musterBis\") %>");
		musterBisLabel.setName("musterBisLabel");
	}
	return musterBisLabel;
}

/**
 * This method initializes lieferungBisLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLieferungBisLabel() {
	if (lieferungBisLabel == null) {
		lieferungBisLabel = new RLabel();
		lieferungBisLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/lieferungBis\") %>");
		lieferungBisLabel.setName("lieferungBisLabel");
	}
	return lieferungBisLabel;
}

/**
 * This method initializes musterBisDatePicker	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker	
 */
private RDatePicker getMusterBisDatePicker() {
	if (musterBisDatePicker == null) {
		musterBisDatePicker = new RDatePicker();
		musterBisDatePicker.setName("musterBisDatePicker");
	}
	return musterBisDatePicker;
}

/**
 * This method initializes lieferungBisDatePicker	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker	
 */
private RDatePicker getLieferungBisDatePicker() {
	if (lieferungBisDatePicker == null) {
		lieferungBisDatePicker = new RDatePicker();
		lieferungBisDatePicker.setName("lieferungBisDatePicker");
	}
	return lieferungBisDatePicker;
}

/**
 * This method initializes Preise	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getPreise() {
	if (Preise == null) {
		Preise = new RLabel();
		Preise.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/preise\") %>");
		Preise.setFont(new Font("Dialog", 3, 18));
		Preise.setStyle("ueberschrift");
		Preise.setName("Preise");
	}
	return Preise;
}

/**
 * This method initializes terminplanungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getTerminplanungLabel() {
	if (terminplanungLabel == null) {
		terminplanungLabel = new RLabel();
		terminplanungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/terminplanung\") %>");
		terminplanungLabel.setFont(new Font("Dialog", 3, 18));
		terminplanungLabel.setStyle("ueberschrift");
		terminplanungLabel.setName("terminplanungLabel");
	}
	return terminplanungLabel;
}

/**
 * This method initializes zielpreisLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getZielpreisLabel() {
	if (zielpreisLabel == null) {
		zielpreisLabel = new RLabel();
		zielpreisLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/zielpreis\") %>");
		zielpreisLabel.setName("zielpreisLabel");
	}
	return zielpreisLabel;
}

/**
 * This method initializes wettbewerbspreisLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getWettbewerbspreisLabel() {
	if (wettbewerbspreisLabel == null) {
		wettbewerbspreisLabel = new RLabel();
		wettbewerbspreisLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/wettbewerbspreis\") %>");
		wettbewerbspreisLabel.setName("wettbewerbspreisLabel");
	}
	return wettbewerbspreisLabel;
}

/**
 * This method initializes zielpreisTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getZielpreisTextField() {
	if (zielpreisTextField == null) {
		zielpreisTextField = new RTextField();
		zielpreisTextField.setText("zielpreisTextField");
		zielpreisTextField.setName("zielpreisTextField");
	}
	return zielpreisTextField;
}

/**
 * This method initializes wettbewerbspreisTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getWettbewerbspreisTextField() {
	if (wettbewerbspreisTextField == null) {
		wettbewerbspreisTextField = new RTextField();
		wettbewerbspreisTextField.setText("wettbewerbspreisTextField");
		wettbewerbspreisTextField.setName("wettbewerbspreisTextField");
	}
	return wettbewerbspreisTextField;
}

/**
 * This method initializes kundenfreigabeCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getKundenfreigabeCheckBox() {
	if (kundenfreigabeCheckBox == null) {
		kundenfreigabeCheckBox = new RCheckBox();
		kundenfreigabeCheckBox.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/kundenfreigabe\") %>");
		kundenfreigabeCheckBox.setName("kundenfreigabeCheckBox");
	}
	return kundenfreigabeCheckBox;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"