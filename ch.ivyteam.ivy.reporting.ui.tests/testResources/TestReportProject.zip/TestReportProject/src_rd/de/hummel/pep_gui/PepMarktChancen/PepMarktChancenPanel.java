package de.hummel.pep_gui.PepMarktChancen;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RBrowser;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextArea;
import com.ulcjava.base.application.util.Font;
import com.ulcjava.base.application.util.ComponentOrientation;
import ch.ivyteam.ivy.richdialog.widgets.containers.RBoxPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RTabbedPane;
import ch.ivyteam.ivy.addons.filemanager.FileManager.FileManagerPanel;
import ch.ivyteam.ivy.richdialog.exec.panel.EmbeddedRichDialog;
import ch.ivyteam.ivy.richdialog.exec.panel.RichDialogPanelFactory;
import com.ulcjava.base.application.ULCContainer;

/**
 * <p>PepMarktChancenPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepMarktChancenPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RTabbedPane marktchancenTabbedPane = null;
private @EmbeddedRichDialog(FileManagerPanel.class) ULCContainer potenzialanalysefileManagerPanel = null;
private @EmbeddedRichDialog(FileManagerPanel.class) ULCContainer chanchenNutzenfileManagerPanel = null;
/**
   * Create a new instance of PepMarktChancenPanel
   */
  public PepMarktChancenPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepMarktChancenPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(666,330));
        this.add(getMarktchancenTabbedPane(), new com.ulcjava.base.application.GridBagConstraints(0, 6, 1, 2, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes marktchancenTabbedPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTabbedPane	
 */
public RTabbedPane getMarktchancenTabbedPane() {
	if (marktchancenTabbedPane == null) {
		marktchancenTabbedPane = new RTabbedPane();
		marktchancenTabbedPane.setName("marktchancenTabbedPane");
		marktchancenTabbedPane.setStyleProperties("{/fill \"BOTH\"/weightY \"1\"/weightX \"1\"}");
		marktchancenTabbedPane.addTab("<%=ivy.cms.co(\"/de.hummel.pep.gui/labels/absatzanalyse\")%>", null, getPotenzialanalysefileManagerPanel(), null);
		marktchancenTabbedPane.addTab("<%=ivy.cms.co(\"/de.hummel.pep.gui/labels/chancenNutzenAnalyse\")%>", null, getChanchenNutzenfileManagerPanel(), null);
	}
	return marktchancenTabbedPane;
}

/**
 * This method initializes potenzialanalysefileManagerPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPotenzialanalysefileManagerPanel() {
	if (potenzialanalysefileManagerPanel == null) {
		potenzialanalysefileManagerPanel = RichDialogPanelFactory
				.create(FileManagerPanel.class);
		potenzialanalysefileManagerPanel.setName("potenzialanalysefileManagerPanel");
	}
	return potenzialanalysefileManagerPanel;
}

/**
 * This method initializes chanchenNutzenfileManagerPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getChanchenNutzenfileManagerPanel() {
	if (chanchenNutzenfileManagerPanel == null) {
		chanchenNutzenfileManagerPanel = RichDialogPanelFactory
				.create(FileManagerPanel.class);
		chanchenNutzenfileManagerPanel.setName("chanchenNutzenfileManagerPanel");
	}
	return chanchenNutzenfileManagerPanel;
}

@Override
public void setEnabled(boolean enabled) {
	super.setEnabled(enabled);
	getMarktchancenTabbedPane().setEnabled(true);
}


}  //  @jve:decl-index=0:visual-constraint="-13,-7"