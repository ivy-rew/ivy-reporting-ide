package de.hummel.pep_gui.PepProjektauftrag;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RComboBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker;

/**
 * <p>PepProjektauftragPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepProjektauftragPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel stichwortLabel = null;
private RLabel projektleiterLabel = null;
private RTextField stichwortTextField = null;
private RComboBox projektleiterComboBox = null;
private RLabel startterminLabel = null;
private RLabel endterminLabel = null;
private RDatePicker starterminDatePicker = null;
private RDatePicker endterminDatePicker = null;
/**
   * Create a new instance of PepProjektauftragPanel
   */
  public PepProjektauftragPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepProjektauftragPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(582,86));
        this.add(getStichwortLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProjektleiterLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getStichwortTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProjektleiterComboBox(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getStartterminLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getEndterminLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getStarterminDatePicker(), new com.ulcjava.base.application.GridBagConstraints(3, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getEndterminDatePicker(), new com.ulcjava.base.application.GridBagConstraints(3, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes stichwortLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getStichwortLabel() {
	if (stichwortLabel == null) {
		stichwortLabel = new RLabel();
		stichwortLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/stichwort\") %>");
		stichwortLabel.setName("stichwortLabel");
	}
	return stichwortLabel;
}

/**
 * This method initializes projektleiterLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getProjektleiterLabel() {
	if (projektleiterLabel == null) {
		projektleiterLabel = new RLabel();
		projektleiterLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/projektleiter\") %>");
		projektleiterLabel.setName("projektleiterLabel");
	}
	return projektleiterLabel;
}

/**
 * This method initializes stichwortTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getStichwortTextField() {
	if (stichwortTextField == null) {
		stichwortTextField = new RTextField();
		stichwortTextField.setText("stichwortTextField");
		stichwortTextField.setMandatory(false);
		stichwortTextField.setName("stichwortTextField");
	}
	return stichwortTextField;
}

/**
 * This method initializes projektleiterComboBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RComboBox	
 */
private RComboBox getProjektleiterComboBox() {
	if (projektleiterComboBox == null) {
		projektleiterComboBox = new RComboBox();
		projektleiterComboBox.setName("projektleiterComboBox");
		projektleiterComboBox.setMandatory(true);
		projektleiterComboBox.setModelConfiguration("{/result \"result=entry.getName()\"/version \"3.0\"/icon \"\"/tooltip \"\"}");
	}
	return projektleiterComboBox;
}

/**
 * This method initializes startterminLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getStartterminLabel() {
	if (startterminLabel == null) {
		startterminLabel = new RLabel();
		startterminLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/starttermin\") %>");
		startterminLabel.setName("startterminLabel");
	}
	return startterminLabel;
}

/**
 * This method initializes endterminLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getEndterminLabel() {
	if (endterminLabel == null) {
		endterminLabel = new RLabel();
		endterminLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/endtermin\") %>");
		endterminLabel.setName("endterminLabel");
	}
	return endterminLabel;
}

/**
 * This method initializes starterminDatePicker	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker	
 */
private RDatePicker getStarterminDatePicker() {
	if (starterminDatePicker == null) {
		starterminDatePicker = new RDatePicker();
		starterminDatePicker.setName("starterminDatePicker");
	}
	return starterminDatePicker;
}

/**
 * This method initializes endterminDatePicker	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RDatePicker	
 */
private RDatePicker getEndterminDatePicker() {
	if (endterminDatePicker == null) {
		endterminDatePicker = new RDatePicker();
		endterminDatePicker.setName("endterminDatePicker");
	}
	return endterminDatePicker;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"