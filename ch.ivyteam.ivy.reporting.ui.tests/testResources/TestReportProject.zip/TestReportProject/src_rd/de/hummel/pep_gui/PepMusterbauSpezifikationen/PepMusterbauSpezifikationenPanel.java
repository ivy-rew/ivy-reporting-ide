package de.hummel.pep_gui.PepMusterbauSpezifikationen;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;

/**
 * <p>PepMusterbauSpezifikationenPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepMusterbauSpezifikationenPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel musterbauSpezLabel = null;
private RCheckBox werkzeugCheckBox = null;
private RCheckBox musterCheckBox = null;
private RCheckBox prototypCheckBox = null;
private RCheckBox schutzCheckBox = null;
private RButton okButton = null;
private RFlowLayoutPane buttonFlowLayoutPane = null;
private RButton antragReferenzButton = null;
private RButton projektReferenzButton = null;
  
  /**
   * Create a new instance of PepMusterbauSpezifikationenPanel
   */
  public PepMusterbauSpezifikationenPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepMusterbauSpezifikationenPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(460,252));
        this.add(getMusterbauSpezLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWerkzeugCheckBox(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMusterCheckBox(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPrototypCheckBox(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSchutzCheckBox(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getButtonFlowLayoutPane(), new com.ulcjava.base.application.GridBagConstraints(0, 6, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes musterbauSpezLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getMusterbauSpezLabel() {
	if (musterbauSpezLabel == null) {
		musterbauSpezLabel = new RLabel();
		musterbauSpezLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/MusterbauundProduktionsspezifikationen\") %>");
		musterbauSpezLabel.setStyle("ueberschrift");
		musterbauSpezLabel.setName("musterbauSpezLabel");
	}
	return musterbauSpezLabel;
}

/**
 * This method initializes werkzeugCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getWerkzeugCheckBox() {
	if (werkzeugCheckBox == null) {
		werkzeugCheckBox = new RCheckBox();
		werkzeugCheckBox.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/werkzeug\") %>");
		werkzeugCheckBox.setName("werkzeugCheckBox");
	}
	return werkzeugCheckBox;
}

/**
 * This method initializes musterCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getMusterCheckBox() {
	if (musterCheckBox == null) {
		musterCheckBox = new RCheckBox();
		musterCheckBox.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/muster\") %>");
		musterCheckBox.setName("musterCheckBox");
	}
	return musterCheckBox;
}

/**
 * This method initializes prototypCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getPrototypCheckBox() {
	if (prototypCheckBox == null) {
		prototypCheckBox = new RCheckBox();
		prototypCheckBox.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/prototyp\") %>");
		prototypCheckBox.setName("prototypCheckBox");
	}
	return prototypCheckBox;
}

/**
 * This method initializes schutzCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getSchutzCheckBox() {
	if (schutzCheckBox == null) {
		schutzCheckBox = new RCheckBox();
		schutzCheckBox.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/schutzaspekte\") %>");
		schutzCheckBox.setName("schutzCheckBox");
	}
	return schutzCheckBox;
}

/**
 * This method initializes okButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getOkButton() {
	if (okButton == null) {
		okButton = new RButton();
		okButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ok\") %>");
		okButton.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/ok_16\") %>");
		okButton.setName("okButton");
	}
	return okButton;
}

/**
 * This method initializes buttonFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getButtonFlowLayoutPane() {
	if (buttonFlowLayoutPane == null) {
		buttonFlowLayoutPane = new RFlowLayoutPane();
		buttonFlowLayoutPane.setName("buttonFlowLayoutPane");
		buttonFlowLayoutPane.setStyle("buttonleiste");
		buttonFlowLayoutPane.add(getProjektReferenzButton());
		buttonFlowLayoutPane.add(getAntragReferenzButton());
		buttonFlowLayoutPane.add(getOkButton());
	}
	return buttonFlowLayoutPane;
}

/**
 * This method initializes antragReferenzButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAntragReferenzButton() {
	if (antragReferenzButton == null) {
		antragReferenzButton = new RButton();
		antragReferenzButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/antragReferenz\") %>");
		antragReferenzButton.setName("antragReferenzButton");
	}
	return antragReferenzButton;
}

/**
 * This method initializes projektReferenzButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getProjektReferenzButton() {
	if (projektReferenzButton == null) {
		projektReferenzButton = new RButton();
		projektReferenzButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/projektReferenz\") %>");
		projektReferenzButton.setName("projektReferenzButton");
	}
	return projektReferenzButton;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"