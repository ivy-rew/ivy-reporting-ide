package de.hummel.pep_gui.PepAufwand;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;
import com.ulcjava.base.application.ULCFlowLayoutPane;

/**
 * <p>PepAufwandPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepAufwandPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel aufwandabschaetzenLabel = null;
private RLabel entwicklerLabel = null;
private RLabel cadLabel = null;
private RLabel werkzeugLabel = null;
private RLabel extKostenLabel = null;
private RLabel gesamtStundenLabel = null;
private RTextField entwicklerTextField = null;
private RTextField cadTextField = null;
private RTextField werkzeugTextField = null;
private RTextField extKostenTextField = null;
private RTextField gesamtStundenTextField = null;
private RLabel gesamtKostenLabel = null;
private RTextField gesamtKostenTextField = null;
/**
   * Create a new instance of PepAufwandPanel
   */
  public PepAufwandPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepAufwandPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(522,181));
        this.add(getAufwandabschaetzenLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getEntwicklerLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getCadLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWerkzeugLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getExtKostenLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGesamtStundenLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getEntwicklerTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getCadTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getWerkzeugTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getExtKostenTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGesamtStundenTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGesamtKostenLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 6, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getGesamtKostenTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 6, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes aufwandabschaetzenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAufwandabschaetzenLabel() {
	if (aufwandabschaetzenLabel == null) {
		aufwandabschaetzenLabel = new RLabel();
		aufwandabschaetzenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/aufwandsabschaetzung\") %>");
		aufwandabschaetzenLabel.setStyle("ueberschrift");
		aufwandabschaetzenLabel.setName("aufwandabschaetzenLabel");
	}
	return aufwandabschaetzenLabel;
}

/**
 * This method initializes entwicklerLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getEntwicklerLabel() {
	if (entwicklerLabel == null) {
		entwicklerLabel = new RLabel();
		entwicklerLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/entwicklerStunden\") %>");
		entwicklerLabel.setName("entwicklerLabel");
	}
	return entwicklerLabel;
}

/**
 * This method initializes cadLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getCadLabel() {
	if (cadLabel == null) {
		cadLabel = new RLabel();
		cadLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/cadStunden\") %>");
		cadLabel.setName("cadLabel");
	}
	return cadLabel;
}

/**
 * This method initializes werkzeugLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getWerkzeugLabel() {
	if (werkzeugLabel == null) {
		werkzeugLabel = new RLabel();
		werkzeugLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/werkzeugKosten\") %>");
		werkzeugLabel.setName("werkzeugLabel");
	}
	return werkzeugLabel;
}

/**
 * This method initializes extKostenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getExtKostenLabel() {
	if (extKostenLabel == null) {
		extKostenLabel = new RLabel();
		extKostenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/extKosten\") %>");
		extKostenLabel.setName("extKostenLabel");
	}
	return extKostenLabel;
}

/**
 * This method initializes gesamtStundenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getGesamtStundenLabel() {
	if (gesamtStundenLabel == null) {
		gesamtStundenLabel = new RLabel();
		gesamtStundenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/gesamtStunden\") %>");
		gesamtStundenLabel.setName("gesamtStundenLabel");
	}
	return gesamtStundenLabel;
}

/**
 * This method initializes entwicklerTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getEntwicklerTextField() {
	if (entwicklerTextField == null) {
		entwicklerTextField = new RTextField();
		entwicklerTextField.setText("0");
		entwicklerTextField.setName("entwicklerTextField");
	}
	return entwicklerTextField;
}

/**
 * This method initializes cadTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getCadTextField() {
	if (cadTextField == null) {
		cadTextField = new RTextField();
		cadTextField.setText("0");
		cadTextField.setName("cadTextField");
	}
	return cadTextField;
}

/**
 * This method initializes werkzeugTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getWerkzeugTextField() {
	if (werkzeugTextField == null) {
		werkzeugTextField = new RTextField();
		werkzeugTextField.setText("0");
		werkzeugTextField.setName("werkzeugTextField");
	}
	return werkzeugTextField;
}

/**
 * This method initializes extKostenTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getExtKostenTextField() {
	if (extKostenTextField == null) {
		extKostenTextField = new RTextField();
		extKostenTextField.setText("0");
		extKostenTextField.setName("extKostenTextField");
	}
	return extKostenTextField;
}

/**
 * This method initializes gesamtStundenTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getGesamtStundenTextField() {
	if (gesamtStundenTextField == null) {
		gesamtStundenTextField = new RTextField();
		gesamtStundenTextField.setText("0");
		gesamtStundenTextField.setEnabled(false);
		gesamtStundenTextField.setName("gesamtStundenTextField");
	}
	return gesamtStundenTextField;
}

/**
 * This method initializes gesamtKostenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getGesamtKostenLabel() {
	if (gesamtKostenLabel == null) {
		gesamtKostenLabel = new RLabel();
		gesamtKostenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/gesamtKosten\") %>");
		gesamtKostenLabel.setName("gesamtKostenLabel");
	}
	return gesamtKostenLabel;
}

/**
 * This method initializes gesamtKostenTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getGesamtKostenTextField() {
	if (gesamtKostenTextField == null) {
		gesamtKostenTextField = new RTextField();
		gesamtKostenTextField.setText("0");
		gesamtKostenTextField.setEnabled(false);
		gesamtKostenTextField.setName("gesamtKostenTextField");
	}
	return gesamtKostenTextField;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"