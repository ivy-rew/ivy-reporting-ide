package de.hummel.pep_gui.PepProzessKette;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.xpertline.ivy.richdialog.widgets.components.RProcessStep;

/**
 * <p>PepProzessKettePanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepProzessKettePanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RProcessStep rProcessStep1 = null;
private RProcessStep rProcessStep2 = null;
private RProcessStep rProcessStep3 = null;
  
  /**
   * Create a new instance of PepProzessKettePanel
   */
  public PepProzessKettePanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepProzessKettePanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(510,37));
        this.add(getRProcessStep1(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getRProcessStep2(), new com.ulcjava.base.application.GridBagConstraints(1, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getRProcessStep3(), new com.ulcjava.base.application.GridBagConstraints(2, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes rProcessStep1	
 * 	
 * @return ch.xpertline.ivy.richdialog.widgets.components.RProcessStep	
 */
private RProcessStep getRProcessStep1() {
	if (rProcessStep1 == null) {
		rProcessStep1 = new RProcessStep();
		rProcessStep1.setText("Antrag stellen");
		rProcessStep1.setName("rProcessStep1");
	}
	return rProcessStep1;
}

/**
 * This method initializes rProcessStep2	
 * 	
 * @return ch.xpertline.ivy.richdialog.widgets.components.RProcessStep	
 */
private RProcessStep getRProcessStep2() {
	if (rProcessStep2 == null) {
		rProcessStep2 = new RProcessStep();
		rProcessStep2.setName("rProcessStep2");
		rProcessStep2.setText("Pr�fung und Aufwand sch�tzen");
	}
	return rProcessStep2;
}

/**
 * This method initializes rProcessStep3	
 * 	
 * @return ch.xpertline.ivy.richdialog.widgets.components.RProcessStep	
 */
private RProcessStep getRProcessStep3() {
	if (rProcessStep3 == null) {
		rProcessStep3 = new RProcessStep();
		rProcessStep3.setName("rProcessStep3");
		rProcessStep3.setText("Genehmigung");
	}
	return rProcessStep3;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"