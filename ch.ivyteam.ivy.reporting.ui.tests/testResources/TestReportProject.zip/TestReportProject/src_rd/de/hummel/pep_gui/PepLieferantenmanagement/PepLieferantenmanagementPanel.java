package de.hummel.pep_gui.PepLieferantenmanagement;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogBorderPanel;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;
import ch.ivyteam.ivy.richdialog.widgets.components.RTable;
import ch.ivyteam.ivy.richdialog.widgets.containers.RGridBagLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RComboBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.components.customrenderers.RComboBoxCellWidget;
import ch.ivyteam.ivy.richdialog.widgets.components.RFiller;
import com.ulcjava.base.application.ULCTable;
import ch.ivyteam.ivy.richdialog.widgets.components.customrenderers.RTextFieldCellWidget;

/**
 * <p>PepLieferantenmanagementPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepLieferantenmanagementPanel extends RichDialogBorderPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RScrollPane lieferantenScrollPane = null;
private RTable lieferantenTable = null;
private RGridBagLayoutPane lieferantenGridBagLayoutPane = null;
private RFlowLayoutPane lieferantenFlowLayoutPane = null;
private RButton neuButton = null;
private RButton loeschenButton = null;
private RComboBoxCellWidget ortComboBoxCellWidget = null;
private RTextFieldCellWidget teilTextFieldCellWidget = null;
/**
   * Create a new instance of PepLieferantenmanagementPanel
   */
  public PepLieferantenmanagementPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepLieferantenmanagementPanel
   * @return void
   */
  private void initialize()
  {
        RFiller lfmgmtlFiller = new RFiller();
        RFiller lfmgmgrFiller = new RFiller();
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(462,208));
        this.add(getLieferantenGridBagLayoutPane(), com.ulcjava.base.application.ULCBorderLayoutPane.NORTH);
        this.add(getLieferantenFlowLayoutPane(), com.ulcjava.base.application.ULCBorderLayoutPane.SOUTH);
        this.add(lfmgmgrFiller, com.ulcjava.base.application.ULCBorderLayoutPane.EAST);
        this.add(lfmgmtlFiller, com.ulcjava.base.application.ULCBorderLayoutPane.WEST);
        this.add(getLieferantenScrollPane(), com.ulcjava.base.application.ULCBorderLayoutPane.CENTER);
  }

/**
 * This method initializes lieferantenScrollPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getLieferantenScrollPane() {
	if (lieferantenScrollPane == null) {
		lieferantenScrollPane = new RScrollPane();
		lieferantenScrollPane.setName("lieferantenScrollPane");
		lieferantenScrollPane.setViewPortView(getLieferantenTable());
	}
	return lieferantenScrollPane;
}

/**
 * This method initializes lieferantenTable	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTable	
 */
private RTable getLieferantenTable() {
	if (lieferantenTable == null) {
		lieferantenTable = new RTable();
		lieferantenTable.setName("lieferantenTable");
		lieferantenTable.setModelConfiguration("{/showTableheader true /autoTableheader false /showtooltip false /showIcons false /version \"3.0\"/columns {{/result \"result=value\"/version \"3.0\"/tooltip \"\"/icon \"\"/header \"ivy.cms.co(\\\"/de.hummel.pep.gui/labels/teil\\\")\"/field \"teil\"/editable \"true\"/condition \"true\"/cellWidget \"teilTextFieldCellWidget\"}{/result \"result=value\"/version \"3.0\"/tooltip \"\"/icon \"\"/header \"ivy.cms.co(\\\"/de.hummel.pep.gui/labels/produktionsort\\\")\"/field \"ort\"/editable \"true\"/condition \"true\"/cellWidget \"ortComboBoxCellWidget\"}{/result \"result=value\"/version \"3.0\"/tooltip \"\"/icon \"\"/header \"ivy.cms.co(\\\"/de.hummel.pep.gui/labels/bemerkungSonst\\\")\"/field \"bemerkung\"/editable \"true\"/condition \"true\"/cellWidget \"\"}}}");
		lieferantenTable.setAutoResizeMode(ULCTable.AUTO_RESIZE_LAST_COLUMN);
		lieferantenTable.setSortable(true);
	}
	return lieferantenTable;
}

/**
 * This method initializes lieferantenGridBagLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RGridBagLayoutPane	
 */
private RGridBagLayoutPane getLieferantenGridBagLayoutPane() {
	if (lieferantenGridBagLayoutPane == null) {
		RFiller lieferantenmanagementFiller = new RFiller();
		lieferantenGridBagLayoutPane = new RGridBagLayoutPane();
		lieferantenGridBagLayoutPane.setName("lieferantenGridBagLayoutPane");
		lieferantenGridBagLayoutPane.setAlignmentX(0.0F);
		lieferantenGridBagLayoutPane.setAlignmentY(0.0F);
		lieferantenGridBagLayoutPane.add(lieferantenmanagementFiller, new com.ulcjava.base.application.GridBagConstraints(1, 0, 2, 2, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
	}
	return lieferantenGridBagLayoutPane;
}

/**
 * This method initializes lieferantenFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getLieferantenFlowLayoutPane() {
	if (lieferantenFlowLayoutPane == null) {
		lieferantenFlowLayoutPane = new RFlowLayoutPane();
		lieferantenFlowLayoutPane.setName("lieferantenFlowLayoutPane");
		lieferantenFlowLayoutPane.setStyle("buttonleiste");
		lieferantenFlowLayoutPane.add(getNeuButton());
		lieferantenFlowLayoutPane.add(getLoeschenButton());
		lieferantenFlowLayoutPane.add(getTeilTextFieldCellWidget());
		lieferantenFlowLayoutPane.add(getOrtComboBoxCellWidget());
	}
	return lieferantenFlowLayoutPane;
}

/**
 * This method initializes neuButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getNeuButton() {
	if (neuButton == null) {
		neuButton = new RButton();
		neuButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/neu\") %>");
		neuButton.setName("neuButton");
	}
	return neuButton;
}

/**
 * This method initializes loeschenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getLoeschenButton() {
	if (loeschenButton == null) {
		loeschenButton = new RButton();
		loeschenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/loeschen\") %>");
		loeschenButton.setName("loeschenButton");
	}
	return loeschenButton;
}

/**
 * This method initializes ortComboBoxCellWidget	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.customrenderers.RComboBoxCellWidget	
 */
private RComboBoxCellWidget getOrtComboBoxCellWidget() {
	if (ortComboBoxCellWidget == null) {
		ortComboBoxCellWidget = new RComboBoxCellWidget();
		ortComboBoxCellWidget.setName("ortComboBoxCellWidget");
		ortComboBoxCellWidget.setModelConfiguration("{/result \"\"/version \"3.0\"/icon \"\"/tooltip \"\"/keyField \"\"}");
		ortComboBoxCellWidget.setMandatory(false);
		ortComboBoxCellWidget.setVisible(false);
	}
	return ortComboBoxCellWidget;
}

/**
 * This method initializes teilTextFieldCellWidget	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.customrenderers.RTextFieldCellWidget	
 */
private RTextFieldCellWidget getTeilTextFieldCellWidget() {
	if (teilTextFieldCellWidget == null) {
		teilTextFieldCellWidget = new RTextFieldCellWidget();
		teilTextFieldCellWidget.setText("teilTextFieldCellWidget");
		teilTextFieldCellWidget.setVisible(false);
		teilTextFieldCellWidget.setMandatory(false);
		teilTextFieldCellWidget.setName("teilTextFieldCellWidget");
	}
	return teilTextFieldCellWidget;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"