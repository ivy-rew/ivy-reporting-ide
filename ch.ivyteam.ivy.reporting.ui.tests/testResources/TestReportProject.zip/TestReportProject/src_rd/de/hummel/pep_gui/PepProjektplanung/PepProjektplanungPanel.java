package de.hummel.pep_gui.PepProjektplanung;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogBorderPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPaneContainer;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane;
import de.hummel.pep_gui.PepProjektauftrag.PepProjektauftragPanel;
import ch.ivyteam.ivy.richdialog.exec.panel.EmbeddedRichDialog;
import ch.ivyteam.ivy.richdialog.exec.panel.RichDialogPanelFactory;
import com.ulcjava.base.application.ULCContainer;
import de.hummel.pep_gui.PepEntwicklungsschritte.PepEntwicklungsschrittePanel;
import de.hummel.pep_gui.PepProjektspezifikationen.PepProjektspezifikationenPanel;
import de.hummel.pep_gui.PepLieferantenmanagement.PepLieferantenmanagementPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RFiller;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;

/**
 * <p>PepProjektplanungPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepProjektplanungPanel extends RichDialogBorderPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel projektplanungLabel = null;
private RScrollPane projektplanungScrollPane = null;
private RTaskPaneContainer projektplanungTaskPaneContainer = null;
private RFlowLayoutPane FlowLayoutPane = null;
private RTaskPane projektauftragTaskPane = null;
private @EmbeddedRichDialog(PepProjektauftragPanel.class) ULCContainer pepProjektauftragPanel = null;
private RTaskPane entwicklungsschritteTaskPane = null;
private @EmbeddedRichDialog(PepEntwicklungsschrittePanel.class) ULCContainer pepEntwicklungsschrittePanel = null;
private RTaskPane projektspezifikationenTaskPane = null;
private @EmbeddedRichDialog(PepProjektspezifikationenPanel.class) ULCContainer pepProjektspezifikationenPanel = null;
private RTaskPane lieferantenmanagementTaskPane = null;
private @EmbeddedRichDialog(PepLieferantenmanagementPanel.class) ULCContainer pepLieferantenmanagementPanel = null;
private RFlowLayoutPane projplngFlowLayoutPane = null;
private RButton abbrechenButton = null;
private RButton okButton = null;
private RButton AblehnenButton = null;
private RButton GenehmigenButton = null;
private RButton referenzProjektAntragButton = null;
/**
   * Create a new instance of PepProjektplanungPanel
   */
  public PepProjektplanungPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepProjektplanungPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(716,565));
        this.add(getFlowLayoutPane(), com.ulcjava.base.application.ULCBorderLayoutPane.NORTH);
        this.add(getProjplngFlowLayoutPane(), com.ulcjava.base.application.ULCBorderLayoutPane.SOUTH);
        this.add(getProjektplanungScrollPane(), com.ulcjava.base.application.ULCBorderLayoutPane.CENTER);
  }

/**
 * This method initializes projektplanungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getProjektplanungLabel() {
	if (projektplanungLabel == null) {
		projektplanungLabel = new RLabel();
		projektplanungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/projektplanung\") %>");
		projektplanungLabel.setStyle("ueberschrift");
		projektplanungLabel.setName("projektplanungLabel");
	}
	return projektplanungLabel;
}

/**
 * This method initializes projektplanungScrollPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getProjektplanungScrollPane() {
	if (projektplanungScrollPane == null) {
		projektplanungScrollPane = new RScrollPane();
		projektplanungScrollPane.setName("projektplanungScrollPane");
		projektplanungScrollPane.setViewPortView(getProjektplanungTaskPaneContainer());
	}
	return projektplanungScrollPane;
}

/**
 * This method initializes projektplanungTaskPaneContainer	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPaneContainer	
 */
private RTaskPaneContainer getProjektplanungTaskPaneContainer() {
	if (projektplanungTaskPaneContainer == null) {
		projektplanungTaskPaneContainer = new RTaskPaneContainer();
		projektplanungTaskPaneContainer.setName("projektplanungTaskPaneContainer");
		projektplanungTaskPaneContainer.add(getProjektauftragTaskPane());
		projektplanungTaskPaneContainer.add(getEntwicklungsschritteTaskPane());
		projektplanungTaskPaneContainer.add(getProjektspezifikationenTaskPane());
		projektplanungTaskPaneContainer.add(getLieferantenmanagementTaskPane());
	}
	return projektplanungTaskPaneContainer;
}

/**
 * This method initializes FlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getFlowLayoutPane() {
	if (FlowLayoutPane == null) {
		FlowLayoutPane = new RFlowLayoutPane();
		FlowLayoutPane.setName("FlowLayoutPane");
		FlowLayoutPane.add(getProjektplanungLabel());
	}
	return FlowLayoutPane;
}

/**
 * This method initializes projektauftragTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getProjektauftragTaskPane() {
	if (projektauftragTaskPane == null) {
		projektauftragTaskPane = new RTaskPane();
		projektauftragTaskPane.setName("projektauftragTaskPane");
		projektauftragTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/projektauftrag\") %>");
		projektauftragTaskPane.add(getPepProjektauftragPanel());
	}
	return projektauftragTaskPane;
}

/**
 * This method initializes pepProjektauftragPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepProjektauftragPanel() {
	if (pepProjektauftragPanel == null) {
		pepProjektauftragPanel = RichDialogPanelFactory
				.create(PepProjektauftragPanel.class);
		pepProjektauftragPanel.setName("pepProjektauftragPanel");
	}
	return pepProjektauftragPanel;
}

/**
 * This method initializes entwicklungsschritteTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getEntwicklungsschritteTaskPane() {
	if (entwicklungsschritteTaskPane == null) {
		entwicklungsschritteTaskPane = new RTaskPane();
		entwicklungsschritteTaskPane.setName("entwicklungsschritteTaskPane");
		entwicklungsschritteTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/entwicklungsschritte\") %>");
		entwicklungsschritteTaskPane.add(getPepEntwicklungsschrittePanel());
	}
	return entwicklungsschritteTaskPane;
}

/**
 * This method initializes pepEntwicklungsschrittePanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepEntwicklungsschrittePanel() {
	if (pepEntwicklungsschrittePanel == null) {
		pepEntwicklungsschrittePanel = RichDialogPanelFactory
				.create(PepEntwicklungsschrittePanel.class);
		pepEntwicklungsschrittePanel.setName("pepEntwicklungsschrittePanel");
	}
	return pepEntwicklungsschrittePanel;
}

/**
 * This method initializes projektspezifikationenTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getProjektspezifikationenTaskPane() {
	if (projektspezifikationenTaskPane == null) {
		projektspezifikationenTaskPane = new RTaskPane();
		projektspezifikationenTaskPane.setName("projektspezifikationenTaskPane");
		projektspezifikationenTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/projektspezifikationen\") %>");
		projektspezifikationenTaskPane.add(getPepProjektspezifikationenPanel());
	}
	return projektspezifikationenTaskPane;
}

/**
 * This method initializes pepProjektspezifikationenPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepProjektspezifikationenPanel() {
	if (pepProjektspezifikationenPanel == null) {
		pepProjektspezifikationenPanel = RichDialogPanelFactory
				.create(PepProjektspezifikationenPanel.class);
		pepProjektspezifikationenPanel.setName("pepProjektspezifikationenPanel");
	}
	return pepProjektspezifikationenPanel;
}

/**
 * This method initializes lieferantenmanagementTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getLieferantenmanagementTaskPane() {
	if (lieferantenmanagementTaskPane == null) {
		lieferantenmanagementTaskPane = new RTaskPane();
		lieferantenmanagementTaskPane.setName("lieferantenmanagementTaskPane");
		lieferantenmanagementTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/lieferantenmanagement\") %>");
		lieferantenmanagementTaskPane.add(getPepLieferantenmanagementPanel());
	}
	return lieferantenmanagementTaskPane;
}

/**
 * This method initializes pepLieferantenmanagementPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepLieferantenmanagementPanel() {
	if (pepLieferantenmanagementPanel == null) {
		pepLieferantenmanagementPanel = RichDialogPanelFactory
				.create(PepLieferantenmanagementPanel.class);
		pepLieferantenmanagementPanel.setName("pepLieferantenmanagementPanel");
	}
	return pepLieferantenmanagementPanel;
}

/**
 * This method initializes projplngFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getProjplngFlowLayoutPane() {
	if (projplngFlowLayoutPane == null) {
		projplngFlowLayoutPane = new RFlowLayoutPane();
		projplngFlowLayoutPane.setName("projplngFlowLayoutPane");
		projplngFlowLayoutPane.setStyle("buttonleiste");
		projplngFlowLayoutPane.add(getReferenzProjektAntragButton());
		projplngFlowLayoutPane.add(getGenehmigenButton());
		projplngFlowLayoutPane.add(getAblehnenButton());
		projplngFlowLayoutPane.add(getOkButton());
		projplngFlowLayoutPane.add(getAbbrechenButton());
	}
	return projplngFlowLayoutPane;
}

/**
 * This method initializes abbrechenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAbbrechenButton() {
	if (abbrechenButton == null) {
		abbrechenButton = new RButton();
		abbrechenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/abbrechen\") %>");
		abbrechenButton.setName("abbrechenButton");
	}
	return abbrechenButton;
}

/**
 * This method initializes okButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getOkButton() {
	if (okButton == null) {
		okButton = new RButton();
		okButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ok\") %>");
		okButton.setName("okButton");
	}
	return okButton;
}

/**
 * This method initializes AblehnenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAblehnenButton() {
	if (AblehnenButton == null) {
		AblehnenButton = new RButton();
		AblehnenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ablehnen\") %>");
		AblehnenButton.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/stop_16\") %>");
		AblehnenButton.setName("AblehnenButton");
	}
	return AblehnenButton;
}

/**
 * This method initializes GenehmigenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getGenehmigenButton() {
	if (GenehmigenButton == null) {
		GenehmigenButton = new RButton();
		GenehmigenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/genehmigen\") %>");
		GenehmigenButton.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/ok_16\") %>");
		GenehmigenButton.setName("GenehmigenButton");
	}
	return GenehmigenButton;
}

/**
 * This method initializes referenzProjektAntragButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getReferenzProjektAntragButton() {
	if (referenzProjektAntragButton == null) {
		referenzProjektAntragButton = new RButton();
		referenzProjektAntragButton.setText("Projekt-Antrag");
		referenzProjektAntragButton.setName("referenzProjektAntragButton");
	}
	return referenzProjektAntragButton;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"