package de.hummel.pep_gui.PepProduktbeschreibung;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.containers.RCardPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RBorderLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;
import ch.ivyteam.ivy.richdialog.widgets.components.RList;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextArea;
import ch.ivyteam.ivy.addons.filemanager.FileManager.FileManagerPanel;
import ch.ivyteam.ivy.richdialog.exec.panel.EmbeddedRichDialog;
import ch.ivyteam.ivy.richdialog.exec.panel.RichDialogPanelFactory;
import com.ulcjava.base.application.ULCContainer;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RTabbedPane;
import com.ulcjava.base.application.util.Color;

/**
 * <p>PepProduktbeschreibungPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepProduktbeschreibungPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel produktbeschreibungLabel = null;
private RLabel produktvarianteLabel = null;
private RCheckBox produktvarianteCheckBox = null;
private RLabel materialLabel = null;
private RTextField materialTextField = null;
private RLabel basisartikelLabel = null;
private RLabel zulassungenLabel = null;
private RLabel sonstigesLabel = null;
private RLabel produktaenderungLabel = null;
private RList zulassungenList = null;
private RTextField basisartikelTextField = null;
private RTextArea sonstigesTextArea = null;
private RScrollPane zertifikateScrollPane1 = null;
private @EmbeddedRichDialog(FileManagerPanel.class) ULCContainer produktbeschreibungfileManagerPanel = null;
private RScrollPane sonstigesScrollPane1 = null;
/**
   * Create a new instance of PepProduktbeschreibungPanel
   */
  public PepProduktbeschreibungPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepProduktbeschreibungPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(880,514));
        this.add(getProduktbeschreibungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProduktvarianteLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProduktvarianteCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMaterialLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMaterialTextField(), new com.ulcjava.base.application.GridBagConstraints(3, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getBasisartikelLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 6, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getZulassungenLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 7, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSonstigesLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 7, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProduktaenderungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getBasisartikelTextField(), new com.ulcjava.base.application.GridBagConstraints(1, 6, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProduktbeschreibungfileManagerPanel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 4, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getZertifikateScrollPane1(), new com.ulcjava.base.application.GridBagConstraints(3, 7, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSonstigesScrollPane1(), new com.ulcjava.base.application.GridBagConstraints(1, 7, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes produktbeschreibungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getProduktbeschreibungLabel() {
	if (produktbeschreibungLabel == null) {
		produktbeschreibungLabel = new RLabel();
		produktbeschreibungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/produktbeschreibung\") %>");
		produktbeschreibungLabel.setStyle("ueberschrift");
		produktbeschreibungLabel.setName("produktbeschreibungLabel");
	}
	return produktbeschreibungLabel;
}

/**
 * This method initializes produktvarianteLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getProduktvarianteLabel() {
	if (produktvarianteLabel == null) {
		produktvarianteLabel = new RLabel();
		produktvarianteLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/produktvariante\") %>");
		produktvarianteLabel.setName("produktvarianteLabel");
	}
	return produktvarianteLabel;
}

/**
 * This method initializes produktvarianteCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getProduktvarianteCheckBox() {
	if (produktvarianteCheckBox == null) {
		produktvarianteCheckBox = new RCheckBox();
		produktvarianteCheckBox.setText("produktvarianteCheckBox");
		produktvarianteCheckBox.setName("produktvarianteCheckBox");
	}
	return produktvarianteCheckBox;
}

/**
 * This method initializes materialLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getMaterialLabel() {
	if (materialLabel == null) {
		materialLabel = new RLabel();
		materialLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/material\") %>");
		materialLabel.setName("materialLabel");
	}
	return materialLabel;
}

/**
 * This method initializes materialTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getMaterialTextField() {
	if (materialTextField == null) {
		materialTextField = new RTextField();
		materialTextField.setText("materialTextField");
		materialTextField.setName("materialTextField");
	}
	return materialTextField;
}

/**
 * This method initializes basisartikelLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getBasisartikelLabel() {
	if (basisartikelLabel == null) {
		basisartikelLabel = new RLabel();
		basisartikelLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/basisartikel\") %>");
		basisartikelLabel.setName("basisartikelLabel");
	}
	return basisartikelLabel;
}

/**
 * This method initializes zulassungenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getZulassungenLabel() {
	if (zulassungenLabel == null) {
		zulassungenLabel = new RLabel();
		zulassungenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/zulassungen\") %>");
		zulassungenLabel.setName("zulassungenLabel");
	}
	return zulassungenLabel;
}

/**
 * This method initializes sonstigesLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getSonstigesLabel() {
	if (sonstigesLabel == null) {
		sonstigesLabel = new RLabel();
		sonstigesLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/sonstiges\") %>");
		sonstigesLabel.setName("sonstigesLabel");
	}
	return sonstigesLabel;
}

/**
 * This method initializes produktaenderungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getProduktaenderungLabel() {
	if (produktaenderungLabel == null) {
		produktaenderungLabel = new RLabel();
		produktaenderungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/produktaenderung\") %>");
		produktaenderungLabel.setStyle("ueberschrift");
		produktaenderungLabel.setName("produktaenderungLabel");
	}
	return produktaenderungLabel;
}

/**
 * This method initializes zulassungenList	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RList	
 */
private RList getZulassungenList() {
	if (zulassungenList == null) {
		zulassungenList = new RList();
		zulassungenList.setName("zulassungenList");
		zulassungenList.setVisibleRowCount(4);
		zulassungenList.setModelConfiguration("{/result \"result=entry\"/version \"3.0\"/icon \"\"/tooltip \"\"}");
	}
	return zulassungenList;
}

/**
 * This method initializes basisartikelTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getBasisartikelTextField() {
	if (basisartikelTextField == null) {
		basisartikelTextField = new RTextField();
		basisartikelTextField.setText("basisartikelTextField");
		basisartikelTextField.setName("basisartikelTextField");
	}
	return basisartikelTextField;
}

/**
 * This method initializes sonstigesTextArea	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextArea	
 */
private RTextArea getSonstigesTextArea() {
	if (sonstigesTextArea == null) {
		sonstigesTextArea = new RTextArea();
		sonstigesTextArea.setText("sonstigesTextArea");
		sonstigesTextArea.setRows(5);
		sonstigesTextArea.setName("sonstigesTextArea");
	}
	return sonstigesTextArea;
}

/**
 * This method initializes zertifikateScrollPane1	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getZertifikateScrollPane1() {
	if (zertifikateScrollPane1 == null) {
		zertifikateScrollPane1 = new RScrollPane();
		zertifikateScrollPane1.setName("zertifikateScrollPane1");
		zertifikateScrollPane1.setStyleProperties("{/fill \"BOTH\"/weightY \"0.1\"/weightX \"1\"}");
		zertifikateScrollPane1.setViewPortView(getZulassungenList());
	}
	return zertifikateScrollPane1;
}

/**
 * This method initializes produktbeschreibungfileManagerPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getProduktbeschreibungfileManagerPanel() {
	if (produktbeschreibungfileManagerPanel == null) {
		produktbeschreibungfileManagerPanel = RichDialogPanelFactory
				.create(FileManagerPanel.class);
		produktbeschreibungfileManagerPanel.setName("produktbeschreibungfileManagerPanel");
		produktbeschreibungfileManagerPanel.setStyleProperties("{/fill \"BOTH\"/weightY \"1\"/weightX \"1\"}");
	}
	return produktbeschreibungfileManagerPanel;
}

/**
 * This method initializes sonstigesScrollPane1	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getSonstigesScrollPane1() {
	if (sonstigesScrollPane1 == null) {
		sonstigesScrollPane1 = new RScrollPane();
		sonstigesScrollPane1.setName("sonstigesScrollPane1");
		sonstigesScrollPane1.setStyle("fill-horiz");
		sonstigesScrollPane1.setPreferredSize(null);
		sonstigesScrollPane1.setStyleProperties("{/fill \"BOTH\"/weightY \"0.1\"}");
		sonstigesScrollPane1.setViewPortView(getSonstigesTextArea());
	}
	return sonstigesScrollPane1;
}
}  //  @jve:decl-index=0:visual-constraint="33,13"