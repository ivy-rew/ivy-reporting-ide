package de.hummel.pep_gui.PepEntwicklungsschritte;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RTextField;

/**
 * <p>PepEntwicklungsschrittePanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepEntwicklungsschrittePanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel projektAnlegenLabel = null;
private RLabel konstruktionLabel = null;
private RLabel risikobewertungLabel = null;
private RCheckBox projektAnlegenCheckBox = null;
private RCheckBox konstruktionCheckBox = null;
private RCheckBox risikobewertungCheckBox = null;
private RLabel prototypLabel = null;
private RLabel erstfertigungLabel = null;
private RLabel serienfreigabeLabel = null;
private RCheckBox prototypCheckBox = null;
private RCheckBox erstfertigungCheckBox = null;
private RCheckBox serienfreigabeCheckBox = null;
private RLabel erstfbegrLabel = null;
private RLabel serienfbegrLabel = null;
private RTextField erstfbTextField = null;
private RTextField serienfbegrTextField = null;
/**
   * Create a new instance of PepEntwicklungsschrittePanel
   */
  public PepEntwicklungsschrittePanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepEntwicklungsschrittePanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(555,115));
        this.add(getProjektAnlegenLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKonstruktionLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getRisikobewertungLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getProjektAnlegenCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKonstruktionCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getRisikobewertungCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPrototypLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getErstfertigungLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSerienfreigabeLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPrototypCheckBox(), new com.ulcjava.base.application.GridBagConstraints(3, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getErstfertigungCheckBox(), new com.ulcjava.base.application.GridBagConstraints(3, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSerienfreigabeCheckBox(), new com.ulcjava.base.application.GridBagConstraints(3, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getErstfbegrLabel(), new com.ulcjava.base.application.GridBagConstraints(4, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSerienfbegrLabel(), new com.ulcjava.base.application.GridBagConstraints(4, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getErstfbTextField(), new com.ulcjava.base.application.GridBagConstraints(5, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSerienfbegrTextField(), new com.ulcjava.base.application.GridBagConstraints(5, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes projektAnlegenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getProjektAnlegenLabel() {
	if (projektAnlegenLabel == null) {
		projektAnlegenLabel = new RLabel();
		projektAnlegenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/projektAnlegen\") %>");
		projektAnlegenLabel.setName("projektAnlegenLabel");
	}
	return projektAnlegenLabel;
}

/**
 * This method initializes konstruktionLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getKonstruktionLabel() {
	if (konstruktionLabel == null) {
		konstruktionLabel = new RLabel();
		konstruktionLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/konstruktion\") %>");
		konstruktionLabel.setName("konstruktionLabel");
	}
	return konstruktionLabel;
}

/**
 * This method initializes risikobewertungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getRisikobewertungLabel() {
	if (risikobewertungLabel == null) {
		risikobewertungLabel = new RLabel();
		risikobewertungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/risikobewertung\") %>");
		risikobewertungLabel.setName("risikobewertungLabel");
	}
	return risikobewertungLabel;
}

/**
 * This method initializes projektAnlegenCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getProjektAnlegenCheckBox() {
	if (projektAnlegenCheckBox == null) {
		projektAnlegenCheckBox = new RCheckBox();
		projektAnlegenCheckBox.setText("");
		projektAnlegenCheckBox.setName("projektAnlegenCheckBox");
	}
	return projektAnlegenCheckBox;
}

/**
 * This method initializes konstruktionCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getKonstruktionCheckBox() {
	if (konstruktionCheckBox == null) {
		konstruktionCheckBox = new RCheckBox();
		konstruktionCheckBox.setText("");
		konstruktionCheckBox.setName("konstruktionCheckBox");
	}
	return konstruktionCheckBox;
}

/**
 * This method initializes risikobewertungCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getRisikobewertungCheckBox() {
	if (risikobewertungCheckBox == null) {
		risikobewertungCheckBox = new RCheckBox();
		risikobewertungCheckBox.setText("");
		risikobewertungCheckBox.setName("risikobewertungCheckBox");
	}
	return risikobewertungCheckBox;
}

/**
 * This method initializes prototypLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getPrototypLabel() {
	if (prototypLabel == null) {
		prototypLabel = new RLabel();
		prototypLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/prototyp\") %>");
		prototypLabel.setName("prototypLabel");
	}
	return prototypLabel;
}

/**
 * This method initializes erstfertigungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getErstfertigungLabel() {
	if (erstfertigungLabel == null) {
		erstfertigungLabel = new RLabel();
		erstfertigungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/erstfertigung\") %>");
		erstfertigungLabel.setName("erstfertigungLabel");
	}
	return erstfertigungLabel;
}

/**
 * This method initializes serienfreigabeLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getSerienfreigabeLabel() {
	if (serienfreigabeLabel == null) {
		serienfreigabeLabel = new RLabel();
		serienfreigabeLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/serienfreigabe\") %>");
		serienfreigabeLabel.setName("serienfreigabeLabel");
	}
	return serienfreigabeLabel;
}

/**
 * This method initializes prototypCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getPrototypCheckBox() {
	if (prototypCheckBox == null) {
		prototypCheckBox = new RCheckBox();
		prototypCheckBox.setText("");
		prototypCheckBox.setName("prototypCheckBox");
	}
	return prototypCheckBox;
}

/**
 * This method initializes erstfertigungCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getErstfertigungCheckBox() {
	if (erstfertigungCheckBox == null) {
		erstfertigungCheckBox = new RCheckBox();
		erstfertigungCheckBox.setText("");
		erstfertigungCheckBox.setName("erstfertigungCheckBox");
	}
	return erstfertigungCheckBox;
}

/**
 * This method initializes serienfreigabeCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getSerienfreigabeCheckBox() {
	if (serienfreigabeCheckBox == null) {
		serienfreigabeCheckBox = new RCheckBox();
		serienfreigabeCheckBox.setText("");
		serienfreigabeCheckBox.setName("serienfreigabeCheckBox");
	}
	return serienfreigabeCheckBox;
}

/**
 * This method initializes erstfbegrLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getErstfbegrLabel() {
	if (erstfbegrLabel == null) {
		erstfbegrLabel = new RLabel();
		erstfbegrLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/begruendung\") %>");
		erstfbegrLabel.setName("erstfbegrLabel");
	}
	return erstfbegrLabel;
}

/**
 * This method initializes serienfbegrLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getSerienfbegrLabel() {
	if (serienfbegrLabel == null) {
		serienfbegrLabel = new RLabel();
		serienfbegrLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/begruendung\") %>");
		serienfbegrLabel.setName("serienfbegrLabel");
	}
	return serienfbegrLabel;
}

/**
 * This method initializes erstfbTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getErstfbTextField() {
	if (erstfbTextField == null) {
		erstfbTextField = new RTextField();
		erstfbTextField.setText("erstfbTextField");
		erstfbTextField.setName("erstfbTextField");
	}
	return erstfbTextField;
}

/**
 * This method initializes serienfbegrTextField	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RTextField	
 */
private RTextField getSerienfbegrTextField() {
	if (serienfbegrTextField == null) {
		serienfbegrTextField = new RTextField();
		serienfbegrTextField.setText("serienfbegrTextField");
		serienfbegrTextField.setName("serienfbegrTextField");
	}
	return serienfbegrTextField;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"