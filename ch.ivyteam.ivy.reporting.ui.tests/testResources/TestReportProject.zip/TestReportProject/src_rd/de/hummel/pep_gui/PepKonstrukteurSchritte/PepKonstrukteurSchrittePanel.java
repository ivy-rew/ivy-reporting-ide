package de.hummel.pep_gui.PepKonstrukteurSchritte;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RComboBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import com.ulcjava.base.application.event.KeyEvent;

/**
 * <p>PepKonstrukteurSchrittePanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepKonstrukteurSchrittePanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel LabelKonstrukteurSchritte = null;
private RLabel LabelKundenfreigabe = null;
private RLabel LabelMuster = null;
private RLabel LabelWerkzeug = null;
private RLabel LabelSchutzfaehigeAspekte = null;
private RCheckBox CheckBoxKundenfreigabe = null;
private RCheckBox CheckBoxMuster = null;
private RCheckBox CheckBoxWerkzeug = null;
private RCheckBox CheckBoxSchutzfaehigeAspekte = null;
private RLabel LabelKonstrukteur = null;
private RComboBox ComboBoxKonstrukteur = null;
private RButton ButtonOk = null;
  
  /**
   * Create a new instance of PepKonstrukteurSchrittePanel
   */
  public PepKonstrukteurSchrittePanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepKonstrukteurSchrittePanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(481,317));
        this.add(getLabelKonstrukteurSchritte(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLabelKundenfreigabe(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLabelMuster(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLabelWerkzeug(), new com.ulcjava.base.application.GridBagConstraints(2, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLabelSchutzfaehigeAspekte(), new com.ulcjava.base.application.GridBagConstraints(2, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getCheckBoxKundenfreigabe(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getCheckBoxMuster(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getCheckBoxWerkzeug(), new com.ulcjava.base.application.GridBagConstraints(3, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getCheckBoxSchutzfaehigeAspekte(), new com.ulcjava.base.application.GridBagConstraints(3, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLabelKonstrukteur(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getComboBoxKonstrukteur(), new com.ulcjava.base.application.GridBagConstraints(1, 4, 3, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getButtonOk(), new com.ulcjava.base.application.GridBagConstraints(3, 5, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes LabelKonstrukteurSchritte	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLabelKonstrukteurSchritte() {
	if (LabelKonstrukteurSchritte == null) {
		LabelKonstrukteurSchritte = new RLabel();
		LabelKonstrukteurSchritte.setText("Konstrukteur und Schritte ermitteln");
		LabelKonstrukteurSchritte.setName("LabelKonstrukteurSchritte");
	}
	return LabelKonstrukteurSchritte;
}

/**
 * This method initializes LabelKundenfreigabe	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLabelKundenfreigabe() {
	if (LabelKundenfreigabe == null) {
		LabelKundenfreigabe = new RLabel();
		LabelKundenfreigabe.setText("Kundenfreigabe");
		LabelKundenfreigabe.setEnabled(false);
		LabelKundenfreigabe.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
		LabelKundenfreigabe.setName("LabelKundenfreigabe");
	}
	return LabelKundenfreigabe;
}

/**
 * This method initializes LabelMuster	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLabelMuster() {
	if (LabelMuster == null) {
		LabelMuster = new RLabel();
		LabelMuster.setText("Muster");
		LabelMuster.setName("LabelMuster");
	}
	return LabelMuster;
}

/**
 * This method initializes LabelWerkzeug	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLabelWerkzeug() {
	if (LabelWerkzeug == null) {
		LabelWerkzeug = new RLabel();
		LabelWerkzeug.setText("Werkzeug");
		LabelWerkzeug.setName("LabelWerkzeug");
	}
	return LabelWerkzeug;
}

/**
 * This method initializes LabelSchutzfaehigeAspekte	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLabelSchutzfaehigeAspekte() {
	if (LabelSchutzfaehigeAspekte == null) {
		LabelSchutzfaehigeAspekte = new RLabel();
		LabelSchutzfaehigeAspekte.setText("Schutzf�hige Aspekte");
		LabelSchutzfaehigeAspekte.setName("LabelSchutzfaehigeAspekte");
	}
	return LabelSchutzfaehigeAspekte;
}

/**
 * This method initializes CheckBoxKundenfreigabe	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getCheckBoxKundenfreigabe() {
	if (CheckBoxKundenfreigabe == null) {
		CheckBoxKundenfreigabe = new RCheckBox();
		CheckBoxKundenfreigabe.setText("");
		CheckBoxKundenfreigabe.setEnabled(false);
		CheckBoxKundenfreigabe.setName("CheckBoxKundenfreigabe");
	}
	return CheckBoxKundenfreigabe;
}

/**
 * This method initializes CheckBoxMuster	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getCheckBoxMuster() {
	if (CheckBoxMuster == null) {
		CheckBoxMuster = new RCheckBox();
		CheckBoxMuster.setText("");
		CheckBoxMuster.setName("CheckBoxMuster");
	}
	return CheckBoxMuster;
}

/**
 * This method initializes CheckBoxWerkzeug	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getCheckBoxWerkzeug() {
	if (CheckBoxWerkzeug == null) {
		CheckBoxWerkzeug = new RCheckBox();
		CheckBoxWerkzeug.setText("");
		CheckBoxWerkzeug.setName("CheckBoxWerkzeug");
	}
	return CheckBoxWerkzeug;
}

/**
 * This method initializes CheckBoxSchutzfaehigeAspekte	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getCheckBoxSchutzfaehigeAspekte() {
	if (CheckBoxSchutzfaehigeAspekte == null) {
		CheckBoxSchutzfaehigeAspekte = new RCheckBox();
		CheckBoxSchutzfaehigeAspekte.setText("");
		CheckBoxSchutzfaehigeAspekte.setName("CheckBoxSchutzfaehigeAspekte");
	}
	return CheckBoxSchutzfaehigeAspekte;
}

/**
 * This method initializes LabelKonstrukteur	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLabelKonstrukteur() {
	if (LabelKonstrukteur == null) {
		LabelKonstrukteur = new RLabel();
		LabelKonstrukteur.setText("Konstrukteur");
		LabelKonstrukteur.setName("LabelKonstrukteur");
	}
	return LabelKonstrukteur;
}

/**
 * This method initializes ComboBoxKonstrukteur	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RComboBox	
 */
private RComboBox getComboBoxKonstrukteur() {
	if (ComboBoxKonstrukteur == null) {
		ComboBoxKonstrukteur = new RComboBox();
		ComboBoxKonstrukteur.setName("ComboBoxKonstrukteur");
		ComboBoxKonstrukteur.setModelConfiguration("{/result \"result=entry.getName()\"/version \"3.0\"/icon \"\"/tooltip \"\"}");
	}
	return ComboBoxKonstrukteur;
}

/**
 * This method initializes ButtonOk	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getButtonOk() {
	if (ButtonOk == null) {
		ButtonOk = new RButton();
		ButtonOk.setText("OK");
		ButtonOk.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/ok_16\") %>");
		ButtonOk.setName("ButtonOk");
	}
	return ButtonOk;
}
}  //  @jve:decl-index=0:visual-constraint="14,-28"