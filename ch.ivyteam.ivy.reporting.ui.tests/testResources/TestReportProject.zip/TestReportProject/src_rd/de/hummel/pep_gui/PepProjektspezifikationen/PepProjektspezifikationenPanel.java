package de.hummel.pep_gui.PepProjektspezifikationen;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RFiller;

/**
 * <p>PepProjektspezifikationenPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepProjektspezifikationenPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel kundenfreigabeLabel = null;
private RLabel lastenheftLabel = null;
private RLabel pflichtenheftLabel = null;
private RLabel konzeptLabel = null;
private RCheckBox kundenfreigabeCheckBox = null;
private RCheckBox lastenheftCheckBox = null;
private RCheckBox pflichtenheftCheckBox = null;
private RCheckBox konzeptCheckBox = null;
private RLabel fmeaLabel = null;
private RLabel atexProduktLabel = null;
private RLabel medizinProduktLabel = null;
private RCheckBox fmeaCheckBox = null;
private RCheckBox atexProduktCheckBox = null;
private RCheckBox medizinProduktCheckBox = null;
private RLabel swEntwLabel = null;
private RLabel mechEntwLabel = null;
private RLabel elentwLabel = null;
private RCheckBox swEntwCheckBox = null;
private RCheckBox mechEntwCheckBox = null;
private RCheckBox elEntwCheckBox = null;
/**
   * Create a new instance of PepProjektspezifikationenPanel
   */
  public PepProjektspezifikationenPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepProjektspezifikationenPanel
   * @return void
   */
  private void initialize()
  {
        RFiller Filler = new RFiller();
        Filler.setStyle("fill-horiz-north");
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(530,149));
        this.add(getKundenfreigabeLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLastenheftLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPflichtenheftLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKonzeptLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKundenfreigabeCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getLastenheftCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPflichtenheftCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getKonzeptCheckBox(), new com.ulcjava.base.application.GridBagConstraints(1, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getFmeaLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAtexProduktLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMedizinProduktLabel(), new com.ulcjava.base.application.GridBagConstraints(2, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getFmeaCheckBox(), new com.ulcjava.base.application.GridBagConstraints(3, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getAtexProduktCheckBox(), new com.ulcjava.base.application.GridBagConstraints(3, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMedizinProduktCheckBox(), new com.ulcjava.base.application.GridBagConstraints(3, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSwEntwLabel(), new com.ulcjava.base.application.GridBagConstraints(4, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMechEntwLabel(), new com.ulcjava.base.application.GridBagConstraints(4, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getElentwLabel(), new com.ulcjava.base.application.GridBagConstraints(4, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getSwEntwCheckBox(), new com.ulcjava.base.application.GridBagConstraints(5, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getMechEntwCheckBox(), new com.ulcjava.base.application.GridBagConstraints(5, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getElEntwCheckBox(), new com.ulcjava.base.application.GridBagConstraints(5, 3, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(Filler, new com.ulcjava.base.application.GridBagConstraints(6, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes kundenfreigabeLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getKundenfreigabeLabel() {
	if (kundenfreigabeLabel == null) {
		kundenfreigabeLabel = new RLabel();
		kundenfreigabeLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/kundenfreigabe\") %>");
		kundenfreigabeLabel.setName("kundenfreigabeLabel");
	}
	return kundenfreigabeLabel;
}

/**
 * This method initializes lastenheftLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getLastenheftLabel() {
	if (lastenheftLabel == null) {
		lastenheftLabel = new RLabel();
		lastenheftLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/lastenheft\") %>");
		lastenheftLabel.setName("lastenheftLabel");
	}
	return lastenheftLabel;
}

/**
 * This method initializes pflichtenheftLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getPflichtenheftLabel() {
	if (pflichtenheftLabel == null) {
		pflichtenheftLabel = new RLabel();
		pflichtenheftLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/pflichtenheft\") %>");
		pflichtenheftLabel.setName("pflichtenheftLabel");
	}
	return pflichtenheftLabel;
}

/**
 * This method initializes konzeptLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getKonzeptLabel() {
	if (konzeptLabel == null) {
		konzeptLabel = new RLabel();
		konzeptLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/konzept\") %>");
		konzeptLabel.setName("konzeptLabel");
	}
	return konzeptLabel;
}

/**
 * This method initializes kundenfreigabeCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getKundenfreigabeCheckBox() {
	if (kundenfreigabeCheckBox == null) {
		kundenfreigabeCheckBox = new RCheckBox();
		kundenfreigabeCheckBox.setText("");
		kundenfreigabeCheckBox.setName("kundenfreigabeCheckBox");
	}
	return kundenfreigabeCheckBox;
}

/**
 * This method initializes lastenheftCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getLastenheftCheckBox() {
	if (lastenheftCheckBox == null) {
		lastenheftCheckBox = new RCheckBox();
		lastenheftCheckBox.setText("");
		lastenheftCheckBox.setName("lastenheftCheckBox");
	}
	return lastenheftCheckBox;
}

/**
 * This method initializes pflichtenheftCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getPflichtenheftCheckBox() {
	if (pflichtenheftCheckBox == null) {
		pflichtenheftCheckBox = new RCheckBox();
		pflichtenheftCheckBox.setText("");
		pflichtenheftCheckBox.setName("pflichtenheftCheckBox");
	}
	return pflichtenheftCheckBox;
}

/**
 * This method initializes konzeptCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getKonzeptCheckBox() {
	if (konzeptCheckBox == null) {
		konzeptCheckBox = new RCheckBox();
		konzeptCheckBox.setText("");
		konzeptCheckBox.setName("konzeptCheckBox");
	}
	return konzeptCheckBox;
}

/**
 * This method initializes fmeaLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getFmeaLabel() {
	if (fmeaLabel == null) {
		fmeaLabel = new RLabel();
		fmeaLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/fmea\") %>");
		fmeaLabel.setName("fmeaLabel");
	}
	return fmeaLabel;
}

/**
 * This method initializes atexProduktLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getAtexProduktLabel() {
	if (atexProduktLabel == null) {
		atexProduktLabel = new RLabel();
		atexProduktLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/atexProdukt\") %>");
		atexProduktLabel.setName("atexProduktLabel");
	}
	return atexProduktLabel;
}

/**
 * This method initializes medizinProduktLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getMedizinProduktLabel() {
	if (medizinProduktLabel == null) {
		medizinProduktLabel = new RLabel();
		medizinProduktLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/medizinprodukt\") %>");
		medizinProduktLabel.setName("medizinProduktLabel");
	}
	return medizinProduktLabel;
}

/**
 * This method initializes fmeaCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getFmeaCheckBox() {
	if (fmeaCheckBox == null) {
		fmeaCheckBox = new RCheckBox();
		fmeaCheckBox.setText("");
		fmeaCheckBox.setName("fmeaCheckBox");
	}
	return fmeaCheckBox;
}

/**
 * This method initializes atexProduktCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getAtexProduktCheckBox() {
	if (atexProduktCheckBox == null) {
		atexProduktCheckBox = new RCheckBox();
		atexProduktCheckBox.setText("");
		atexProduktCheckBox.setName("atexProduktCheckBox");
	}
	return atexProduktCheckBox;
}

/**
 * This method initializes medizinProduktCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getMedizinProduktCheckBox() {
	if (medizinProduktCheckBox == null) {
		medizinProduktCheckBox = new RCheckBox();
		medizinProduktCheckBox.setText("");
		medizinProduktCheckBox.setName("medizinProduktCheckBox");
	}
	return medizinProduktCheckBox;
}

/**
 * This method initializes swEntwLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getSwEntwLabel() {
	if (swEntwLabel == null) {
		swEntwLabel = new RLabel();
		swEntwLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/swEntw\") %>");
		swEntwLabel.setName("swEntwLabel");
	}
	return swEntwLabel;
}

/**
 * This method initializes mechEntwLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getMechEntwLabel() {
	if (mechEntwLabel == null) {
		mechEntwLabel = new RLabel();
		mechEntwLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/mechEntw\") %>");
		mechEntwLabel.setName("mechEntwLabel");
	}
	return mechEntwLabel;
}

/**
 * This method initializes elentwLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getElentwLabel() {
	if (elentwLabel == null) {
		elentwLabel = new RLabel();
		elentwLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/elEntw\") %>");
		elentwLabel.setName("elentwLabel");
	}
	return elentwLabel;
}

/**
 * This method initializes swEntwCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getSwEntwCheckBox() {
	if (swEntwCheckBox == null) {
		swEntwCheckBox = new RCheckBox();
		swEntwCheckBox.setText("");
		swEntwCheckBox.setName("swEntwCheckBox");
	}
	return swEntwCheckBox;
}

/**
 * This method initializes mechEntwCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getMechEntwCheckBox() {
	if (mechEntwCheckBox == null) {
		mechEntwCheckBox = new RCheckBox();
		mechEntwCheckBox.setText("");
		mechEntwCheckBox.setName("mechEntwCheckBox");
	}
	return mechEntwCheckBox;
}

/**
 * This method initializes elEntwCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getElEntwCheckBox() {
	if (elEntwCheckBox == null) {
		elEntwCheckBox = new RCheckBox();
		elEntwCheckBox.setText("");
		elEntwCheckBox.setName("elEntwCheckBox");
	}
	return elEntwCheckBox;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"