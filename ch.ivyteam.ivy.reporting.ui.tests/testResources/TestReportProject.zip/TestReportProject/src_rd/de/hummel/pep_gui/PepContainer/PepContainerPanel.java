package de.hummel.pep_gui.PepContainer;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogGridBagPanel;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPaneContainer;
import ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane;
import de.hummel.allgemein.gui.Ablehnung.AblehnungPanel;
import de.hummel.pep_gui.PepKopfdaten.PepKopfdatenPanel;
import ch.ivyteam.ivy.richdialog.exec.panel.EmbeddedRichDialog;
import ch.ivyteam.ivy.richdialog.exec.panel.RichDialogPanelFactory;
import com.ulcjava.base.application.ULCContainer;
import de.hummel.pep_gui.PepTerminPreis.PepTerminPreisPanel;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.components.RBrowser;
import ch.ivyteam.ivy.richdialog.widgets.components.RTree;
import ch.ivyteam.ivy.richdialog.widgets.containers.RToolBar;
import de.hummel.pep_gui.PepProduktbeschreibung.PepProduktbeschreibungPanel;
import de.hummel.pep_gui.PepMarktChancen.PepMarktChancenPanel;
import de.hummel.pep_gui.PepAufwand.PepAufwandPanel;
import de.hummel.allgemein.gui.Genehmigung.GenehmigungPanel;
import de.hummel.pep_gui.PepProzessKette.PepProzessKettePanel;

/**
 * <p>PepContainerPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepContainerPanel extends RichDialogGridBagPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RLabel HeaderLabel = null;
private RScrollPane containerScrollPane = null;
private RTaskPaneContainer entwicklungsantragTaskPaneContainer = null;
private RTaskPane kopfdatenTaskPane = null;
private RTaskPane terminPreisTaskPane = null;
private @EmbeddedRichDialog(PepKopfdatenPanel.class) ULCContainer pepKopfdatenPanel = null;
private @EmbeddedRichDialog(PepTerminPreisPanel.class) ULCContainer pepTerminPreisPanel = null;
private RFlowLayoutPane buttonFlowLayoutPane = null;
private RButton einreichenButton = null;
private RButton wiedervorlageButton = null;
private RButton genehmigenButton = null;
private RButton ablehnenButton = null;
private RButton abbrechenButton = null;
private RTaskPane produktbeschreibungTaskPane = null;
private @EmbeddedRichDialog(PepProduktbeschreibungPanel.class) ULCContainer pepProduktbeschreibungPanel = null;
private RTaskPane marktNutzenTaskPane = null;
private @EmbeddedRichDialog(PepMarktChancenPanel.class) ULCContainer pepMarktChancenPanel = null;
private RTaskPane aufwandTaskPane = null;
private @EmbeddedRichDialog(PepAufwandPanel.class) ULCContainer aufwandpepAufwandPanel = null;
private RButton okButton = null;
private RTaskPane gehnemigtTaskPane = null;
private RTaskPane abgelehntTaskPane = null;
private @EmbeddedRichDialog(GenehmigungPanel.class) ULCContainer genehmigungPanel = null;
private @EmbeddedRichDialog(AblehnungPanel.class) ULCContainer ablehnungPanel = null;
private @EmbeddedRichDialog(PepProzessKettePanel.class) ULCContainer pepProzessKettePanel = null;
/**
   * Create a new instance of PepContainerPanel
   */
  public PepContainerPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepContainerPanel
   * @return void
   */
  private void initialize()
  {
        this.setStyleProperties(null);
        this.add(getHeaderLabel(), new com.ulcjava.base.application.GridBagConstraints(0, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getContainerScrollPane(), new com.ulcjava.base.application.GridBagConstraints(0, 2, 1, 2, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getPepProzessKettePanel(), new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
        this.add(getButtonFlowLayoutPane(), new com.ulcjava.base.application.GridBagConstraints(0, 4, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
  }

/**
 * This method initializes HeaderLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getHeaderLabel() {
	if (HeaderLabel == null) {
		HeaderLabel = new RLabel();
		HeaderLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/entwicklungsantrag\") %>");
		HeaderLabel.setStyle("kopf");
		HeaderLabel.setName("HeaderLabel");
	}
	return HeaderLabel;
}

/**
 * This method initializes containerScrollPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RScrollPane	
 */
private RScrollPane getContainerScrollPane() {
	if (containerScrollPane == null) {
		containerScrollPane = new RScrollPane();
		containerScrollPane.setName("containerScrollPane");
		containerScrollPane.setStyle("fill-both");
		containerScrollPane.setName("containerScrollPane");
		containerScrollPane.setViewPortView(getEntwicklungsantragTaskPaneContainer());
	}
	return containerScrollPane;
}

/**
 * This method initializes entwicklungsantragTaskPaneContainer	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPaneContainer	
 */
private RTaskPaneContainer getEntwicklungsantragTaskPaneContainer() {
	if (entwicklungsantragTaskPaneContainer == null) {
		entwicklungsantragTaskPaneContainer = new RTaskPaneContainer();
		entwicklungsantragTaskPaneContainer.setName("entwicklungsantragTaskPaneContainer");
		entwicklungsantragTaskPaneContainer.setStyle("fill-both");
		entwicklungsantragTaskPaneContainer.setName("entwicklungsantragTaskPaneContainer");
		entwicklungsantragTaskPaneContainer.add(getKopfdatenTaskPane());
		entwicklungsantragTaskPaneContainer.add(getTerminPreisTaskPane());
		entwicklungsantragTaskPaneContainer.add(getProduktbeschreibungTaskPane());
		entwicklungsantragTaskPaneContainer.add(getMarktNutzenTaskPane());
		entwicklungsantragTaskPaneContainer.add(getAufwandTaskPane());
		entwicklungsantragTaskPaneContainer.add(getGehnemigtTaskPane());
		entwicklungsantragTaskPaneContainer.add(getAbgelehntTaskPane());
	}
	return entwicklungsantragTaskPaneContainer;
}

/**
 * This method initializes kopfdatenTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getKopfdatenTaskPane() {
	if (kopfdatenTaskPane == null) {
		kopfdatenTaskPane = new RTaskPane();
		kopfdatenTaskPane.setName("kopfdatenTaskPane");
		kopfdatenTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/kopfdaten\") %>");
		kopfdatenTaskPane.add(getPepKopfdatenPanel());
	}
	return kopfdatenTaskPane;
}

/**
 * This method initializes terminPreisTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getTerminPreisTaskPane() {
	if (terminPreisTaskPane == null) {
		terminPreisTaskPane = new RTaskPane();
		terminPreisTaskPane.setName("terminPreisTaskPane");
		terminPreisTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/terminPreis\") %>");
		terminPreisTaskPane.add(getPepTerminPreisPanel());
	}
	return terminPreisTaskPane;
}

/**
 * This method initializes pepKopfdatenPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepKopfdatenPanel() {
	if (pepKopfdatenPanel == null) {
		pepKopfdatenPanel = RichDialogPanelFactory
				.create(PepKopfdatenPanel.class);
		pepKopfdatenPanel.setName("pepKopfdatenPanel");
		pepKopfdatenPanel.setName("pepKopfdatenPanel");
	}
	return pepKopfdatenPanel;
}

/**
 * This method initializes pepTerminPreisPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepTerminPreisPanel() {
	if (pepTerminPreisPanel == null) {
		pepTerminPreisPanel = RichDialogPanelFactory
				.create(PepTerminPreisPanel.class);
		pepTerminPreisPanel.setName("pepTerminPreisPanel");
		pepTerminPreisPanel.setToolTipText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/produktbeschreibung\") %>");
		pepTerminPreisPanel.setName("pepTerminPreisPanel");
	}
	return pepTerminPreisPanel;
}

/**
 * This method initializes buttonFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getButtonFlowLayoutPane() {
	if (buttonFlowLayoutPane == null) {
		buttonFlowLayoutPane = new RFlowLayoutPane();
		buttonFlowLayoutPane.setName("buttonFlowLayoutPane");
		buttonFlowLayoutPane.setStyle("buttonleiste");
		buttonFlowLayoutPane.add(getOkButton());
		buttonFlowLayoutPane.setName("buttonFlowLayoutPane");
		buttonFlowLayoutPane.add(getAbbrechenButton());
		buttonFlowLayoutPane.add(getAblehnenButton());
		buttonFlowLayoutPane.add(getGenehmigenButton());
		buttonFlowLayoutPane.add(getWiedervorlageButton());
		buttonFlowLayoutPane.add(getEinreichenButton());
	}
	return buttonFlowLayoutPane;
}

/**
 * This method initializes einreichenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getEinreichenButton() {
	if (einreichenButton == null) {
		einreichenButton = new RButton();
		einreichenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/einreichen\") %>");
		einreichenButton.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/ok_16\") %>");
		einreichenButton.setName("einreichenButton");
	}
	return einreichenButton;
}

/**
 * This method initializes wiedervorlageButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getWiedervorlageButton() {
	if (wiedervorlageButton == null) {
		wiedervorlageButton = new RButton();
		wiedervorlageButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/wiedervorlage\") %>");
		wiedervorlageButton.setName("wiedervorlageButton");
	}
	return wiedervorlageButton;
}

/**
 * This method initializes genehmigenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getGenehmigenButton() {
	if (genehmigenButton == null) {
		genehmigenButton = new RButton();
		genehmigenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/genehmigen\") %>");
		genehmigenButton.setIconUri("<%= ivy.cms.cr(\"/ch/ivyteam/ivy/addons/commonicons/General/hot/16/ok_16\") %>");
		genehmigenButton.setName("genehmigenButton");
	}
	return genehmigenButton;
}

/**
 * This method initializes ablehnenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAblehnenButton() {
	if (ablehnenButton == null) {
		ablehnenButton = new RButton();
		ablehnenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ablehnen\") %>");
		ablehnenButton.setName("ablehnenButton");
	}
	return ablehnenButton;
}

/**
 * This method initializes abbrechenButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAbbrechenButton() {
	if (abbrechenButton == null) {
		abbrechenButton = new RButton();
		abbrechenButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/abbrechen\") %>");
		abbrechenButton.setName("abbrechenButton");
	}
	return abbrechenButton;
}

/**
 * This method initializes produktbeschreibungTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getProduktbeschreibungTaskPane() {
	if (produktbeschreibungTaskPane == null) {
		produktbeschreibungTaskPane = new RTaskPane();
		produktbeschreibungTaskPane.setName("produktbeschreibungTaskPane");
		produktbeschreibungTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/produktbeschreibung\") %>");
		produktbeschreibungTaskPane.add(getPepProduktbeschreibungPanel());
	}
	return produktbeschreibungTaskPane;
}

/**
 * This method initializes pepProduktbeschreibungPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepProduktbeschreibungPanel() {
	if (pepProduktbeschreibungPanel == null) {
		pepProduktbeschreibungPanel = RichDialogPanelFactory
				.create(PepProduktbeschreibungPanel.class);
		pepProduktbeschreibungPanel.setName("pepProduktbeschreibungPanel");
	}
	return pepProduktbeschreibungPanel;
}

/**
 * This method initializes marktNutzenTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getMarktNutzenTaskPane() {
	if (marktNutzenTaskPane == null) {
		marktNutzenTaskPane = new RTaskPane();
		marktNutzenTaskPane.setName("marktNutzenTaskPane");
		marktNutzenTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/potenzial\") %>");
		marktNutzenTaskPane.add(getPepMarktChancenPanel());
	}
	return marktNutzenTaskPane;
}

/**
 * This method initializes pepMarktChancenPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepMarktChancenPanel() {
	if (pepMarktChancenPanel == null) {
		pepMarktChancenPanel = RichDialogPanelFactory
				.create(PepMarktChancenPanel.class);
		pepMarktChancenPanel.setName("pepMarktChancenPanel");
	}
	return pepMarktChancenPanel;
}

/**
 * This method initializes aufwandTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getAufwandTaskPane() {
	if (aufwandTaskPane == null) {
		aufwandTaskPane = new RTaskPane();
		aufwandTaskPane.setName("aufwandTaskPane");
		aufwandTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/aufwandsabschaetzung\") %>");
		aufwandTaskPane.add(getAufwandpepAufwandPanel());
	}
	return aufwandTaskPane;
}

/**
 * This method initializes aufwandpepAufwandPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getAufwandpepAufwandPanel() {
	if (aufwandpepAufwandPanel == null) {
		aufwandpepAufwandPanel = RichDialogPanelFactory
				.create(PepAufwandPanel.class);
		aufwandpepAufwandPanel.setName("aufwandpepAufwandPanel");
	}
	return aufwandpepAufwandPanel;
}

/**
 * This method initializes okButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getOkButton() {
	if (okButton == null) {
		okButton = new RButton();
		okButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ok\") %>");
		okButton.setName("okButton");
	}
	return okButton;
}

/**
 * This method initializes gehnemigtTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getGehnemigtTaskPane() {
	if (gehnemigtTaskPane == null) {
		gehnemigtTaskPane = new RTaskPane();
		gehnemigtTaskPane.setName("gehnemigtTaskPane");
		gehnemigtTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/genehmigung\") %>");
		gehnemigtTaskPane.add(getGenehmigungPanel());
	}
	return gehnemigtTaskPane;
}

/**
 * This method initializes abgelehntTaskPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RTaskPane	
 */
private RTaskPane getAbgelehntTaskPane() {
	if (abgelehntTaskPane == null) {
		abgelehntTaskPane = new RTaskPane();
		abgelehntTaskPane.setName("abgelehntTaskPane");
		abgelehntTaskPane.setTitle("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/ablehnung\") %>");
		abgelehntTaskPane.add(getAblehnungPanel());
	}
	return abgelehntTaskPane;
}

/**
 * This method initializes genehmigungPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getGenehmigungPanel() {
	if (genehmigungPanel == null) {
		genehmigungPanel = RichDialogPanelFactory
				.create(GenehmigungPanel.class);
		genehmigungPanel.setName("genehmigungPanel");
	}
	return genehmigungPanel;
}

/**
 * This method initializes ablehnungPanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getAblehnungPanel() {
	if (ablehnungPanel == null) {
		ablehnungPanel = RichDialogPanelFactory.create(AblehnungPanel.class);
		ablehnungPanel.setName("ablehnungPanel");
	}
	return ablehnungPanel;
}

/**
 * This method initializes pepProzessKettePanel, an embedded RichDialog.
 * The created object might have a different type than the declared
 * class due to overriding.
 * @returns com.ulcjava.base.application.ULCContainer 
 */
private ULCContainer getPepProzessKettePanel() {
	if (pepProzessKettePanel == null) {
		pepProzessKettePanel = RichDialogPanelFactory
				.create(PepProzessKettePanel.class);
		pepProzessKettePanel.setName("pepProzessKettePanel");
	}
	return pepProzessKettePanel;
}
}  //  @jve:decl-index=0:visual-constraint="9,11"