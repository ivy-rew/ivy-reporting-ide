package de.hummel.pep_gui.PepSerienSpezifikationen;

import ch.ivyteam.ivy.richdialog.exec.panel.IRichDialogPanel;
import ch.ivyteam.ivy.richdialog.rdpanels.RichDialogBorderPanel;
import ch.ivyteam.ivy.richdialog.widgets.containers.RGridBagLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane;
import ch.ivyteam.ivy.richdialog.widgets.components.RLabel;
import ch.ivyteam.ivy.richdialog.widgets.components.RButton;
import ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox;
import ch.ivyteam.ivy.richdialog.widgets.components.RFiller;

/**
 * <p>PepSerienSpezifikationenPanel is a rich dialog panel implementation.
 *
 * <p>Please note that a rich dialog panel is not an instance of a Swing 
 * container, but of an ULCContainer. As such it can not be run 
 * or instantiated outside the ULC framework.
 */
@SuppressWarnings("all")
public class PepSerienSpezifikationenPanel extends RichDialogBorderPanel 
implements IRichDialogPanel 
{ 
  /** Serial version id */
  private static final long serialVersionUID = 1L;
private RGridBagLayoutPane serienspezifikationGridBagLayoutPane = null;
private RFlowLayoutPane serienspezifikationFlowLayoutPane = null;
private RLabel serienspezifikationAbarbeitenLabel = null;
private RButton okButton = null;
private RCheckBox werkzeugCheckBox = null;
private RLabel geraetezertifizierungLabel = null;
private RLabel kundenfreigabeLabel = null;
private RCheckBox geraetezertifizierungCheckBox = null;
private RCheckBox kundenfreigabeCheckBox = null;
private RLabel erstfertigungLabel = null;
private RLabel risikobewertungLabel = null;
private RCheckBox erstfertigungCheckBox = null;
private RLabel werkzeugLabel = null;
private RCheckBox risikobewertungCheckBox = null;
private RButton projektButton = null;
private RButton antragButton = null;
/**
   * Create a new instance of PepSerienSpezifikationenPanel
   */
  public PepSerienSpezifikationenPanel()
  {
    super();
    initialize();
  }
  
  /**
   * This method initializes PepSerienSpezifikationenPanel
   * @return void
   */
  private void initialize()
  {
        this.setPreferredSize(new com.ulcjava.base.application.util.Dimension(604,204));
        this.add(getSerienspezifikationAbarbeitenLabel(), com.ulcjava.base.application.ULCBorderLayoutPane.NORTH);
        this.add(getSerienspezifikationFlowLayoutPane(), com.ulcjava.base.application.ULCBorderLayoutPane.SOUTH);
        this.add(getSerienspezifikationGridBagLayoutPane(), com.ulcjava.base.application.ULCBorderLayoutPane.CENTER);
  }

/**
 * This method initializes serienspezifikationGridBagLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RGridBagLayoutPane	
 */
private RGridBagLayoutPane getSerienspezifikationGridBagLayoutPane() {
	if (serienspezifikationGridBagLayoutPane == null) {
		RFiller leftFiller = new RFiller();
		RFiller serienspezifikationFiller = new RFiller();
		serienspezifikationFiller.setStyle("fill-horiz-north");
		serienspezifikationGridBagLayoutPane = new RGridBagLayoutPane();
		serienspezifikationGridBagLayoutPane.setName("serienspezifikationGridBagLayoutPane");
		serienspezifikationGridBagLayoutPane.add(getWerkzeugCheckBox(), new com.ulcjava.base.application.GridBagConstraints(2, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getGeraetezertifizierungLabel(), new com.ulcjava.base.application.GridBagConstraints(1, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getKundenfreigabeLabel(), new com.ulcjava.base.application.GridBagConstraints(1, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getGeraetezertifizierungCheckBox(), new com.ulcjava.base.application.GridBagConstraints(2, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getKundenfreigabeCheckBox(), new com.ulcjava.base.application.GridBagConstraints(2, 2, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getErstfertigungLabel(), new com.ulcjava.base.application.GridBagConstraints(3, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getRisikobewertungLabel(), new com.ulcjava.base.application.GridBagConstraints(3, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getErstfertigungCheckBox(), new com.ulcjava.base.application.GridBagConstraints(4, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getWerkzeugLabel(), new com.ulcjava.base.application.GridBagConstraints(1, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(getRisikobewertungCheckBox(), new com.ulcjava.base.application.GridBagConstraints(4, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(serienspezifikationFiller, new com.ulcjava.base.application.GridBagConstraints(5, 0, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
		serienspezifikationGridBagLayoutPane.add(leftFiller, new com.ulcjava.base.application.GridBagConstraints(0, 1, 1, 1, -1, -1, com.ulcjava.base.application.GridBagConstraints.CENTER, com.ulcjava.base.application.GridBagConstraints.NONE, new com.ulcjava.base.application.util.Insets(0,0,0,0), 0, 0));
	}
	return serienspezifikationGridBagLayoutPane;
}

/**
 * This method initializes serienspezifikationFlowLayoutPane	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.containers.RFlowLayoutPane	
 */
private RFlowLayoutPane getSerienspezifikationFlowLayoutPane() {
	if (serienspezifikationFlowLayoutPane == null) {
		serienspezifikationFlowLayoutPane = new RFlowLayoutPane();
		serienspezifikationFlowLayoutPane.setName("serienspezifikationFlowLayoutPane");
		serienspezifikationFlowLayoutPane.setStyle("buttonleiste");
		serienspezifikationFlowLayoutPane.add(getProjektButton());
		serienspezifikationFlowLayoutPane.add(getAntragButton());
		serienspezifikationFlowLayoutPane.add(getOkButton());
	}
	return serienspezifikationFlowLayoutPane;
}

/**
 * This method initializes serienspezifikationAbarbeitenLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getSerienspezifikationAbarbeitenLabel() {
	if (serienspezifikationAbarbeitenLabel == null) {
		serienspezifikationAbarbeitenLabel = new RLabel();
		serienspezifikationAbarbeitenLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/serienspezifikationAbarbeiten\") %>");
		serienspezifikationAbarbeitenLabel.setStyle("ueberschrift");
		serienspezifikationAbarbeitenLabel.setName("serienspezifikationAbarbeitenLabel");
	}
	return serienspezifikationAbarbeitenLabel;
}

/**
 * This method initializes okButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getOkButton() {
	if (okButton == null) {
		okButton = new RButton();
		okButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/ok\") %>");
		okButton.setName("okButton");
	}
	return okButton;
}

/**
 * This method initializes werkzeugCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getWerkzeugCheckBox() {
	if (werkzeugCheckBox == null) {
		werkzeugCheckBox = new RCheckBox();
		werkzeugCheckBox.setText("");
		werkzeugCheckBox.setName("werkzeugCheckBox");
	}
	return werkzeugCheckBox;
}

/**
 * This method initializes geraetezertifizierungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getGeraetezertifizierungLabel() {
	if (geraetezertifizierungLabel == null) {
		geraetezertifizierungLabel = new RLabel();
		geraetezertifizierungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/geraeteZertifizierung\") %>");
		geraetezertifizierungLabel.setName("geraetezertifizierungLabel");
	}
	return geraetezertifizierungLabel;
}

/**
 * This method initializes kundenfreigabeLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getKundenfreigabeLabel() {
	if (kundenfreigabeLabel == null) {
		kundenfreigabeLabel = new RLabel();
		kundenfreigabeLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/kundenfreigabe\") %>");
		kundenfreigabeLabel.setName("kundenfreigabeLabel");
	}
	return kundenfreigabeLabel;
}

/**
 * This method initializes geraetezertifizierungCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getGeraetezertifizierungCheckBox() {
	if (geraetezertifizierungCheckBox == null) {
		geraetezertifizierungCheckBox = new RCheckBox();
		geraetezertifizierungCheckBox.setText("");
		geraetezertifizierungCheckBox.setName("geraetezertifizierungCheckBox");
	}
	return geraetezertifizierungCheckBox;
}

/**
 * This method initializes kundenfreigabeCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getKundenfreigabeCheckBox() {
	if (kundenfreigabeCheckBox == null) {
		kundenfreigabeCheckBox = new RCheckBox();
		kundenfreigabeCheckBox.setText("");
		kundenfreigabeCheckBox.setName("kundenfreigabeCheckBox");
	}
	return kundenfreigabeCheckBox;
}

/**
 * This method initializes erstfertigungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getErstfertigungLabel() {
	if (erstfertigungLabel == null) {
		erstfertigungLabel = new RLabel();
		erstfertigungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/erstfertigung\") %>");
		erstfertigungLabel.setName("erstfertigungLabel");
	}
	return erstfertigungLabel;
}

/**
 * This method initializes risikobewertungLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getRisikobewertungLabel() {
	if (risikobewertungLabel == null) {
		risikobewertungLabel = new RLabel();
		risikobewertungLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/risikobewertung\") %>");
		risikobewertungLabel.setName("risikobewertungLabel");
	}
	return risikobewertungLabel;
}

/**
 * This method initializes erstfertigungCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getErstfertigungCheckBox() {
	if (erstfertigungCheckBox == null) {
		erstfertigungCheckBox = new RCheckBox();
		erstfertigungCheckBox.setText("");
		erstfertigungCheckBox.setEnabled(false);
		erstfertigungCheckBox.setName("erstfertigungCheckBox");
	}
	return erstfertigungCheckBox;
}

/**
 * This method initializes werkzeugLabel	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RLabel	
 */
private RLabel getWerkzeugLabel() {
	if (werkzeugLabel == null) {
		werkzeugLabel = new RLabel();
		werkzeugLabel.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/labels/werkzeug\") %>");
		werkzeugLabel.setName("werkzeugLabel");
	}
	return werkzeugLabel;
}

/**
 * This method initializes risikobewertungCheckBox	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RCheckBox	
 */
private RCheckBox getRisikobewertungCheckBox() {
	if (risikobewertungCheckBox == null) {
		risikobewertungCheckBox = new RCheckBox();
		risikobewertungCheckBox.setText("");
		risikobewertungCheckBox.setEnabled(false);
		risikobewertungCheckBox.setName("risikobewertungCheckBox");
	}
	return risikobewertungCheckBox;
}

/**
 * This method initializes projektButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getProjektButton() {
	if (projektButton == null) {
		projektButton = new RButton();
		projektButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/projektReferenz\") %>");
		projektButton.setName("projektButton");
	}
	return projektButton;
}

/**
 * This method initializes antragButton	
 * 	
 * @return ch.ivyteam.ivy.richdialog.widgets.components.RButton	
 */
private RButton getAntragButton() {
	if (antragButton == null) {
		antragButton = new RButton();
		antragButton.setText("<%= ivy.cms.co(\"/de.hummel.pep.gui/Button/antragReferenz\") %>");
		antragButton.setName("antragButton");
	}
	return antragButton;
}
}  //  @jve:decl-index=0:visual-constraint="10,10"