package ch.ivyteam.ivy.addons.filemanager.FileManagerOverride;

/**
 * It allows organizing and managing the files present on the server (download, upload, deletion of Files, directory management etc?). It integrates the DesktopHandlerPanel Rich Dialog.
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class FileManagerOverrideData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class FileManagerOverrideData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -4221585638389632572L;

  /**
   * A tree of FolderOnServer objects
   */
  private transient ch.ivyteam.ivy.scripting.objects.Tree folderTree;

  /**
   * Gets the field folderTree.
   * @return the value of the field folderTree; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Tree getFolderTree()
  {
    return folderTree;
  }

  /**
   * Sets the field folderTree.
   * @param _folderTree the new value of the field folderTree.
   */
  public void setFolderTree(ch.ivyteam.ivy.scripting.objects.Tree _folderTree)
  {
    folderTree = _folderTree;
  }

  /**
   * List of documents that are found into the DB.
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> documentsInDb;

  /**
   * Gets the field documentsInDb.
   * @return the value of the field documentsInDb; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getDocumentsInDb()
  {
    return documentsInDb;
  }

  /**
   * Sets the field documentsInDb.
   * @param _documentsInDb the new value of the field documentsInDb.
   */
  public void setDocumentsInDb(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _documentsInDb)
  {
    documentsInDb = _documentsInDb;
  }

  /**
   * List of documents found in the Server File system
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> documentsInFS;

  /**
   * Gets the field documentsInFS.
   * @return the value of the field documentsInFS; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getDocumentsInFS()
  {
    return documentsInFS;
  }

  /**
   * Sets the field documentsInFS.
   * @param _documentsInFS the new value of the field documentsInFS.
   */
  public void setDocumentsInFS(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _documentsInFS)
  {
    documentsInFS = _documentsInFS;
  }

  /**
   * files to add to DB after consistancy check. (There are on the FileSystem but are not in the DB)
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> filesToAdd;

  /**
   * Gets the field filesToAdd.
   * @return the value of the field filesToAdd; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getFilesToAdd()
  {
    return filesToAdd;
  }

  /**
   * Sets the field filesToAdd.
   * @param _filesToAdd the new value of the field filesToAdd.
   */
  public void setFilesToAdd(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _filesToAdd)
  {
    filesToAdd = _filesToAdd;
  }

  /**
   * files to delete from DB after consistancy check. (There are not on the FileSystem but are still in the DB)
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> filestoDelete;

  /**
   * Gets the field filestoDelete.
   * @return the value of the field filestoDelete; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getFilestoDelete()
  {
    return filestoDelete;
  }

  /**
   * Sets the field filestoDelete.
   * @param _filestoDelete the new value of the field filestoDelete.
   */
  public void setFilestoDelete(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _filestoDelete)
  {
    filestoDelete = _filestoDelete;
  }

  /**
   * Check if DB and File System consistant
   */
  private transient java.lang.Boolean consistancyOK;

  /**
   * Gets the field consistancyOK.
   * @return the value of the field consistancyOK; may be null.
   */
  public java.lang.Boolean getConsistancyOK()
  {
    return consistancyOK;
  }

  /**
   * Sets the field consistancyOK.
   * @param _consistancyOK the new value of the field consistancyOK.
   */
  public void setConsistancyOK(java.lang.Boolean _consistancyOK)
  {
    consistancyOK = _consistancyOK;
  }

  /**
   * Java Class that takes care of all the download process
   */
  private transient ch.ivyteam.ivy.addons.filemanager.FileDownloadHandler downloadHandler;

  /**
   * Gets the field downloadHandler.
   * @return the value of the field downloadHandler; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.FileDownloadHandler getDownloadHandler()
  {
    return downloadHandler;
  }

  /**
   * Sets the field downloadHandler.
   * @param _downloadHandler the new value of the field downloadHandler.
   */
  public void setDownloadHandler(ch.ivyteam.ivy.addons.filemanager.FileDownloadHandler _downloadHandler)
  {
    downloadHandler = _downloadHandler;
  }

  /**
   * Quantity of files into the server path
   */
  private transient java.lang.String filesNumber;

  /**
   * Gets the field filesNumber.
   * @return the value of the field filesNumber; may be null.
   */
  public java.lang.String getFilesNumber()
  {
    return filesNumber;
  }

  /**
   * Sets the field filesNumber.
   * @param _filesNumber the new value of the field filesNumber.
   */
  public void setFilesNumber(java.lang.String _filesNumber)
  {
    filesNumber = _filesNumber;
  }

  /**
   * File to upload or File that was at last uploaded
   */
  private transient java.io.File fileUpload;

  /**
   * Gets the field fileUpload.
   * @return the value of the field fileUpload; may be null.
   */
  public java.io.File getFileUpload()
  {
    return fileUpload;
  }

  /**
   * Sets the field fileUpload.
   * @param _fileUpload the new value of the field fileUpload.
   */
  public void setFileUpload(java.io.File _fileUpload)
  {
    fileUpload = _fileUpload;
  }

  /**
   * Boolean Flag to store the response from the user for actions such as delete or replace a file.
   */
  private transient java.lang.Boolean responseBoolean;

  /**
   * Gets the field responseBoolean.
   * @return the value of the field responseBoolean; may be null.
   */
  public java.lang.Boolean getResponseBoolean()
  {
    return responseBoolean;
  }

  /**
   * Sets the field responseBoolean.
   * @param _responseBoolean the new value of the field responseBoolean.
   */
  public void setResponseBoolean(java.lang.Boolean _responseBoolean)
  {
    responseBoolean = _responseBoolean;
  }

  /**
   * String to get the returned messages fronm the upload and downloadHandler
   */
  private transient ch.ivyteam.ivy.addons.filemanager.ReturnedMessage returnedMessage;

  /**
   * Gets the field returnedMessage.
   * @return the value of the field returnedMessage; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.ReturnedMessage getReturnedMessage()
  {
    return returnedMessage;
  }

  /**
   * Sets the field returnedMessage.
   * @param _returnedMessage the new value of the field returnedMessage.
   */
  public void setReturnedMessage(ch.ivyteam.ivy.addons.filemanager.ReturnedMessage _returnedMessage)
  {
    returnedMessage = _returnedMessage;
  }

  /**
   * Selected Document Object with DocumentID, path, filename and UserID
   */
  private transient ch.ivyteam.ivy.addons.filemanager.DocumentOnServer selectedDocument;

  /**
   * Gets the field selectedDocument.
   * @return the value of the field selectedDocument; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.DocumentOnServer getSelectedDocument()
  {
    return selectedDocument;
  }

  /**
   * Sets the field selectedDocument.
   * @param _selectedDocument the new value of the field selectedDocument.
   */
  public void setSelectedDocument(ch.ivyteam.ivy.addons.filemanager.DocumentOnServer _selectedDocument)
  {
    selectedDocument = _selectedDocument;
  }

  /**
   * the String representation of the default fixed path for the document management on the server. THIS SHOULD'NT BE CHANGED
   */
  private transient java.lang.String serverPath;

  /**
   * Gets the field serverPath.
   * @return the value of the field serverPath; may be null.
   */
  public java.lang.String getServerPath()
  {
    return serverPath;
  }

  /**
   * Sets the field serverPath.
   * @param _serverPath the new value of the field serverPath.
   */
  public void setServerPath(java.lang.String _serverPath)
  {
    serverPath = _serverPath;
  }

  /**
   * A String Variable to be used in some Methods.
   */
  private transient java.lang.String stringVariable;

  /**
   * Gets the field stringVariable.
   * @return the value of the field stringVariable; may be null.
   */
  public java.lang.String getStringVariable()
  {
    return stringVariable;
  }

  /**
   * Sets the field stringVariable.
   * @param _stringVariable the new value of the field stringVariable.
   */
  public void setStringVariable(java.lang.String _stringVariable)
  {
    stringVariable = _stringVariable;
  }

  /**
   * String representation of the actual time
   */
  private transient java.lang.String time;

  /**
   * Gets the field time.
   * @return the value of the field time; may be null.
   */
  public java.lang.String getTime()
  {
    return time;
  }

  /**
   * Sets the field time.
   * @param _time the new value of the field time.
   */
  public void setTime(java.lang.String _time)
  {
    time = _time;
  }

  /**
   * Today's date
   */
  private transient java.lang.String today;

  /**
   * Gets the field today.
   * @return the value of the field today; may be null.
   */
  public java.lang.String getToday()
  {
    return today;
  }

  /**
   * Sets the field today.
   * @param _today the new value of the field today.
   */
  public void setToday(java.lang.String _today)
  {
    today = _today;
  }

  /**
   * Java Class that takes care of all the upload process and the file deletion on the server
   */
  private transient ch.ivyteam.ivy.addons.filemanager.FileUploadHandler uploadHandler;

  /**
   * Gets the field uploadHandler.
   * @return the value of the field uploadHandler; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.FileUploadHandler getUploadHandler()
  {
    return uploadHandler;
  }

  /**
   * Sets the field uploadHandler.
   * @param _uploadHandler the new value of the field uploadHandler.
   */
  public void setUploadHandler(ch.ivyteam.ivy.addons.filemanager.FileUploadHandler _uploadHandler)
  {
    uploadHandler = _uploadHandler;
  }

  /**
   * selected Folder from user or Application
   */
  private transient ch.ivyteam.ivy.addons.filemanager.FolderOnServer selectedFolderOnServer;

  /**
   * Gets the field selectedFolderOnServer.
   * @return the value of the field selectedFolderOnServer; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.FolderOnServer getSelectedFolderOnServer()
  {
    return selectedFolderOnServer;
  }

  /**
   * Sets the field selectedFolderOnServer.
   * @param _selectedFolderOnServer the new value of the field selectedFolderOnServer.
   */
  public void setSelectedFolderOnServer(ch.ivyteam.ivy.addons.filemanager.FolderOnServer _selectedFolderOnServer)
  {
    selectedFolderOnServer = _selectedFolderOnServer;
  }

  /**
   * The name of the selected File on the server
   */
  private transient java.lang.String selectedServerFileName;

  /**
   * Gets the field selectedServerFileName.
   * @return the value of the field selectedServerFileName; may be null.
   */
  public java.lang.String getSelectedServerFileName()
  {
    return selectedServerFileName;
  }

  /**
   * Sets the field selectedServerFileName.
   * @param _selectedServerFileName the new value of the field selectedServerFileName.
   */
  public void setSelectedServerFileName(java.lang.String _selectedServerFileName)
  {
    selectedServerFileName = _selectedServerFileName;
  }

  /**
   * Boolean to set the visibility of the Tree
   */
  private transient java.lang.Boolean isTreeVisible;

  /**
   * Gets the field isTreeVisible.
   * @return the value of the field isTreeVisible; may be null.
   */
  public java.lang.Boolean getIsTreeVisible()
  {
    return isTreeVisible;
  }

  /**
   * Sets the field isTreeVisible.
   * @param _isTreeVisible the new value of the field isTreeVisible.
   */
  public void setIsTreeVisible(java.lang.Boolean _isTreeVisible)
  {
    isTreeVisible = _isTreeVisible;
  }

  /**
   * Progress unit step for the progressbar
   */
  private transient java.lang.Number progressUnit;

  /**
   * Gets the field progressUnit.
   * @return the value of the field progressUnit; may be null.
   */
  public java.lang.Number getProgressUnit()
  {
    return progressUnit;
  }

  /**
   * Sets the field progressUnit.
   * @param _progressUnit the new value of the field progressUnit.
   */
  public void setProgressUnit(java.lang.Number _progressUnit)
  {
    progressUnit = _progressUnit;
  }

  /**
   * the path of the client temp dirctory
   */
  private transient java.lang.String clientTempDirPath;

  /**
   * Gets the field clientTempDirPath.
   * @return the value of the field clientTempDirPath; may be null.
   */
  public java.lang.String getClientTempDirPath()
  {
    return clientTempDirPath;
  }

  /**
   * Sets the field clientTempDirPath.
   * @param _clientTempDirPath the new value of the field clientTempDirPath.
   */
  public void setClientTempDirPath(java.lang.String _clientTempDirPath)
  {
    clientTempDirPath = _clientTempDirPath;
  }

  /**
   * Number Flag to store the response from the user for actions such as delete or replace a file.
   */
  private transient java.lang.Number returnedCode;

  /**
   * Gets the field returnedCode.
   * @return the value of the field returnedCode; may be null.
   */
  public java.lang.Number getReturnedCode()
  {
    return returnedCode;
  }

  /**
   * Sets the field returnedCode.
   * @param _returnedCode the new value of the field returnedCode.
   */
  public void setReturnedCode(java.lang.Number _returnedCode)
  {
    returnedCode = _returnedCode;
  }

  /**
   * List of selected Documents on the server in the table
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> selectedDocuments;

  /**
   * Gets the field selectedDocuments.
   * @return the value of the field selectedDocuments; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getSelectedDocuments()
  {
    return selectedDocuments;
  }

  /**
   * Sets the field selectedDocuments.
   * @param _selectedDocuments the new value of the field selectedDocuments.
   */
  public void setSelectedDocuments(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _selectedDocuments)
  {
    selectedDocuments = _selectedDocuments;
  }

  /**
   * the system path separator on the client (/ on UNIX,\ on Windows)
   */
  private transient java.lang.String clientPathSeparator;

  /**
   * Gets the field clientPathSeparator.
   * @return the value of the field clientPathSeparator; may be null.
   */
  public java.lang.String getClientPathSeparator()
  {
    return clientPathSeparator;
  }

  /**
   * Sets the field clientPathSeparator.
   * @param _clientPathSeparator the new value of the field clientPathSeparator.
   */
  public void setClientPathSeparator(java.lang.String _clientPathSeparator)
  {
    clientPathSeparator = _clientPathSeparator;
  }

  /**
   * List of Files to unlock
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.FileCouple> ListOfFileCoupleToUnlock;

  /**
   * Gets the field ListOfFileCoupleToUnlock.
   * @return the value of the field ListOfFileCoupleToUnlock; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.FileCouple> getListOfFileCoupleToUnlock()
  {
    return ListOfFileCoupleToUnlock;
  }

  /**
   * Sets the field ListOfFileCoupleToUnlock.
   * @param _ListOfFileCoupleToUnlock the new value of the field ListOfFileCoupleToUnlock.
   */
  public void setListOfFileCoupleToUnlock(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.FileCouple> _ListOfFileCoupleToUnlock)
  {
    ListOfFileCoupleToUnlock = _ListOfFileCoupleToUnlock;
  }

  /**
   * a File path to unlock
   */
  private transient java.lang.String FilePathToUnlock;

  /**
   * Gets the field FilePathToUnlock.
   * @return the value of the field FilePathToUnlock; may be null.
   */
  public java.lang.String getFilePathToUnlock()
  {
    return FilePathToUnlock;
  }

  /**
   * Sets the field FilePathToUnlock.
   * @param _FilePathToUnlock the new value of the field FilePathToUnlock.
   */
  public void setFilePathToUnlock(java.lang.String _FilePathToUnlock)
  {
    FilePathToUnlock = _FilePathToUnlock;
  }

  /**
   * new File size after edit
   */
  private transient java.lang.String newFileSize;

  /**
   * Gets the field newFileSize.
   * @return the value of the field newFileSize; may be null.
   */
  public java.lang.String getNewFileSize()
  {
    return newFileSize;
  }

  /**
   * Sets the field newFileSize.
   * @param _newFileSize the new value of the field newFileSize.
   */
  public void setNewFileSize(java.lang.String _newFileSize)
  {
    newFileSize = _newFileSize;
  }

  /**
   * The parent ULCWindow of the entire Application
   */
  private transient com.ulcjava.base.application.ULCWindow appULCWindow;

  /**
   * Gets the field appULCWindow.
   * @return the value of the field appULCWindow; may be null.
   */
  public com.ulcjava.base.application.ULCWindow getAppULCWindow()
  {
    return appULCWindow;
  }

  /**
   * Sets the field appULCWindow.
   * @param _appULCWindow the new value of the field appULCWindow.
   */
  public void setAppULCWindow(com.ulcjava.base.application.ULCWindow _appULCWindow)
  {
    appULCWindow = _appULCWindow;
  }

  /**
   * if true the files are searched recursively under the selected directory. If false, just the files directly under the directory are shown.
   */
  private transient java.lang.Boolean isRecursive;

  /**
   * Gets the field isRecursive.
   * @return the value of the field isRecursive; may be null.
   */
  public java.lang.Boolean getIsRecursive()
  {
    return isRecursive;
  }

  /**
   * Sets the field isRecursive.
   * @param _isRecursive the new value of the field isRecursive.
   */
  public void setIsRecursive(java.lang.Boolean _isRecursive)
  {
    isRecursive = _isRecursive;
  }

  /**
   * used to enabled some advanced features like delete or add a new directory
   */
  private transient java.lang.Boolean advancedActionsEnabled;

  /**
   * Gets the field advancedActionsEnabled.
   * @return the value of the field advancedActionsEnabled; may be null.
   */
  public java.lang.Boolean getAdvancedActionsEnabled()
  {
    return advancedActionsEnabled;
  }

  /**
   * Sets the field advancedActionsEnabled.
   * @param _advancedActionsEnabled the new value of the field advancedActionsEnabled.
   */
  public void setAdvancedActionsEnabled(java.lang.Boolean _advancedActionsEnabled)
  {
    advancedActionsEnabled = _advancedActionsEnabled;
  }

  /**
   * used as flag to tell if the copy/paste function is on.
   */
  private transient java.lang.Boolean copyOn;

  /**
   * Gets the field copyOn.
   * @return the value of the field copyOn; may be null.
   */
  public java.lang.Boolean getCopyOn()
  {
    return copyOn;
  }

  /**
   * Sets the field copyOn.
   * @param _copyOn the new value of the field copyOn.
   */
  public void setCopyOn(java.lang.Boolean _copyOn)
  {
    copyOn = _copyOn;
  }

  /**
   * Object responsible for Files properties storing system (like DB or XML system)
   */
  private transient ch.ivyteam.ivy.addons.filemanager.database.AbstractFileManagementHandler fileManagementHandler;

  /**
   * Gets the field fileManagementHandler.
   * @return the value of the field fileManagementHandler; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.database.AbstractFileManagementHandler getFileManagementHandler()
  {
    return fileManagementHandler;
  }

  /**
   * Sets the field fileManagementHandler.
   * @param _fileManagementHandler the new value of the field fileManagementHandler.
   */
  public void setFileManagementHandler(ch.ivyteam.ivy.addons.filemanager.database.AbstractFileManagementHandler _fileManagementHandler)
  {
    fileManagementHandler = _fileManagementHandler;
  }

  /**
   * used in loops
   */
  private transient java.lang.Number cursor;

  /**
   * Gets the field cursor.
   * @return the value of the field cursor; may be null.
   */
  public java.lang.Number getCursor()
  {
    return cursor;
  }

  /**
   * Sets the field cursor.
   * @param _cursor the new value of the field cursor.
   */
  public void setCursor(java.lang.Number _cursor)
  {
    cursor = _cursor;
  }

  /**
   * allows showing or hidding the toolbar
   */
  private transient java.lang.Boolean isToolbarVisible;

  /**
   * Gets the field isToolbarVisible.
   * @return the value of the field isToolbarVisible; may be null.
   */
  public java.lang.Boolean getIsToolbarVisible()
  {
    return isToolbarVisible;
  }

  /**
   * Sets the field isToolbarVisible.
   * @param _isToolbarVisible the new value of the field isToolbarVisible.
   */
  public void setIsToolbarVisible(java.lang.Boolean _isToolbarVisible)
  {
    isToolbarVisible = _isToolbarVisible;
  }

  /**
   * used to store synch/asynch windows titles
   */
  private transient java.lang.String windowTitle;

  /**
   * Gets the field windowTitle.
   * @return the value of the field windowTitle; may be null.
   */
  public java.lang.String getWindowTitle()
  {
    return windowTitle;
  }

  /**
   * Sets the field windowTitle.
   * @param _windowTitle the new value of the field windowTitle.
   */
  public void setWindowTitle(java.lang.String _windowTitle)
  {
    windowTitle = _windowTitle;
  }

  /**
   * path choosed in pathchooser mode
   */
  private transient java.lang.String pathChooserReturn;

  /**
   * Gets the field pathChooserReturn.
   * @return the value of the field pathChooserReturn; may be null.
   */
  public java.lang.String getPathChooserReturn()
  {
    return pathChooserReturn;
  }

  /**
   * Sets the field pathChooserReturn.
   * @param _pathChooserReturn the new value of the field pathChooserReturn.
   */
  public void setPathChooserReturn(java.lang.String _pathChooserReturn)
  {
    pathChooserReturn = _pathChooserReturn;
  }

  /**
   * true if started as path chooser. Used to set the visibility of certains visual components (like buttons)
   */
  private transient java.lang.Boolean isPathChooserFlowLayoutVisible;

  /**
   * Gets the field isPathChooserFlowLayoutVisible.
   * @return the value of the field isPathChooserFlowLayoutVisible; may be null.
   */
  public java.lang.Boolean getIsPathChooserFlowLayoutVisible()
  {
    return isPathChooserFlowLayoutVisible;
  }

  /**
   * Sets the field isPathChooserFlowLayoutVisible.
   * @param _isPathChooserFlowLayoutVisible the new value of the field isPathChooserFlowLayoutVisible.
   */
  public void setIsPathChooserFlowLayoutVisible(java.lang.Boolean _isPathChooserFlowLayoutVisible)
  {
    isPathChooserFlowLayoutVisible = _isPathChooserFlowLayoutVisible;
  }

  /**
   * Documents to be copied in an copy/paste action
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> copiedDocuments;

  /**
   * Gets the field copiedDocuments.
   * @return the value of the field copiedDocuments; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getCopiedDocuments()
  {
    return copiedDocuments;
  }

  /**
   * Sets the field copiedDocuments.
   * @param _copiedDocuments the new value of the field copiedDocuments.
   */
  public void setCopiedDocuments(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _copiedDocuments)
  {
    copiedDocuments = _copiedDocuments;
  }

  /**
   * documentOnServer used to store a doc to be edited
   */
  private transient ch.ivyteam.ivy.addons.filemanager.DocumentOnServer docToEdit;

  /**
   * Gets the field docToEdit.
   * @return the value of the field docToEdit; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.DocumentOnServer getDocToEdit()
  {
    return docToEdit;
  }

  /**
   * Sets the field docToEdit.
   * @param _docToEdit the new value of the field docToEdit.
   */
  public void setDocToEdit(ch.ivyteam.ivy.addons.filemanager.DocumentOnServer _docToEdit)
  {
    docToEdit = _docToEdit;
  }

  /**
   * temp list of java.io.File Objects
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<java.io.File> tmpListOfFiles;

  /**
   * Gets the field tmpListOfFiles.
   * @return the value of the field tmpListOfFiles; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<java.io.File> getTmpListOfFiles()
  {
    return tmpListOfFiles;
  }

  /**
   * Sets the field tmpListOfFiles.
   * @param _tmpListOfFiles the new value of the field tmpListOfFiles.
   */
  public void setTmpListOfFiles(ch.ivyteam.ivy.scripting.objects.List<java.io.File> _tmpListOfFiles)
  {
    tmpListOfFiles = _tmpListOfFiles;
  }

  /**
   * java.io.File : stores the current File to be moved in operations like DnD etc...
   */
  private transient java.io.File fileToMove;

  /**
   * Gets the field fileToMove.
   * @return the value of the field fileToMove; may be null.
   */
  public java.io.File getFileToMove()
  {
    return fileToMove;
  }

  /**
   * Sets the field fileToMove.
   * @param _fileToMove the new value of the field fileToMove.
   */
  public void setFileToMove(java.io.File _fileToMove)
  {
    fileToMove = _fileToMove;
  }

  /**
   * java.io.File used to store a File to be edited
   */
  private transient java.io.File fileToEdit;

  /**
   * Gets the field fileToEdit.
   * @return the value of the field fileToEdit; may be null.
   */
  public java.io.File getFileToEdit()
  {
    return fileToEdit;
  }

  /**
   * Sets the field fileToEdit.
   * @param _fileToEdit the new value of the field fileToEdit.
   */
  public void setFileToEdit(java.io.File _fileToEdit)
  {
    fileToEdit = _fileToEdit;
  }

  /**
   * stores a list of Files the user choosed to overwrtite in copy/paste, Dnd operatiions etc...
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<java.io.File> filesToOverwrite;

  /**
   * Gets the field filesToOverwrite.
   * @return the value of the field filesToOverwrite; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<java.io.File> getFilesToOverwrite()
  {
    return filesToOverwrite;
  }

  /**
   * Sets the field filesToOverwrite.
   * @param _filesToOverwrite the new value of the field filesToOverwrite.
   */
  public void setFilesToOverwrite(ch.ivyteam.ivy.scripting.objects.List<java.io.File> _filesToOverwrite)
  {
    filesToOverwrite = _filesToOverwrite;
  }

  /**
   * the Text displayed on the progressBar
   */
  private transient java.lang.String progressText;

  /**
   * Gets the field progressText.
   * @return the value of the field progressText; may be null.
   */
  public java.lang.String getProgressText()
  {
    return progressText;
  }

  /**
   * Sets the field progressText.
   * @param _progressText the new value of the field progressText.
   */
  public void setProgressText(java.lang.String _progressText)
  {
    progressText = _progressText;
  }

  /**
   * The Ivy DB connection friendly name
   */
  private java.lang.String ivyConnexionDBName;

  /**
   * Gets the field ivyConnexionDBName.
   * @return the value of the field ivyConnexionDBName; may be null.
   */
  public java.lang.String getIvyConnexionDBName()
  {
    return ivyConnexionDBName;
  }

  /**
   * Sets the field ivyConnexionDBName.
   * @param _ivyConnexionDBName the new value of the field ivyConnexionDBName.
   */
  public void setIvyConnexionDBName(java.lang.String _ivyConnexionDBName)
  {
    ivyConnexionDBName = _ivyConnexionDBName;
  }

  /**
   * The table Name used to  store the Files informations.
   */
  private java.lang.String DbTableName;

  /**
   * Gets the field DbTableName.
   * @return the value of the field DbTableName; may be null.
   */
  public java.lang.String getDbTableName()
  {
    return DbTableName;
  }

  /**
   * Sets the field DbTableName.
   * @param _DbTableName the new value of the field DbTableName.
   */
  public void setDbTableName(java.lang.String _DbTableName)
  {
    DbTableName = _DbTableName;
  }

  /**
   * *This parameter is only supported for PostgreSQL. It indicates the schemata that contains the table. Default is "public".
   */
  private java.lang.String schemaName;

  /**
   * Gets the field schemaName.
   * @return the value of the field schemaName; may be null.
   */
  public java.lang.String getSchemaName()
  {
    return schemaName;
  }

  /**
   * Sets the field schemaName.
   * @param _schemaName the new value of the field schemaName.
   */
  public void setSchemaName(java.lang.String _schemaName)
  {
    schemaName = _schemaName;
  }

  /**
   * boolean used to determine if the list should be refreshed after incoming SE
   */
  private transient java.lang.Boolean updateList;

  /**
   * Gets the field updateList.
   * @return the value of the field updateList; may be null.
   */
  public java.lang.Boolean getUpdateList()
  {
    return updateList;
  }

  /**
   * Sets the field updateList.
   * @param _updateList the new value of the field updateList.
   */
  public void setUpdateList(java.lang.Boolean _updateList)
  {
    updateList = _updateList;
  }

  /**
   * unique Panel Id for this FileManagement. Avoid performing self sent System Events.
   */
  private transient java.lang.Number panelId;

  /**
   * Gets the field panelId.
   * @return the value of the field panelId; may be null.
   */
  public java.lang.Number getPanelId()
  {
    return panelId;
  }

  /**
   * Sets the field panelId.
   * @param _panelId the new value of the field panelId.
   */
  public void setPanelId(java.lang.Number _panelId)
  {
    panelId = _panelId;
  }

  /**
   * used  as email container object to call the DesktopHandler mail method.
   */
  private transient ch.ivyteam.ivy.addons.filemanager.EmailContainer emailContainer;

  /**
   * Gets the field emailContainer.
   * @return the value of the field emailContainer; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.EmailContainer getEmailContainer()
  {
    return emailContainer;
  }

  /**
   * Sets the field emailContainer.
   * @param _emailContainer the new value of the field emailContainer.
   */
  public void setEmailContainer(ch.ivyteam.ivy.addons.filemanager.EmailContainer _emailContainer)
  {
    emailContainer = _emailContainer;
  }

  /**
   * used in the edit process to store the response of the DesktopHandler telling if the choosed file is editable by the client.
   */
  private transient java.lang.Boolean isFileEditable;

  /**
   * Gets the field isFileEditable.
   * @return the value of the field isFileEditable; may be null.
   */
  public java.lang.Boolean getIsFileEditable()
  {
    return isFileEditable;
  }

  /**
   * Sets the field isFileEditable.
   * @param _isFileEditable the new value of the field isFileEditable.
   */
  public void setIsFileEditable(java.lang.Boolean _isFileEditable)
  {
    isFileEditable = _isFileEditable;
  }

  /**
   * used in DnD operations from files
   */
  private transient java.lang.String DnDDestinationPath;

  /**
   * Gets the field DnDDestinationPath.
   * @return the value of the field DnDDestinationPath; may be null.
   */
  public java.lang.String getDnDDestinationPath()
  {
    return DnDDestinationPath;
  }

  /**
   * Sets the field DnDDestinationPath.
   * @param _DnDDestinationPath the new value of the field DnDDestinationPath.
   */
  public void setDnDDestinationPath(java.lang.String _DnDDestinationPath)
  {
    DnDDestinationPath = _DnDDestinationPath;
  }

  /**
   * used in DnD operations
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> filesToMove;

  /**
   * Gets the field filesToMove.
   * @return the value of the field filesToMove; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getFilesToMove()
  {
    return filesToMove;
  }

  /**
   * Sets the field filesToMove.
   * @param _filesToMove the new value of the field filesToMove.
   */
  public void setFilesToMove(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _filesToMove)
  {
    filesToMove = _filesToMove;
  }

  /**
   * used in DnD operations / stores the files that could not be moved because locked.
   */
  private transient ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> filesUnpossibleToMove;

  /**
   * Gets the field filesUnpossibleToMove.
   * @return the value of the field filesUnpossibleToMove; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> getFilesUnpossibleToMove()
  {
    return filesUnpossibleToMove;
  }

  /**
   * Sets the field filesUnpossibleToMove.
   * @param _filesUnpossibleToMove the new value of the field filesUnpossibleToMove.
   */
  public void setFilesUnpossibleToMove(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.addons.filemanager.DocumentOnServer> _filesUnpossibleToMove)
  {
    filesUnpossibleToMove = _filesUnpossibleToMove;
  }

  /**
   * Ivy user name / if Ivy user name unknown = OS user name
   */
  private transient java.lang.String applicationUserName;

  /**
   * Gets the field applicationUserName.
   * @return the value of the field applicationUserName; may be null.
   */
  public java.lang.String getApplicationUserName()
  {
    return applicationUserName;
  }

  /**
   * Sets the field applicationUserName.
   * @param _applicationUserName the new value of the field applicationUserName.
   */
  public void setApplicationUserName(java.lang.String _applicationUserName)
  {
    applicationUserName = _applicationUserName;
  }

  /**
   * Used to get the pressed button in some dialogs
   */
  private transient java.lang.String pressedButton;

  /**
   * Gets the field pressedButton.
   * @return the value of the field pressedButton; may be null.
   */
  public java.lang.String getPressedButton()
  {
    return pressedButton;
  }

  /**
   * Sets the field pressedButton.
   * @param _pressedButton the new value of the field pressedButton.
   */
  public void setPressedButton(java.lang.String _pressedButton)
  {
    pressedButton = _pressedButton;
  }

  /**
   * true if the files copied come from this panel, else false.
   */
  private transient java.lang.Boolean filesCopiedInThisPanel;

  /**
   * Gets the field filesCopiedInThisPanel.
   * @return the value of the field filesCopiedInThisPanel; may be null.
   */
  public java.lang.Boolean getFilesCopiedInThisPanel()
  {
    return filesCopiedInThisPanel;
  }

  /**
   * Sets the field filesCopiedInThisPanel.
   * @param _filesCopiedInThisPanel the new value of the field filesCopiedInThisPanel.
   */
  public void setFilesCopiedInThisPanel(java.lang.Boolean _filesCopiedInThisPanel)
  {
    filesCopiedInThisPanel = _filesCopiedInThisPanel;
  }

  /**
   * encapsulates the errors and exceptions that can occur in operations. Sent in the errorOccurred broadcast event.
   */
  private transient ch.ivyteam.ivy.addons.filemanager.ErrorUtil errorUtil;

  /**
   * Gets the field errorUtil.
   * @return the value of the field errorUtil; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.ErrorUtil getErrorUtil()
  {
    return errorUtil;
  }

  /**
   * Sets the field errorUtil.
   * @param _errorUtil the new value of the field errorUtil.
   */
  public void setErrorUtil(ch.ivyteam.ivy.addons.filemanager.ErrorUtil _errorUtil)
  {
    errorUtil = _errorUtil;
  }

  /**
   * encapsulates the errors and exceptions that can occur in operations. Comes in the errorOccurred broadcast event.
   */
  private transient ch.ivyteam.ivy.addons.filemanager.ErrorUtil incomingErrorUtil;

  /**
   * Gets the field incomingErrorUtil.
   * @return the value of the field incomingErrorUtil; may be null.
   */
  public ch.ivyteam.ivy.addons.filemanager.ErrorUtil getIncomingErrorUtil()
  {
    return incomingErrorUtil;
  }

  /**
   * Sets the field incomingErrorUtil.
   * @param _incomingErrorUtil the new value of the field incomingErrorUtil.
   */
  public void setIncomingErrorUtil(ch.ivyteam.ivy.addons.filemanager.ErrorUtil _incomingErrorUtil)
  {
    incomingErrorUtil = _incomingErrorUtil;
  }

  /**
   * used in some broadcast events to check if the event was launched in the same panel.
   */
  private transient java.lang.Boolean samePanelFlag;

  /**
   * Gets the field samePanelFlag.
   * @return the value of the field samePanelFlag; may be null.
   */
  public java.lang.Boolean getSamePanelFlag()
  {
    return samePanelFlag;
  }

  /**
   * Sets the field samePanelFlag.
   * @param _samePanelFlag the new value of the field samePanelFlag.
   */
  public void setSamePanelFlag(java.lang.Boolean _samePanelFlag)
  {
    samePanelFlag = _samePanelFlag;
  }

  /**
   * If true then tolbars with iPhone icons like are displayed, otherwise the "normal" icons are displayed.
   */
  private transient java.lang.Boolean roundedCornerIconsMode;

  /**
   * Gets the field roundedCornerIconsMode.
   * @return the value of the field roundedCornerIconsMode; may be null.
   */
  public java.lang.Boolean getRoundedCornerIconsMode()
  {
    return roundedCornerIconsMode;
  }

  /**
   * Sets the field roundedCornerIconsMode.
   * @param _roundedCornerIconsMode the new value of the field roundedCornerIconsMode.
   */
  public void setRoundedCornerIconsMode(java.lang.Boolean _roundedCornerIconsMode)
  {
    roundedCornerIconsMode = _roundedCornerIconsMode;
  }

  /**
   * If true then the edit/credit/remove/ toolbar actions will be disabled.
   */
  private java.lang.Boolean readOnlyMode;

  /**
   * Gets the field readOnlyMode.
   * @return the value of the field readOnlyMode; may be null.
   */
  public java.lang.Boolean getReadOnlyMode()
  {
    return readOnlyMode;
  }

  /**
   * Sets the field readOnlyMode.
   * @param _readOnlyMode the new value of the field readOnlyMode.
   */
  public void setReadOnlyMode(java.lang.Boolean _readOnlyMode)
  {
    readOnlyMode = _readOnlyMode;
  }

}
