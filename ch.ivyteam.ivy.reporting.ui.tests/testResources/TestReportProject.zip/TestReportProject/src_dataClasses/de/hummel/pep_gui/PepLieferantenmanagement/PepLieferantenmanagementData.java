package de.hummel.pep_gui.PepLieferantenmanagement;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepLieferantenmanagementData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepLieferantenmanagementData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 1770893883872045480L;

  private ch.ivyteam.ivy.scripting.objects.List<de.hummel.pep.processes.LieferantenManagement> lieferantenmanagement;

  /**
   * Gets the field lieferantenmanagement.
   * @return the value of the field lieferantenmanagement; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<de.hummel.pep.processes.LieferantenManagement> getLieferantenmanagement()
  {
    return lieferantenmanagement;
  }

  /**
   * Sets the field lieferantenmanagement.
   * @param _lieferantenmanagement the new value of the field lieferantenmanagement.
   */
  public void setLieferantenmanagement(ch.ivyteam.ivy.scripting.objects.List<de.hummel.pep.processes.LieferantenManagement> _lieferantenmanagement)
  {
    lieferantenmanagement = _lieferantenmanagement;
  }

}
