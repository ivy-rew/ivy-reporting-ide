package de.hummel.pep_gui.PepContainer;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepContainerData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepContainerData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 6122917694229633186L;

  private de.hummel.pep.go.Produktentwicklung produktentwicklung;

  /**
   * Gets the field produktentwicklung.
   * @return the value of the field produktentwicklung; may be null.
   */
  public de.hummel.pep.go.Produktentwicklung getProduktentwicklung()
  {
    return produktentwicklung;
  }

  /**
   * Sets the field produktentwicklung.
   * @param _produktentwicklung the new value of the field produktentwicklung.
   */
  public void setProduktentwicklung(de.hummel.pep.go.Produktentwicklung _produktentwicklung)
  {
    produktentwicklung = _produktentwicklung;
  }

  private de.hummel.pep.processes.PEPData prozessData;

  /**
   * Gets the field prozessData.
   * @return the value of the field prozessData; may be null.
   */
  public de.hummel.pep.processes.PEPData getProzessData()
  {
    return prozessData;
  }

  /**
   * Sets the field prozessData.
   * @param _prozessData the new value of the field prozessData.
   */
  public void setProzessData(de.hummel.pep.processes.PEPData _prozessData)
  {
    prozessData = _prozessData;
  }

  private java.lang.Boolean tempBoolean;

  /**
   * Gets the field tempBoolean.
   * @return the value of the field tempBoolean; may be null.
   */
  public java.lang.Boolean getTempBoolean()
  {
    return tempBoolean;
  }

  /**
   * Sets the field tempBoolean.
   * @param _tempBoolean the new value of the field tempBoolean.
   */
  public void setTempBoolean(java.lang.Boolean _tempBoolean)
  {
    tempBoolean = _tempBoolean;
  }

}
