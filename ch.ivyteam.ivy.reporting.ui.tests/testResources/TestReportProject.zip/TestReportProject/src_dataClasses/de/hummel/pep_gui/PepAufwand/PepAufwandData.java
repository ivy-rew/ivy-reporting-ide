package de.hummel.pep_gui.PepAufwand;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepAufwandData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepAufwandData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -8866580491079158922L;

  private de.hummel.pep.go.Produktentwicklung produktentwicklung;

  /**
   * Gets the field produktentwicklung.
   * @return the value of the field produktentwicklung; may be null.
   */
  public de.hummel.pep.go.Produktentwicklung getProduktentwicklung()
  {
    return produktentwicklung;
  }

  /**
   * Sets the field produktentwicklung.
   * @param _produktentwicklung the new value of the field produktentwicklung.
   */
  public void setProduktentwicklung(de.hummel.pep.go.Produktentwicklung _produktentwicklung)
  {
    produktentwicklung = _produktentwicklung;
  }

  private de.hummel.pep.processes.Aufwand aufwand;

  /**
   * Gets the field aufwand.
   * @return the value of the field aufwand; may be null.
   */
  public de.hummel.pep.processes.Aufwand getAufwand()
  {
    return aufwand;
  }

  /**
   * Sets the field aufwand.
   * @param _aufwand the new value of the field aufwand.
   */
  public void setAufwand(de.hummel.pep.processes.Aufwand _aufwand)
  {
    aufwand = _aufwand;
  }

}
