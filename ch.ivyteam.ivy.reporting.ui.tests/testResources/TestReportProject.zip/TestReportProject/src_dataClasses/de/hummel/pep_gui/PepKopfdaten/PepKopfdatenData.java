package de.hummel.pep_gui.PepKopfdaten;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepKopfdatenData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepKopfdatenData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 8619641645547441711L;

  private de.hummel.pep.go.Produktentwicklung produktentwicklung;

  /**
   * Gets the field produktentwicklung.
   * @return the value of the field produktentwicklung; may be null.
   */
  public de.hummel.pep.go.Produktentwicklung getProduktentwicklung()
  {
    return produktentwicklung;
  }

  /**
   * Sets the field produktentwicklung.
   * @param _produktentwicklung the new value of the field produktentwicklung.
   */
  public void setProduktentwicklung(de.hummel.pep.go.Produktentwicklung _produktentwicklung)
  {
    produktentwicklung = _produktentwicklung;
  }

  private ch.ivyteam.ivy.scripting.objects.List<java.lang.String> warengruppenListe;

  /**
   * Gets the field warengruppenListe.
   * @return the value of the field warengruppenListe; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<java.lang.String> getWarengruppenListe()
  {
    return warengruppenListe;
  }

  /**
   * Sets the field warengruppenListe.
   * @param _warengruppenListe the new value of the field warengruppenListe.
   */
  public void setWarengruppenListe(ch.ivyteam.ivy.scripting.objects.List<java.lang.String> _warengruppenListe)
  {
    warengruppenListe = _warengruppenListe;
  }

}
