package de.hummel.pep_gui.PepTerminPreis;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepTerminPreisData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepTerminPreisData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 4557693511213275232L;

  private de.hummel.pep.go.Produktentwicklung produktentwicklung;

  /**
   * Gets the field produktentwicklung.
   * @return the value of the field produktentwicklung; may be null.
   */
  public de.hummel.pep.go.Produktentwicklung getProduktentwicklung()
  {
    return produktentwicklung;
  }

  /**
   * Sets the field produktentwicklung.
   * @param _produktentwicklung the new value of the field produktentwicklung.
   */
  public void setProduktentwicklung(de.hummel.pep.go.Produktentwicklung _produktentwicklung)
  {
    produktentwicklung = _produktentwicklung;
  }

}
