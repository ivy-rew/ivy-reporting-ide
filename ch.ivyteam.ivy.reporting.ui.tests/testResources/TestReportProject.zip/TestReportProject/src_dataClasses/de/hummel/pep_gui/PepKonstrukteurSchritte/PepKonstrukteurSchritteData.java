package de.hummel.pep_gui.PepKonstrukteurSchritte;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepKonstrukteurSchritteData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepKonstrukteurSchritteData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -2725299470592983318L;

  private ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.security.IUser> ListeKonstrukteur;

  /**
   * Gets the field ListeKonstrukteur.
   * @return the value of the field ListeKonstrukteur; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.security.IUser> getListeKonstrukteur()
  {
    return ListeKonstrukteur;
  }

  /**
   * Sets the field ListeKonstrukteur.
   * @param _ListeKonstrukteur the new value of the field ListeKonstrukteur.
   */
  public void setListeKonstrukteur(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.security.IUser> _ListeKonstrukteur)
  {
    ListeKonstrukteur = _ListeKonstrukteur;
  }

  private de.hummel.pep.processes.allgemein.erstellePEPKonzeptData pepKonzeptData;

  /**
   * Gets the field pepKonzeptData.
   * @return the value of the field pepKonzeptData; may be null.
   */
  public de.hummel.pep.processes.allgemein.erstellePEPKonzeptData getPepKonzeptData()
  {
    return pepKonzeptData;
  }

  /**
   * Sets the field pepKonzeptData.
   * @param _pepKonzeptData the new value of the field pepKonzeptData.
   */
  public void setPepKonzeptData(de.hummel.pep.processes.allgemein.erstellePEPKonzeptData _pepKonzeptData)
  {
    pepKonzeptData = _pepKonzeptData;
  }

}
