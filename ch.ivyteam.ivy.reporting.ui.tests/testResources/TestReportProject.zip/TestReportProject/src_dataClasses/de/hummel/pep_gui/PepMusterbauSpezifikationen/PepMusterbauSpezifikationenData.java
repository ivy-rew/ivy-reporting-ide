package de.hummel.pep_gui.PepMusterbauSpezifikationen;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepMusterbauSpezifikationenData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepMusterbauSpezifikationenData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -3630205126328840347L;

  private de.hummel.pep.processes.PEPData pepData;

  /**
   * Gets the field pepData.
   * @return the value of the field pepData; may be null.
   */
  public de.hummel.pep.processes.PEPData getPepData()
  {
    return pepData;
  }

  /**
   * Sets the field pepData.
   * @param _pepData the new value of the field pepData.
   */
  public void setPepData(de.hummel.pep.processes.PEPData _pepData)
  {
    pepData = _pepData;
  }

}
