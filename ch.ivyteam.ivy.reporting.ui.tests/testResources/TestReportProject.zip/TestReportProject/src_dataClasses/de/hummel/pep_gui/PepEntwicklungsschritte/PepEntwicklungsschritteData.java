package de.hummel.pep_gui.PepEntwicklungsschritte;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepEntwicklungsschritteData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepEntwicklungsschritteData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -6287965519393315870L;

  private de.hummel.pep.processes.Entwicklungsschritte entwicklungsschritte;

  /**
   * Gets the field entwicklungsschritte.
   * @return the value of the field entwicklungsschritte; may be null.
   */
  public de.hummel.pep.processes.Entwicklungsschritte getEntwicklungsschritte()
  {
    return entwicklungsschritte;
  }

  /**
   * Sets the field entwicklungsschritte.
   * @param _entwicklungsschritte the new value of the field entwicklungsschritte.
   */
  public void setEntwicklungsschritte(de.hummel.pep.processes.Entwicklungsschritte _entwicklungsschritte)
  {
    entwicklungsschritte = _entwicklungsschritte;
  }

}
