package de.hummel.pep_gui.PepProjektspezifikationen;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepProjektspezifikationenData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepProjektspezifikationenData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -4176919797925459140L;

  private de.hummel.pep.processes.Projektspezifikationen projektspezifikationen;

  /**
   * Gets the field projektspezifikationen.
   * @return the value of the field projektspezifikationen; may be null.
   */
  public de.hummel.pep.processes.Projektspezifikationen getProjektspezifikationen()
  {
    return projektspezifikationen;
  }

  /**
   * Sets the field projektspezifikationen.
   * @param _projektspezifikationen the new value of the field projektspezifikationen.
   */
  public void setProjektspezifikationen(de.hummel.pep.processes.Projektspezifikationen _projektspezifikationen)
  {
    projektspezifikationen = _projektspezifikationen;
  }

}
