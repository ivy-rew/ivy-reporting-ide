package de.hummel.pep_gui.PepProjektauftrag;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepProjektauftragData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepProjektauftragData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 2642969715872809339L;

  private de.hummel.pep.go.Produktentwicklung produktentwicklung;

  /**
   * Gets the field produktentwicklung.
   * @return the value of the field produktentwicklung; may be null.
   */
  public de.hummel.pep.go.Produktentwicklung getProduktentwicklung()
  {
    return produktentwicklung;
  }

  /**
   * Sets the field produktentwicklung.
   * @param _produktentwicklung the new value of the field produktentwicklung.
   */
  public void setProduktentwicklung(de.hummel.pep.go.Produktentwicklung _produktentwicklung)
  {
    produktentwicklung = _produktentwicklung;
  }

  private ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.security.IUser> userList;

  /**
   * Gets the field userList.
   * @return the value of the field userList; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.security.IUser> getUserList()
  {
    return userList;
  }

  /**
   * Sets the field userList.
   * @param _userList the new value of the field userList.
   */
  public void setUserList(ch.ivyteam.ivy.scripting.objects.List<ch.ivyteam.ivy.security.IUser> _userList)
  {
    userList = _userList;
  }

}
