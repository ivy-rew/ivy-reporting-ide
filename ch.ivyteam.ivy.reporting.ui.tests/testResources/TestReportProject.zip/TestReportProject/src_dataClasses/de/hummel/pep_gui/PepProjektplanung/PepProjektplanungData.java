package de.hummel.pep_gui.PepProjektplanung;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PepProjektplanungData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PepProjektplanungData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -530607049633617954L;

  private de.hummel.pep.processes.PEPData prozessData;

  /**
   * Gets the field prozessData.
   * @return the value of the field prozessData; may be null.
   */
  public de.hummel.pep.processes.PEPData getProzessData()
  {
    return prozessData;
  }

  /**
   * Sets the field prozessData.
   * @param _prozessData the new value of the field prozessData.
   */
  public void setProzessData(de.hummel.pep.processes.PEPData _prozessData)
  {
    prozessData = _prozessData;
  }

  private java.lang.Boolean tempBoolean;

  /**
   * Gets the field tempBoolean.
   * @return the value of the field tempBoolean; may be null.
   */
  public java.lang.Boolean getTempBoolean()
  {
    return tempBoolean;
  }

  /**
   * Sets the field tempBoolean.
   * @param _tempBoolean the new value of the field tempBoolean.
   */
  public void setTempBoolean(java.lang.Boolean _tempBoolean)
  {
    tempBoolean = _tempBoolean;
  }

}
