package de.hummel.pep.processes;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Aufwand", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Aufwand extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 2542538600377266400L;

  private java.lang.Integer entwicklerStunden;

  /**
   * Gets the field entwicklerStunden.
   * @return the value of the field entwicklerStunden; may be null.
   */
  public java.lang.Integer getEntwicklerStunden()
  {
    return entwicklerStunden;
  }

  /**
   * Sets the field entwicklerStunden.
   * @param _entwicklerStunden the new value of the field entwicklerStunden.
   */
  public void setEntwicklerStunden(java.lang.Integer _entwicklerStunden)
  {
    entwicklerStunden = _entwicklerStunden;
  }

  private java.lang.Integer cadStunden;

  /**
   * Gets the field cadStunden.
   * @return the value of the field cadStunden; may be null.
   */
  public java.lang.Integer getCadStunden()
  {
    return cadStunden;
  }

  /**
   * Sets the field cadStunden.
   * @param _cadStunden the new value of the field cadStunden.
   */
  public void setCadStunden(java.lang.Integer _cadStunden)
  {
    cadStunden = _cadStunden;
  }

  private java.lang.Double werkzeugKosten;

  /**
   * Gets the field werkzeugKosten.
   * @return the value of the field werkzeugKosten; may be null.
   */
  public java.lang.Double getWerkzeugKosten()
  {
    return werkzeugKosten;
  }

  /**
   * Sets the field werkzeugKosten.
   * @param _werkzeugKosten the new value of the field werkzeugKosten.
   */
  public void setWerkzeugKosten(java.lang.Double _werkzeugKosten)
  {
    werkzeugKosten = _werkzeugKosten;
  }

  private java.lang.Double extKosten;

  /**
   * Gets the field extKosten.
   * @return the value of the field extKosten; may be null.
   */
  public java.lang.Double getExtKosten()
  {
    return extKosten;
  }

  /**
   * Sets the field extKosten.
   * @param _extKosten the new value of the field extKosten.
   */
  public void setExtKosten(java.lang.Double _extKosten)
  {
    extKosten = _extKosten;
  }

  private java.lang.Integer gesamtStunden;

  /**
   * Gets the field gesamtStunden.
   * @return the value of the field gesamtStunden; may be null.
   */
  public java.lang.Integer getGesamtStunden()
  {
    return gesamtStunden;
  }

  /**
   * Sets the field gesamtStunden.
   * @param _gesamtStunden the new value of the field gesamtStunden.
   */
  public void setGesamtStunden(java.lang.Integer _gesamtStunden)
  {
    gesamtStunden = _gesamtStunden;
  }

  private java.lang.Double gesamtKosten;

  /**
   * Gets the field gesamtKosten.
   * @return the value of the field gesamtKosten; may be null.
   */
  public java.lang.Double getGesamtKosten()
  {
    return gesamtKosten;
  }

  /**
   * Sets the field gesamtKosten.
   * @param _gesamtKosten the new value of the field gesamtKosten.
   */
  public void setGesamtKosten(java.lang.Double _gesamtKosten)
  {
    gesamtKosten = _gesamtKosten;
  }

}
