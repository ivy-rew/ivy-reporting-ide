package de.hummel.pep.go;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Kontakt", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
@javax.persistence.Entity
@javax.persistence.Table(name="Kontakt")
public class Kontakt extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -7728455731066096124L;

  /**
   * Identifier
   */
  @javax.persistence.Id
  @javax.persistence.GeneratedValue
  private java.lang.Integer id;

  /**
   * Gets the field id.
   * @return the value of the field id; may be null.
   */
  public java.lang.Integer getId()
  {
    return id;
  }

  /**
   * Sets the field id.
   * @param _id the new value of the field id.
   */
  public void setId(java.lang.Integer _id)
  {
    id = _id;
  }

  private java.lang.String strasse;

  /**
   * Gets the field strasse.
   * @return the value of the field strasse; may be null.
   */
  public java.lang.String getStrasse()
  {
    return strasse;
  }

  /**
   * Sets the field strasse.
   * @param _strasse the new value of the field strasse.
   */
  public void setStrasse(java.lang.String _strasse)
  {
    strasse = _strasse;
  }

}
