package de.hummel.pep.processes;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Fertigungsspezifikationen", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Fertigungsspezifikationen extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -2266476404262012715L;

  private java.lang.Boolean werkzeug;

  /**
   * Gets the field werkzeug.
   * @return the value of the field werkzeug; may be null.
   */
  public java.lang.Boolean getWerkzeug()
  {
    return werkzeug;
  }

  /**
   * Sets the field werkzeug.
   * @param _werkzeug the new value of the field werkzeug.
   */
  public void setWerkzeug(java.lang.Boolean _werkzeug)
  {
    werkzeug = _werkzeug;
  }

  private java.lang.Boolean muster;

  /**
   * Gets the field muster.
   * @return the value of the field muster; may be null.
   */
  public java.lang.Boolean getMuster()
  {
    return muster;
  }

  /**
   * Sets the field muster.
   * @param _muster the new value of the field muster.
   */
  public void setMuster(java.lang.Boolean _muster)
  {
    muster = _muster;
  }

  private java.lang.Boolean schutzAspekte;

  /**
   * Gets the field schutzAspekte.
   * @return the value of the field schutzAspekte; may be null.
   */
  public java.lang.Boolean getSchutzAspekte()
  {
    return schutzAspekte;
  }

  /**
   * Sets the field schutzAspekte.
   * @param _schutzAspekte the new value of the field schutzAspekte.
   */
  public void setSchutzAspekte(java.lang.Boolean _schutzAspekte)
  {
    schutzAspekte = _schutzAspekte;
  }

  private java.lang.Boolean prototyp;

  /**
   * Gets the field prototyp.
   * @return the value of the field prototyp; may be null.
   */
  public java.lang.Boolean getPrototyp()
  {
    return prototyp;
  }

  /**
   * Sets the field prototyp.
   * @param _prototyp the new value of the field prototyp.
   */
  public void setPrototyp(java.lang.Boolean _prototyp)
  {
    prototyp = _prototyp;
  }

  private java.lang.Boolean geraeteZertifizierung;

  /**
   * Gets the field geraeteZertifizierung.
   * @return the value of the field geraeteZertifizierung; may be null.
   */
  public java.lang.Boolean getGeraeteZertifizierung()
  {
    return geraeteZertifizierung;
  }

  /**
   * Sets the field geraeteZertifizierung.
   * @param _geraeteZertifizierung the new value of the field geraeteZertifizierung.
   */
  public void setGeraeteZertifizierung(java.lang.Boolean _geraeteZertifizierung)
  {
    geraeteZertifizierung = _geraeteZertifizierung;
  }

}
