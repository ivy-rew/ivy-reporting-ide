package de.hummel.pep.processes;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class LieferantenManagement", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class LieferantenManagement extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 3623193904303480005L;

  private java.lang.String teil;

  /**
   * Gets the field teil.
   * @return the value of the field teil; may be null.
   */
  public java.lang.String getTeil()
  {
    return teil;
  }

  /**
   * Sets the field teil.
   * @param _teil the new value of the field teil.
   */
  public void setTeil(java.lang.String _teil)
  {
    teil = _teil;
  }

  private java.lang.String ort;

  /**
   * Gets the field ort.
   * @return the value of the field ort; may be null.
   */
  public java.lang.String getOrt()
  {
    return ort;
  }

  /**
   * Sets the field ort.
   * @param _ort the new value of the field ort.
   */
  public void setOrt(java.lang.String _ort)
  {
    ort = _ort;
  }

  private java.lang.String bemerkung;

  /**
   * Gets the field bemerkung.
   * @return the value of the field bemerkung; may be null.
   */
  public java.lang.String getBemerkung()
  {
    return bemerkung;
  }

  /**
   * Sets the field bemerkung.
   * @param _bemerkung the new value of the field bemerkung.
   */
  public void setBemerkung(java.lang.String _bemerkung)
  {
    bemerkung = _bemerkung;
  }

}
