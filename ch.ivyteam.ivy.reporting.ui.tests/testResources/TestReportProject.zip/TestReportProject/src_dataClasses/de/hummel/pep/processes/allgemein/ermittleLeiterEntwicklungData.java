package de.hummel.pep.processes.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class ermittleLeiterEntwicklungData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class ermittleLeiterEntwicklungData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 2924147475094381875L;

  private transient java.lang.String geschaeftsbereich;

  /**
   * Gets the field geschaeftsbereich.
   * @return the value of the field geschaeftsbereich; may be null.
   */
  public java.lang.String getGeschaeftsbereich()
  {
    return geschaeftsbereich;
  }

  /**
   * Sets the field geschaeftsbereich.
   * @param _geschaeftsbereich the new value of the field geschaeftsbereich.
   */
  public void setGeschaeftsbereich(java.lang.String _geschaeftsbereich)
  {
    geschaeftsbereich = _geschaeftsbereich;
  }

  private transient java.lang.String leiterEntwicklung;

  /**
   * Gets the field leiterEntwicklung.
   * @return the value of the field leiterEntwicklung; may be null.
   */
  public java.lang.String getLeiterEntwicklung()
  {
    return leiterEntwicklung;
  }

  /**
   * Sets the field leiterEntwicklung.
   * @param _leiterEntwicklung the new value of the field leiterEntwicklung.
   */
  public void setLeiterEntwicklung(java.lang.String _leiterEntwicklung)
  {
    leiterEntwicklung = _leiterEntwicklung;
  }

}
