package de.hummel.pep.processes;

/**
 * Prozessdaten f�r PEP
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class PEPData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class PEPData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 2767729653519894048L;

  /**
   * Beinhaltet Ivy Username f�r Leiter Entwicklung
   */
  private java.lang.String userLeiterentwicklung;

  /**
   * Gets the field userLeiterentwicklung.
   * @return the value of the field userLeiterentwicklung; may be null.
   */
  public java.lang.String getUserLeiterentwicklung()
  {
    return userLeiterentwicklung;
  }

  /**
   * Sets the field userLeiterentwicklung.
   * @param _userLeiterentwicklung the new value of the field userLeiterentwicklung.
   */
  public void setUserLeiterentwicklung(java.lang.String _userLeiterentwicklung)
  {
    userLeiterentwicklung = _userLeiterentwicklung;
  }

  /**
   * Beinhaltet Icy Username f�r Genehmigungsberechtigten anhand Aufwand
   */
  private java.lang.String userGenehmigungsberechtigter;

  /**
   * Gets the field userGenehmigungsberechtigter.
   * @return the value of the field userGenehmigungsberechtigter; may be null.
   */
  public java.lang.String getUserGenehmigungsberechtigter()
  {
    return userGenehmigungsberechtigter;
  }

  /**
   * Sets the field userGenehmigungsberechtigter.
   * @param _userGenehmigungsberechtigter the new value of the field userGenehmigungsberechtigter.
   */
  public void setUserGenehmigungsberechtigter(java.lang.String _userGenehmigungsberechtigter)
  {
    userGenehmigungsberechtigter = _userGenehmigungsberechtigter;
  }

  /**
   * Beinhaltet Ivy Username f�r PL
   */
  private java.lang.String userProjektleiter;

  /**
   * Gets the field userProjektleiter.
   * @return the value of the field userProjektleiter; may be null.
   */
  public java.lang.String getUserProjektleiter()
  {
    return userProjektleiter;
  }

  /**
   * Sets the field userProjektleiter.
   * @param _userProjektleiter the new value of the field userProjektleiter.
   */
  public void setUserProjektleiter(java.lang.String _userProjektleiter)
  {
    userProjektleiter = _userProjektleiter;
  }

  /**
   * Beinhaltet Ivy Username f�r Konstruktion
   */
  private java.lang.String userKonstruktion;

  /**
   * Gets the field userKonstruktion.
   * @return the value of the field userKonstruktion; may be null.
   */
  public java.lang.String getUserKonstruktion()
  {
    return userKonstruktion;
  }

  /**
   * Sets the field userKonstruktion.
   * @param _userKonstruktion the new value of the field userKonstruktion.
   */
  public void setUserKonstruktion(java.lang.String _userKonstruktion)
  {
    userKonstruktion = _userKonstruktion;
  }

  private de.hummel.pep.go.Produktentwicklung produktentwicklung;

  /**
   * Gets the field produktentwicklung.
   * @return the value of the field produktentwicklung; may be null.
   */
  public de.hummel.pep.go.Produktentwicklung getProduktentwicklung()
  {
    return produktentwicklung;
  }

  /**
   * Sets the field produktentwicklung.
   * @param _produktentwicklung the new value of the field produktentwicklung.
   */
  public void setProduktentwicklung(de.hummel.pep.go.Produktentwicklung _produktentwicklung)
  {
    produktentwicklung = _produktentwicklung;
  }

  private de.hummel.pep.processes.Entwicklungsschritte entwicklungsschritte;

  /**
   * Gets the field entwicklungsschritte.
   * @return the value of the field entwicklungsschritte; may be null.
   */
  public de.hummel.pep.processes.Entwicklungsschritte getEntwicklungsschritte()
  {
    return entwicklungsschritte;
  }

  /**
   * Sets the field entwicklungsschritte.
   * @param _entwicklungsschritte the new value of the field entwicklungsschritte.
   */
  public void setEntwicklungsschritte(de.hummel.pep.processes.Entwicklungsschritte _entwicklungsschritte)
  {
    entwicklungsschritte = _entwicklungsschritte;
  }

  private ch.ivyteam.ivy.scripting.objects.List<de.hummel.pep.processes.LieferantenManagement> lieferantenManagement;

  /**
   * Gets the field lieferantenManagement.
   * @return the value of the field lieferantenManagement; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<de.hummel.pep.processes.LieferantenManagement> getLieferantenManagement()
  {
    return lieferantenManagement;
  }

  /**
   * Sets the field lieferantenManagement.
   * @param _lieferantenManagement the new value of the field lieferantenManagement.
   */
  public void setLieferantenManagement(ch.ivyteam.ivy.scripting.objects.List<de.hummel.pep.processes.LieferantenManagement> _lieferantenManagement)
  {
    lieferantenManagement = _lieferantenManagement;
  }

  private java.lang.String userProduktmanagement;

  /**
   * Gets the field userProduktmanagement.
   * @return the value of the field userProduktmanagement; may be null.
   */
  public java.lang.String getUserProduktmanagement()
  {
    return userProduktmanagement;
  }

  /**
   * Sets the field userProduktmanagement.
   * @param _userProduktmanagement the new value of the field userProduktmanagement.
   */
  public void setUserProduktmanagement(java.lang.String _userProduktmanagement)
  {
    userProduktmanagement = _userProduktmanagement;
  }

  private java.lang.String userAntragsteller;

  /**
   * Gets the field userAntragsteller.
   * @return the value of the field userAntragsteller; may be null.
   */
  public java.lang.String getUserAntragsteller()
  {
    return userAntragsteller;
  }

  /**
   * Sets the field userAntragsteller.
   * @param _userAntragsteller the new value of the field userAntragsteller.
   */
  public void setUserAntragsteller(java.lang.String _userAntragsteller)
  {
    userAntragsteller = _userAntragsteller;
  }

  private de.hummel.pep.processes.MusterProduktionSpezifikationen musterProduktionsSpezifikationen;

  /**
   * Gets the field musterProduktionsSpezifikationen.
   * @return the value of the field musterProduktionsSpezifikationen; may be null.
   */
  public de.hummel.pep.processes.MusterProduktionSpezifikationen getMusterProduktionsSpezifikationen()
  {
    return musterProduktionsSpezifikationen;
  }

  /**
   * Sets the field musterProduktionsSpezifikationen.
   * @param _musterProduktionsSpezifikationen the new value of the field musterProduktionsSpezifikationen.
   */
  public void setMusterProduktionsSpezifikationen(de.hummel.pep.processes.MusterProduktionSpezifikationen _musterProduktionsSpezifikationen)
  {
    musterProduktionsSpezifikationen = _musterProduktionsSpezifikationen;
  }

  private de.hummel.pep.processes.Projektspezifikationen projektspezifikationen;

  /**
   * Gets the field projektspezifikationen.
   * @return the value of the field projektspezifikationen; may be null.
   */
  public de.hummel.pep.processes.Projektspezifikationen getProjektspezifikationen()
  {
    return projektspezifikationen;
  }

  /**
   * Sets the field projektspezifikationen.
   * @param _projektspezifikationen the new value of the field projektspezifikationen.
   */
  public void setProjektspezifikationen(de.hummel.pep.processes.Projektspezifikationen _projektspezifikationen)
  {
    projektspezifikationen = _projektspezifikationen;
  }

  private de.hummel.pep.processes.Aufwand aufwand;

  /**
   * Gets the field aufwand.
   * @return the value of the field aufwand; may be null.
   */
  public de.hummel.pep.processes.Aufwand getAufwand()
  {
    return aufwand;
  }

  /**
   * Sets the field aufwand.
   * @param _aufwand the new value of the field aufwand.
   */
  public void setAufwand(de.hummel.pep.processes.Aufwand _aufwand)
  {
    aufwand = _aufwand;
  }

  private java.lang.Boolean wiedervorlage;

  /**
   * Gets the field wiedervorlage.
   * @return the value of the field wiedervorlage; may be null.
   */
  public java.lang.Boolean getWiedervorlage()
  {
    return wiedervorlage;
  }

  /**
   * Sets the field wiedervorlage.
   * @param _wiedervorlage the new value of the field wiedervorlage.
   */
  public void setWiedervorlage(java.lang.Boolean _wiedervorlage)
  {
    wiedervorlage = _wiedervorlage;
  }

  private de.hummel.pep.processes.Fertigungsspezifikationen fertigungsSpezifikationen;

  /**
   * Gets the field fertigungsSpezifikationen.
   * @return the value of the field fertigungsSpezifikationen; may be null.
   */
  public de.hummel.pep.processes.Fertigungsspezifikationen getFertigungsSpezifikationen()
  {
    return fertigungsSpezifikationen;
  }

  /**
   * Sets the field fertigungsSpezifikationen.
   * @param _fertigungsSpezifikationen the new value of the field fertigungsSpezifikationen.
   */
  public void setFertigungsSpezifikationen(de.hummel.pep.processes.Fertigungsspezifikationen _fertigungsSpezifikationen)
  {
    fertigungsSpezifikationen = _fertigungsSpezifikationen;
  }

  /**
   * Beinhaltet Word Dokument
   */
  private ch.ivyteam.ivy.scripting.objects.File laufzettel;

  /**
   * Gets the field laufzettel.
   * @return the value of the field laufzettel; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.File getLaufzettel()
  {
    return laufzettel;
  }

  /**
   * Sets the field laufzettel.
   * @param _laufzettel the new value of the field laufzettel.
   */
  public void setLaufzettel(ch.ivyteam.ivy.scripting.objects.File _laufzettel)
  {
    laufzettel = _laufzettel;
  }

  private java.lang.String userATEX;

  /**
   * Gets the field userATEX.
   * @return the value of the field userATEX; may be null.
   */
  public java.lang.String getUserATEX()
  {
    return userATEX;
  }

  /**
   * Sets the field userATEX.
   * @param _userATEX the new value of the field userATEX.
   */
  public void setUserATEX(java.lang.String _userATEX)
  {
    userATEX = _userATEX;
  }

  private java.lang.String userMEDTECH;

  /**
   * Gets the field userMEDTECH.
   * @return the value of the field userMEDTECH; may be null.
   */
  public java.lang.String getUserMEDTECH()
  {
    return userMEDTECH;
  }

  /**
   * Sets the field userMEDTECH.
   * @param _userMEDTECH the new value of the field userMEDTECH.
   */
  public void setUserMEDTECH(java.lang.String _userMEDTECH)
  {
    userMEDTECH = _userMEDTECH;
  }

  private java.lang.Boolean tempBOOLEAN;

  /**
   * Gets the field tempBOOLEAN.
   * @return the value of the field tempBOOLEAN; may be null.
   */
  public java.lang.Boolean getTempBOOLEAN()
  {
    return tempBOOLEAN;
  }

  /**
   * Sets the field tempBOOLEAN.
   * @param _tempBOOLEAN the new value of the field tempBOOLEAN.
   */
  public void setTempBOOLEAN(java.lang.Boolean _tempBOOLEAN)
  {
    tempBOOLEAN = _tempBOOLEAN;
  }

}
