package de.hummel.pep.go;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Produktentwicklung", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
@javax.persistence.Entity
@javax.persistence.Table(name="pep_produktentwicklung")
public class Produktentwicklung extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 5273613706023677809L;

  /**
   * Identifier
   */
  @javax.persistence.Id
  @javax.persistence.GeneratedValue
  private java.lang.Integer id;

  /**
   * Gets the field id.
   * @return the value of the field id; may be null.
   */
  public java.lang.Integer getId()
  {
    return id;
  }

  /**
   * Sets the field id.
   * @param _id the new value of the field id.
   */
  public void setId(java.lang.Integer _id)
  {
    id = _id;
  }

  /**
   * Verkn�pfung zum Ivy Prozess
   */
  private java.lang.Integer prozessId;

  /**
   * Gets the field prozessId.
   * @return the value of the field prozessId; may be null.
   */
  public java.lang.Integer getProzessId()
  {
    return prozessId;
  }

  /**
   * Sets the field prozessId.
   * @param _prozessId the new value of the field prozessId.
   */
  public void setProzessId(java.lang.Integer _prozessId)
  {
    prozessId = _prozessId;
  }

  private java.lang.String antragsteller;

  /**
   * Gets the field antragsteller.
   * @return the value of the field antragsteller; may be null.
   */
  public java.lang.String getAntragsteller()
  {
    return antragsteller;
  }

  /**
   * Sets the field antragsteller.
   * @param _antragsteller the new value of the field antragsteller.
   */
  public void setAntragsteller(java.lang.String _antragsteller)
  {
    antragsteller = _antragsteller;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date antragsDatum;

  /**
   * Gets the field antragsDatum.
   * @return the value of the field antragsDatum; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getAntragsDatum()
  {
    return antragsDatum;
  }

  /**
   * Sets the field antragsDatum.
   * @param _antragsDatum the new value of the field antragsDatum.
   */
  public void setAntragsDatum(ch.ivyteam.ivy.scripting.objects.Date _antragsDatum)
  {
    antragsDatum = _antragsDatum;
  }

  private java.lang.String geschaeftsbereich;

  /**
   * Gets the field geschaeftsbereich.
   * @return the value of the field geschaeftsbereich; may be null.
   */
  public java.lang.String getGeschaeftsbereich()
  {
    return geschaeftsbereich;
  }

  /**
   * Sets the field geschaeftsbereich.
   * @param _geschaeftsbereich the new value of the field geschaeftsbereich.
   */
  public void setGeschaeftsbereich(java.lang.String _geschaeftsbereich)
  {
    geschaeftsbereich = _geschaeftsbereich;
  }

  private java.lang.String warengruppe;

  /**
   * Gets the field warengruppe.
   * @return the value of the field warengruppe; may be null.
   */
  public java.lang.String getWarengruppe()
  {
    return warengruppe;
  }

  /**
   * Sets the field warengruppe.
   * @param _warengruppe the new value of the field warengruppe.
   */
  public void setWarengruppe(java.lang.String _warengruppe)
  {
    warengruppe = _warengruppe;
  }

  private java.lang.String entwicklungstyp;

  /**
   * Gets the field entwicklungstyp.
   * @return the value of the field entwicklungstyp; may be null.
   */
  public java.lang.String getEntwicklungstyp()
  {
    return entwicklungstyp;
  }

  /**
   * Sets the field entwicklungstyp.
   * @param _entwicklungstyp the new value of the field entwicklungstyp.
   */
  public void setEntwicklungstyp(java.lang.String _entwicklungstyp)
  {
    entwicklungstyp = _entwicklungstyp;
  }

  private java.lang.String projektnummer;

  /**
   * Gets the field projektnummer.
   * @return the value of the field projektnummer; may be null.
   */
  public java.lang.String getProjektnummer()
  {
    return projektnummer;
  }

  /**
   * Sets the field projektnummer.
   * @param _projektnummer the new value of the field projektnummer.
   */
  public void setProjektnummer(java.lang.String _projektnummer)
  {
    projektnummer = _projektnummer;
  }

  private java.lang.Integer prioritaet;

  /**
   * Gets the field prioritaet.
   * @return the value of the field prioritaet; may be null.
   */
  public java.lang.Integer getPrioritaet()
  {
    return prioritaet;
  }

  /**
   * Sets the field prioritaet.
   * @param _prioritaet the new value of the field prioritaet.
   */
  public void setPrioritaet(java.lang.Integer _prioritaet)
  {
    prioritaet = _prioritaet;
  }

  private java.lang.String ansprechpartner;

  /**
   * Gets the field ansprechpartner.
   * @return the value of the field ansprechpartner; may be null.
   */
  public java.lang.String getAnsprechpartner()
  {
    return ansprechpartner;
  }

  /**
   * Sets the field ansprechpartner.
   * @param _ansprechpartner the new value of the field ansprechpartner.
   */
  public void setAnsprechpartner(java.lang.String _ansprechpartner)
  {
    ansprechpartner = _ansprechpartner;
  }

  private java.lang.Integer menge;

  /**
   * Gets the field menge.
   * @return the value of the field menge; may be null.
   */
  public java.lang.Integer getMenge()
  {
    return menge;
  }

  /**
   * Sets the field menge.
   * @param _menge the new value of the field menge.
   */
  public void setMenge(java.lang.Integer _menge)
  {
    menge = _menge;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date angebotBis;

  /**
   * Gets the field angebotBis.
   * @return the value of the field angebotBis; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getAngebotBis()
  {
    return angebotBis;
  }

  /**
   * Sets the field angebotBis.
   * @param _angebotBis the new value of the field angebotBis.
   */
  public void setAngebotBis(ch.ivyteam.ivy.scripting.objects.Date _angebotBis)
  {
    angebotBis = _angebotBis;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date kdZeichnungBis;

  /**
   * Gets the field kdZeichnungBis.
   * @return the value of the field kdZeichnungBis; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getKdZeichnungBis()
  {
    return kdZeichnungBis;
  }

  /**
   * Sets the field kdZeichnungBis.
   * @param _kdZeichnungBis the new value of the field kdZeichnungBis.
   */
  public void setKdZeichnungBis(ch.ivyteam.ivy.scripting.objects.Date _kdZeichnungBis)
  {
    kdZeichnungBis = _kdZeichnungBis;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date musterBis;

  /**
   * Gets the field musterBis.
   * @return the value of the field musterBis; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getMusterBis()
  {
    return musterBis;
  }

  /**
   * Sets the field musterBis.
   * @param _musterBis the new value of the field musterBis.
   */
  public void setMusterBis(ch.ivyteam.ivy.scripting.objects.Date _musterBis)
  {
    musterBis = _musterBis;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date lieferungBis;

  /**
   * Gets the field lieferungBis.
   * @return the value of the field lieferungBis; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getLieferungBis()
  {
    return lieferungBis;
  }

  /**
   * Sets the field lieferungBis.
   * @param _lieferungBis the new value of the field lieferungBis.
   */
  public void setLieferungBis(ch.ivyteam.ivy.scripting.objects.Date _lieferungBis)
  {
    lieferungBis = _lieferungBis;
  }

  private java.lang.Double zielpreis;

  /**
   * Gets the field zielpreis.
   * @return the value of the field zielpreis; may be null.
   */
  public java.lang.Double getZielpreis()
  {
    return zielpreis;
  }

  /**
   * Sets the field zielpreis.
   * @param _zielpreis the new value of the field zielpreis.
   */
  public void setZielpreis(java.lang.Double _zielpreis)
  {
    zielpreis = _zielpreis;
  }

  private java.lang.Double wettbewerbspreis;

  /**
   * Gets the field wettbewerbspreis.
   * @return the value of the field wettbewerbspreis; may be null.
   */
  public java.lang.Double getWettbewerbspreis()
  {
    return wettbewerbspreis;
  }

  /**
   * Sets the field wettbewerbspreis.
   * @param _wettbewerbspreis the new value of the field wettbewerbspreis.
   */
  public void setWettbewerbspreis(java.lang.Double _wettbewerbspreis)
  {
    wettbewerbspreis = _wettbewerbspreis;
  }

  private java.lang.Boolean kundenfreigabe;

  /**
   * Gets the field kundenfreigabe.
   * @return the value of the field kundenfreigabe; may be null.
   */
  public java.lang.Boolean getKundenfreigabe()
  {
    return kundenfreigabe;
  }

  /**
   * Sets the field kundenfreigabe.
   * @param _kundenfreigabe the new value of the field kundenfreigabe.
   */
  public void setKundenfreigabe(java.lang.Boolean _kundenfreigabe)
  {
    kundenfreigabe = _kundenfreigabe;
  }

  private java.lang.Boolean produktvariante;

  /**
   * Gets the field produktvariante.
   * @return the value of the field produktvariante; may be null.
   */
  public java.lang.Boolean getProduktvariante()
  {
    return produktvariante;
  }

  /**
   * Sets the field produktvariante.
   * @param _produktvariante the new value of the field produktvariante.
   */
  public void setProduktvariante(java.lang.Boolean _produktvariante)
  {
    produktvariante = _produktvariante;
  }

  private java.lang.String material;

  /**
   * Gets the field material.
   * @return the value of the field material; may be null.
   */
  public java.lang.String getMaterial()
  {
    return material;
  }

  /**
   * Sets the field material.
   * @param _material the new value of the field material.
   */
  public void setMaterial(java.lang.String _material)
  {
    material = _material;
  }

  private java.lang.String basisArtikel;

  /**
   * Gets the field basisArtikel.
   * @return the value of the field basisArtikel; may be null.
   */
  public java.lang.String getBasisArtikel()
  {
    return basisArtikel;
  }

  /**
   * Sets the field basisArtikel.
   * @param _basisArtikel the new value of the field basisArtikel.
   */
  public void setBasisArtikel(java.lang.String _basisArtikel)
  {
    basisArtikel = _basisArtikel;
  }

  private java.lang.String zulassungen;

  /**
   * Gets the field zulassungen.
   * @return the value of the field zulassungen; may be null.
   */
  public java.lang.String getZulassungen()
  {
    return zulassungen;
  }

  /**
   * Sets the field zulassungen.
   * @param _zulassungen the new value of the field zulassungen.
   */
  public void setZulassungen(java.lang.String _zulassungen)
  {
    zulassungen = _zulassungen;
  }

  @javax.persistence.Column(length=500)
  private java.lang.String sonstiges;

  /**
   * Gets the field sonstiges.
   * @return the value of the field sonstiges; may be null.
   */
  public java.lang.String getSonstiges()
  {
    return sonstiges;
  }

  /**
   * Sets the field sonstiges.
   * @param _sonstiges the new value of the field sonstiges.
   */
  public void setSonstiges(java.lang.String _sonstiges)
  {
    sonstiges = _sonstiges;
  }

  @javax.persistence.Column(length=500)
  private java.lang.String nutzen;

  /**
   * Gets the field nutzen.
   * @return the value of the field nutzen; may be null.
   */
  public java.lang.String getNutzen()
  {
    return nutzen;
  }

  /**
   * Sets the field nutzen.
   * @param _nutzen the new value of the field nutzen.
   */
  public void setNutzen(java.lang.String _nutzen)
  {
    nutzen = _nutzen;
  }

  private java.lang.String aufwandStunden;

  /**
   * Gets the field aufwandStunden.
   * @return the value of the field aufwandStunden; may be null.
   */
  public java.lang.String getAufwandStunden()
  {
    return aufwandStunden;
  }

  /**
   * Sets the field aufwandStunden.
   * @param _aufwandStunden the new value of the field aufwandStunden.
   */
  public void setAufwandStunden(java.lang.String _aufwandStunden)
  {
    aufwandStunden = _aufwandStunden;
  }

  private java.lang.Double aufwandPreis;

  /**
   * Gets the field aufwandPreis.
   * @return the value of the field aufwandPreis; may be null.
   */
  public java.lang.Double getAufwandPreis()
  {
    return aufwandPreis;
  }

  /**
   * Sets the field aufwandPreis.
   * @param _aufwandPreis the new value of the field aufwandPreis.
   */
  public void setAufwandPreis(java.lang.Double _aufwandPreis)
  {
    aufwandPreis = _aufwandPreis;
  }

  private java.lang.String ablehnungsgrund;

  /**
   * Gets the field ablehnungsgrund.
   * @return the value of the field ablehnungsgrund; may be null.
   */
  public java.lang.String getAblehnungsgrund()
  {
    return ablehnungsgrund;
  }

  /**
   * Sets the field ablehnungsgrund.
   * @param _ablehnungsgrund the new value of the field ablehnungsgrund.
   */
  public void setAblehnungsgrund(java.lang.String _ablehnungsgrund)
  {
    ablehnungsgrund = _ablehnungsgrund;
  }

  private java.lang.String stichwort;

  /**
   * Gets the field stichwort.
   * @return the value of the field stichwort; may be null.
   */
  public java.lang.String getStichwort()
  {
    return stichwort;
  }

  /**
   * Sets the field stichwort.
   * @param _stichwort the new value of the field stichwort.
   */
  public void setStichwort(java.lang.String _stichwort)
  {
    stichwort = _stichwort;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date starttermin;

  /**
   * Gets the field starttermin.
   * @return the value of the field starttermin; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getStarttermin()
  {
    return starttermin;
  }

  /**
   * Sets the field starttermin.
   * @param _starttermin the new value of the field starttermin.
   */
  public void setStarttermin(ch.ivyteam.ivy.scripting.objects.Date _starttermin)
  {
    starttermin = _starttermin;
  }

  private java.lang.String projektleiter;

  /**
   * Gets the field projektleiter.
   * @return the value of the field projektleiter; may be null.
   */
  public java.lang.String getProjektleiter()
  {
    return projektleiter;
  }

  /**
   * Sets the field projektleiter.
   * @param _projektleiter the new value of the field projektleiter.
   */
  public void setProjektleiter(java.lang.String _projektleiter)
  {
    projektleiter = _projektleiter;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date endtermin;

  /**
   * Gets the field endtermin.
   * @return the value of the field endtermin; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getEndtermin()
  {
    return endtermin;
  }

  /**
   * Sets the field endtermin.
   * @param _endtermin the new value of the field endtermin.
   */
  public void setEndtermin(ch.ivyteam.ivy.scripting.objects.Date _endtermin)
  {
    endtermin = _endtermin;
  }

  @javax.persistence.Column(length=500)
  private java.lang.String begruendungErstfertigung;

  /**
   * Gets the field begruendungErstfertigung.
   * @return the value of the field begruendungErstfertigung; may be null.
   */
  public java.lang.String getBegruendungErstfertigung()
  {
    return begruendungErstfertigung;
  }

  /**
   * Sets the field begruendungErstfertigung.
   * @param _begruendungErstfertigung the new value of the field begruendungErstfertigung.
   */
  public void setBegruendungErstfertigung(java.lang.String _begruendungErstfertigung)
  {
    begruendungErstfertigung = _begruendungErstfertigung;
  }

  private java.lang.Boolean antragsGenehmigung;

  /**
   * Gets the field antragsGenehmigung.
   * @return the value of the field antragsGenehmigung; may be null.
   */
  public java.lang.Boolean getAntragsGenehmigung()
  {
    return antragsGenehmigung;
  }

  /**
   * Sets the field antragsGenehmigung.
   * @param _antragsGenehmigung the new value of the field antragsGenehmigung.
   */
  public void setAntragsGenehmigung(java.lang.Boolean _antragsGenehmigung)
  {
    antragsGenehmigung = _antragsGenehmigung;
  }

  private java.lang.String antragAblehnungsGrund;

  /**
   * Gets the field antragAblehnungsGrund.
   * @return the value of the field antragAblehnungsGrund; may be null.
   */
  public java.lang.String getAntragAblehnungsGrund()
  {
    return antragAblehnungsGrund;
  }

  /**
   * Sets the field antragAblehnungsGrund.
   * @param _antragAblehnungsGrund the new value of the field antragAblehnungsGrund.
   */
  public void setAntragAblehnungsGrund(java.lang.String _antragAblehnungsGrund)
  {
    antragAblehnungsGrund = _antragAblehnungsGrund;
  }

  private java.lang.String antragSonstigesGrund;

  /**
   * Gets the field antragSonstigesGrund.
   * @return the value of the field antragSonstigesGrund; may be null.
   */
  public java.lang.String getAntragSonstigesGrund()
  {
    return antragSonstigesGrund;
  }

  /**
   * Sets the field antragSonstigesGrund.
   * @param _antragSonstigesGrund the new value of the field antragSonstigesGrund.
   */
  public void setAntragSonstigesGrund(java.lang.String _antragSonstigesGrund)
  {
    antragSonstigesGrund = _antragSonstigesGrund;
  }

  private java.lang.Boolean freigabeZeichnung;

  /**
   * Gets the field freigabeZeichnung.
   * @return the value of the field freigabeZeichnung; may be null.
   */
  public java.lang.Boolean getFreigabeZeichnung()
  {
    return freigabeZeichnung;
  }

  /**
   * Sets the field freigabeZeichnung.
   * @param _freigabeZeichnung the new value of the field freigabeZeichnung.
   */
  public void setFreigabeZeichnung(java.lang.Boolean _freigabeZeichnung)
  {
    freigabeZeichnung = _freigabeZeichnung;
  }

  private java.lang.Boolean freigabePrototyp;

  /**
   * Gets the field freigabePrototyp.
   * @return the value of the field freigabePrototyp; may be null.
   */
  public java.lang.Boolean getFreigabePrototyp()
  {
    return freigabePrototyp;
  }

  /**
   * Sets the field freigabePrototyp.
   * @param _freigabePrototyp the new value of the field freigabePrototyp.
   */
  public void setFreigabePrototyp(java.lang.Boolean _freigabePrototyp)
  {
    freigabePrototyp = _freigabePrototyp;
  }

  private java.lang.Boolean freigabeSerienfertigung;

  /**
   * Gets the field freigabeSerienfertigung.
   * @return the value of the field freigabeSerienfertigung; may be null.
   */
  public java.lang.Boolean getFreigabeSerienfertigung()
  {
    return freigabeSerienfertigung;
  }

  /**
   * Sets the field freigabeSerienfertigung.
   * @param _freigabeSerienfertigung the new value of the field freigabeSerienfertigung.
   */
  public void setFreigabeSerienfertigung(java.lang.Boolean _freigabeSerienfertigung)
  {
    freigabeSerienfertigung = _freigabeSerienfertigung;
  }

  private java.lang.Boolean freigabeKonzept;

  /**
   * Gets the field freigabeKonzept.
   * @return the value of the field freigabeKonzept; may be null.
   */
  public java.lang.Boolean getFreigabeKonzept()
  {
    return freigabeKonzept;
  }

  /**
   * Sets the field freigabeKonzept.
   * @param _freigabeKonzept the new value of the field freigabeKonzept.
   */
  public void setFreigabeKonzept(java.lang.Boolean _freigabeKonzept)
  {
    freigabeKonzept = _freigabeKonzept;
  }

  private java.lang.String ablehnungsgrundSonstiges;

  /**
   * Gets the field ablehnungsgrundSonstiges.
   * @return the value of the field ablehnungsgrundSonstiges; may be null.
   */
  public java.lang.String getAblehnungsgrundSonstiges()
  {
    return ablehnungsgrundSonstiges;
  }

  /**
   * Sets the field ablehnungsgrundSonstiges.
   * @param _ablehnungsgrundSonstiges the new value of the field ablehnungsgrundSonstiges.
   */
  public void setAblehnungsgrundSonstiges(java.lang.String _ablehnungsgrundSonstiges)
  {
    ablehnungsgrundSonstiges = _ablehnungsgrundSonstiges;
  }

  private java.lang.String referenzProjektnummer;

  /**
   * Gets the field referenzProjektnummer.
   * @return the value of the field referenzProjektnummer; may be null.
   */
  public java.lang.String getReferenzProjektnummer()
  {
    return referenzProjektnummer;
  }

  /**
   * Sets the field referenzProjektnummer.
   * @param _referenzProjektnummer the new value of the field referenzProjektnummer.
   */
  public void setReferenzProjektnummer(java.lang.String _referenzProjektnummer)
  {
    referenzProjektnummer = _referenzProjektnummer;
  }

  private java.lang.String freigabeSerienfertigungBegruendung;

  /**
   * Gets the field freigabeSerienfertigungBegruendung.
   * @return the value of the field freigabeSerienfertigungBegruendung; may be null.
   */
  public java.lang.String getFreigabeSerienfertigungBegruendung()
  {
    return freigabeSerienfertigungBegruendung;
  }

  /**
   * Sets the field freigabeSerienfertigungBegruendung.
   * @param _freigabeSerienfertigungBegruendung the new value of the field freigabeSerienfertigungBegruendung.
   */
  public void setFreigabeSerienfertigungBegruendung(java.lang.String _freigabeSerienfertigungBegruendung)
  {
    freigabeSerienfertigungBegruendung = _freigabeSerienfertigungBegruendung;
  }

  @org.hibernate.annotations.Type(type = "ch.ivyteam.ivy.process.data.persistence.usertype.DateUserType")
  private ch.ivyteam.ivy.scripting.objects.Date freigabeSerienfertigungDatum;

  /**
   * Gets the field freigabeSerienfertigungDatum.
   * @return the value of the field freigabeSerienfertigungDatum; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getFreigabeSerienfertigungDatum()
  {
    return freigabeSerienfertigungDatum;
  }

  /**
   * Sets the field freigabeSerienfertigungDatum.
   * @param _freigabeSerienfertigungDatum the new value of the field freigabeSerienfertigungDatum.
   */
  public void setFreigabeSerienfertigungDatum(ch.ivyteam.ivy.scripting.objects.Date _freigabeSerienfertigungDatum)
  {
    freigabeSerienfertigungDatum = _freigabeSerienfertigungDatum;
  }

  private java.lang.String freigabeSerienfertigungUser;

  /**
   * Gets the field freigabeSerienfertigungUser.
   * @return the value of the field freigabeSerienfertigungUser; may be null.
   */
  public java.lang.String getFreigabeSerienfertigungUser()
  {
    return freigabeSerienfertigungUser;
  }

  /**
   * Sets the field freigabeSerienfertigungUser.
   * @param _freigabeSerienfertigungUser the new value of the field freigabeSerienfertigungUser.
   */
  public void setFreigabeSerienfertigungUser(java.lang.String _freigabeSerienfertigungUser)
  {
    freigabeSerienfertigungUser = _freigabeSerienfertigungUser;
  }

  private java.lang.String freigabeSerienfertigungSonstiges;

  /**
   * Gets the field freigabeSerienfertigungSonstiges.
   * @return the value of the field freigabeSerienfertigungSonstiges; may be null.
   */
  public java.lang.String getFreigabeSerienfertigungSonstiges()
  {
    return freigabeSerienfertigungSonstiges;
  }

  /**
   * Sets the field freigabeSerienfertigungSonstiges.
   * @param _freigabeSerienfertigungSonstiges the new value of the field freigabeSerienfertigungSonstiges.
   */
  public void setFreigabeSerienfertigungSonstiges(java.lang.String _freigabeSerienfertigungSonstiges)
  {
    freigabeSerienfertigungSonstiges = _freigabeSerienfertigungSonstiges;
  }

}
