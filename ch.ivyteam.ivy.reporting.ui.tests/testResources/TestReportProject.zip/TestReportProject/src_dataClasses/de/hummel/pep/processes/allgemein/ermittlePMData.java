package de.hummel.pep.processes.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class ermittlePMData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class ermittlePMData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 3623193900781864590L;

  private java.lang.String warengruppe;

  /**
   * Gets the field warengruppe.
   * @return the value of the field warengruppe; may be null.
   */
  public java.lang.String getWarengruppe()
  {
    return warengruppe;
  }

  /**
   * Sets the field warengruppe.
   * @param _warengruppe the new value of the field warengruppe.
   */
  public void setWarengruppe(java.lang.String _warengruppe)
  {
    warengruppe = _warengruppe;
  }

  private java.lang.String pm;

  /**
   * Gets the field pm.
   * @return the value of the field pm; may be null.
   */
  public java.lang.String getPm()
  {
    return pm;
  }

  /**
   * Sets the field pm.
   * @param _pm the new value of the field pm.
   */
  public void setPm(java.lang.String _pm)
  {
    pm = _pm;
  }

  private java.lang.String geschaeftsbereich;

  /**
   * Gets the field geschaeftsbereich.
   * @return the value of the field geschaeftsbereich; may be null.
   */
  public java.lang.String getGeschaeftsbereich()
  {
    return geschaeftsbereich;
  }

  /**
   * Sets the field geschaeftsbereich.
   * @param _geschaeftsbereich the new value of the field geschaeftsbereich.
   */
  public void setGeschaeftsbereich(java.lang.String _geschaeftsbereich)
  {
    geschaeftsbereich = _geschaeftsbereich;
  }

}
