package de.hummel.pep.processes;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Entwicklungsschritte", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Entwicklungsschritte extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 6572898867186856701L;

  private java.lang.Boolean projektAnlegen;

  /**
   * Gets the field projektAnlegen.
   * @return the value of the field projektAnlegen; may be null.
   */
  public java.lang.Boolean getProjektAnlegen()
  {
    return projektAnlegen;
  }

  /**
   * Sets the field projektAnlegen.
   * @param _projektAnlegen the new value of the field projektAnlegen.
   */
  public void setProjektAnlegen(java.lang.Boolean _projektAnlegen)
  {
    projektAnlegen = _projektAnlegen;
  }

  private java.lang.Boolean prototyp;

  /**
   * Gets the field prototyp.
   * @return the value of the field prototyp; may be null.
   */
  public java.lang.Boolean getPrototyp()
  {
    return prototyp;
  }

  /**
   * Sets the field prototyp.
   * @param _prototyp the new value of the field prototyp.
   */
  public void setPrototyp(java.lang.Boolean _prototyp)
  {
    prototyp = _prototyp;
  }

  private java.lang.Boolean konstruktion;

  /**
   * Gets the field konstruktion.
   * @return the value of the field konstruktion; may be null.
   */
  public java.lang.Boolean getKonstruktion()
  {
    return konstruktion;
  }

  /**
   * Sets the field konstruktion.
   * @param _konstruktion the new value of the field konstruktion.
   */
  public void setKonstruktion(java.lang.Boolean _konstruktion)
  {
    konstruktion = _konstruktion;
  }

  private java.lang.Boolean erstfertigung;

  /**
   * Gets the field erstfertigung.
   * @return the value of the field erstfertigung; may be null.
   */
  public java.lang.Boolean getErstfertigung()
  {
    return erstfertigung;
  }

  /**
   * Sets the field erstfertigung.
   * @param _erstfertigung the new value of the field erstfertigung.
   */
  public void setErstfertigung(java.lang.Boolean _erstfertigung)
  {
    erstfertigung = _erstfertigung;
  }

  private java.lang.Boolean risikobewertung;

  /**
   * Gets the field risikobewertung.
   * @return the value of the field risikobewertung; may be null.
   */
  public java.lang.Boolean getRisikobewertung()
  {
    return risikobewertung;
  }

  /**
   * Sets the field risikobewertung.
   * @param _risikobewertung the new value of the field risikobewertung.
   */
  public void setRisikobewertung(java.lang.Boolean _risikobewertung)
  {
    risikobewertung = _risikobewertung;
  }

  private java.lang.Boolean serienfreigabe;

  /**
   * Gets the field serienfreigabe.
   * @return the value of the field serienfreigabe; may be null.
   */
  public java.lang.Boolean getSerienfreigabe()
  {
    return serienfreigabe;
  }

  /**
   * Sets the field serienfreigabe.
   * @param _serienfreigabe the new value of the field serienfreigabe.
   */
  public void setSerienfreigabe(java.lang.Boolean _serienfreigabe)
  {
    serienfreigabe = _serienfreigabe;
  }

  private java.lang.String erstfertigungBegruendung;

  /**
   * Gets the field erstfertigungBegruendung.
   * @return the value of the field erstfertigungBegruendung; may be null.
   */
  public java.lang.String getErstfertigungBegruendung()
  {
    return erstfertigungBegruendung;
  }

  /**
   * Sets the field erstfertigungBegruendung.
   * @param _erstfertigungBegruendung the new value of the field erstfertigungBegruendung.
   */
  public void setErstfertigungBegruendung(java.lang.String _erstfertigungBegruendung)
  {
    erstfertigungBegruendung = _erstfertigungBegruendung;
  }

  private java.lang.String serienfreigabeBegruendung;

  /**
   * Gets the field serienfreigabeBegruendung.
   * @return the value of the field serienfreigabeBegruendung; may be null.
   */
  public java.lang.String getSerienfreigabeBegruendung()
  {
    return serienfreigabeBegruendung;
  }

  /**
   * Sets the field serienfreigabeBegruendung.
   * @param _serienfreigabeBegruendung the new value of the field serienfreigabeBegruendung.
   */
  public void setSerienfreigabeBegruendung(java.lang.String _serienfreigabeBegruendung)
  {
    serienfreigabeBegruendung = _serienfreigabeBegruendung;
  }

}
