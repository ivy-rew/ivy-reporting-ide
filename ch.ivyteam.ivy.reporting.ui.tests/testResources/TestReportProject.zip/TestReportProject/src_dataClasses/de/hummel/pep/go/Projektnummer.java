package de.hummel.pep.go;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Projektnummer", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
@javax.persistence.Entity
@javax.persistence.Table(name="projektnummer")
public class Projektnummer extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -1695274484436931933L;

  /**
   * Identifier
   */
  private java.lang.String projektnummer;

  /**
   * Gets the field projektnummer.
   * @return the value of the field projektnummer; may be null.
   */
  public java.lang.String getProjektnummer()
  {
    return projektnummer;
  }

  /**
   * Sets the field projektnummer.
   * @param _projektnummer the new value of the field projektnummer.
   */
  public void setProjektnummer(java.lang.String _projektnummer)
  {
    projektnummer = _projektnummer;
  }

  @javax.persistence.Id
  @javax.persistence.GeneratedValue
  private java.lang.Integer zaehler;

  /**
   * Gets the field zaehler.
   * @return the value of the field zaehler; may be null.
   */
  public java.lang.Integer getZaehler()
  {
    return zaehler;
  }

  /**
   * Sets the field zaehler.
   * @param _zaehler the new value of the field zaehler.
   */
  public void setZaehler(java.lang.Integer _zaehler)
  {
    zaehler = _zaehler;
  }

  private java.util.Date datum;

  /**
   * Gets the field datum.
   * @return the value of the field datum; may be null.
   */
  public java.util.Date getDatum()
  {
    return datum;
  }

  /**
   * Sets the field datum.
   * @param _datum the new value of the field datum.
   */
  public void setDatum(java.util.Date _datum)
  {
    datum = _datum;
  }

}
