package de.hummel.pep.processes;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Projektspezifikationen", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Projektspezifikationen extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -4226637141076710775L;

  private java.lang.Boolean kundenfreigabe;

  /**
   * Gets the field kundenfreigabe.
   * @return the value of the field kundenfreigabe; may be null.
   */
  public java.lang.Boolean getKundenfreigabe()
  {
    return kundenfreigabe;
  }

  /**
   * Sets the field kundenfreigabe.
   * @param _kundenfreigabe the new value of the field kundenfreigabe.
   */
  public void setKundenfreigabe(java.lang.Boolean _kundenfreigabe)
  {
    kundenfreigabe = _kundenfreigabe;
  }

  private java.lang.Boolean lastenheft;

  /**
   * Gets the field lastenheft.
   * @return the value of the field lastenheft; may be null.
   */
  public java.lang.Boolean getLastenheft()
  {
    return lastenheft;
  }

  /**
   * Sets the field lastenheft.
   * @param _lastenheft the new value of the field lastenheft.
   */
  public void setLastenheft(java.lang.Boolean _lastenheft)
  {
    lastenheft = _lastenheft;
  }

  private java.lang.Boolean fmea;

  /**
   * Gets the field fmea.
   * @return the value of the field fmea; may be null.
   */
  public java.lang.Boolean getFmea()
  {
    return fmea;
  }

  /**
   * Sets the field fmea.
   * @param _fmea the new value of the field fmea.
   */
  public void setFmea(java.lang.Boolean _fmea)
  {
    fmea = _fmea;
  }

  private java.lang.Boolean swEntwicklung;

  /**
   * Gets the field swEntwicklung.
   * @return the value of the field swEntwicklung; may be null.
   */
  public java.lang.Boolean getSwEntwicklung()
  {
    return swEntwicklung;
  }

  /**
   * Sets the field swEntwicklung.
   * @param _swEntwicklung the new value of the field swEntwicklung.
   */
  public void setSwEntwicklung(java.lang.Boolean _swEntwicklung)
  {
    swEntwicklung = _swEntwicklung;
  }

  private java.lang.Boolean pflichtenheft;

  /**
   * Gets the field pflichtenheft.
   * @return the value of the field pflichtenheft; may be null.
   */
  public java.lang.Boolean getPflichtenheft()
  {
    return pflichtenheft;
  }

  /**
   * Sets the field pflichtenheft.
   * @param _pflichtenheft the new value of the field pflichtenheft.
   */
  public void setPflichtenheft(java.lang.Boolean _pflichtenheft)
  {
    pflichtenheft = _pflichtenheft;
  }

  private java.lang.Boolean atexProdukt;

  /**
   * Gets the field atexProdukt.
   * @return the value of the field atexProdukt; may be null.
   */
  public java.lang.Boolean getAtexProdukt()
  {
    return atexProdukt;
  }

  /**
   * Sets the field atexProdukt.
   * @param _atexProdukt the new value of the field atexProdukt.
   */
  public void setAtexProdukt(java.lang.Boolean _atexProdukt)
  {
    atexProdukt = _atexProdukt;
  }

  private java.lang.Boolean mechEntwicklung;

  /**
   * Gets the field mechEntwicklung.
   * @return the value of the field mechEntwicklung; may be null.
   */
  public java.lang.Boolean getMechEntwicklung()
  {
    return mechEntwicklung;
  }

  /**
   * Sets the field mechEntwicklung.
   * @param _mechEntwicklung the new value of the field mechEntwicklung.
   */
  public void setMechEntwicklung(java.lang.Boolean _mechEntwicklung)
  {
    mechEntwicklung = _mechEntwicklung;
  }

  private java.lang.Boolean konzept;

  /**
   * Gets the field konzept.
   * @return the value of the field konzept; may be null.
   */
  public java.lang.Boolean getKonzept()
  {
    return konzept;
  }

  /**
   * Sets the field konzept.
   * @param _konzept the new value of the field konzept.
   */
  public void setKonzept(java.lang.Boolean _konzept)
  {
    konzept = _konzept;
  }

  private java.lang.Boolean medizinprodukt;

  /**
   * Gets the field medizinprodukt.
   * @return the value of the field medizinprodukt; may be null.
   */
  public java.lang.Boolean getMedizinprodukt()
  {
    return medizinprodukt;
  }

  /**
   * Sets the field medizinprodukt.
   * @param _medizinprodukt the new value of the field medizinprodukt.
   */
  public void setMedizinprodukt(java.lang.Boolean _medizinprodukt)
  {
    medizinprodukt = _medizinprodukt;
  }

  private java.lang.Boolean elEntwicklung;

  /**
   * Gets the field elEntwicklung.
   * @return the value of the field elEntwicklung; may be null.
   */
  public java.lang.Boolean getElEntwicklung()
  {
    return elEntwicklung;
  }

  /**
   * Sets the field elEntwicklung.
   * @param _elEntwicklung the new value of the field elEntwicklung.
   */
  public void setElEntwicklung(java.lang.Boolean _elEntwicklung)
  {
    elEntwicklung = _elEntwicklung;
  }

}
