package de.hummel.pep.processes.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class ermittleGenehmigungsberechtigtenData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class ermittleGenehmigungsberechtigtenData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 8425612875053252466L;

  private java.lang.Double aufwand;

  /**
   * Gets the field aufwand.
   * @return the value of the field aufwand; may be null.
   */
  public java.lang.Double getAufwand()
  {
    return aufwand;
  }

  /**
   * Sets the field aufwand.
   * @param _aufwand the new value of the field aufwand.
   */
  public void setAufwand(java.lang.Double _aufwand)
  {
    aufwand = _aufwand;
  }

  private java.lang.String genehmigungsberechtigter;

  /**
   * Gets the field genehmigungsberechtigter.
   * @return the value of the field genehmigungsberechtigter; may be null.
   */
  public java.lang.String getGenehmigungsberechtigter()
  {
    return genehmigungsberechtigter;
  }

  /**
   * Sets the field genehmigungsberechtigter.
   * @param _genehmigungsberechtigter the new value of the field genehmigungsberechtigter.
   */
  public void setGenehmigungsberechtigter(java.lang.String _genehmigungsberechtigter)
  {
    genehmigungsberechtigter = _genehmigungsberechtigter;
  }

  private java.lang.String geschaeftsbereich;

  /**
   * Gets the field geschaeftsbereich.
   * @return the value of the field geschaeftsbereich; may be null.
   */
  public java.lang.String getGeschaeftsbereich()
  {
    return geschaeftsbereich;
  }

  /**
   * Sets the field geschaeftsbereich.
   * @param _geschaeftsbereich the new value of the field geschaeftsbereich.
   */
  public void setGeschaeftsbereich(java.lang.String _geschaeftsbereich)
  {
    geschaeftsbereich = _geschaeftsbereich;
  }

}
