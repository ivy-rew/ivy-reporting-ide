package de.hummel.x2000;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class artikel", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class artikel extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -4598244486642781267L;

  private transient java.lang.String artikelnummer;

  /**
   * Gets the field artikelnummer.
   * @return the value of the field artikelnummer; may be null.
   */
  public java.lang.String getArtikelnummer()
  {
    return artikelnummer;
  }

  /**
   * Sets the field artikelnummer.
   * @param _artikelnummer the new value of the field artikelnummer.
   */
  public void setArtikelnummer(java.lang.String _artikelnummer)
  {
    artikelnummer = _artikelnummer;
  }

  private transient java.lang.String bez1;

  /**
   * Gets the field bez1.
   * @return the value of the field bez1; may be null.
   */
  public java.lang.String getBez1()
  {
    return bez1;
  }

  /**
   * Sets the field bez1.
   * @param _bez1 the new value of the field bez1.
   */
  public void setBez1(java.lang.String _bez1)
  {
    bez1 = _bez1;
  }

  private transient java.lang.String bez2;

  /**
   * Gets the field bez2.
   * @return the value of the field bez2; may be null.
   */
  public java.lang.String getBez2()
  {
    return bez2;
  }

  /**
   * Sets the field bez2.
   * @param _bez2 the new value of the field bez2.
   */
  public void setBez2(java.lang.String _bez2)
  {
    bez2 = _bez2;
  }

  private transient java.lang.String bez3;

  /**
   * Gets the field bez3.
   * @return the value of the field bez3; may be null.
   */
  public java.lang.String getBez3()
  {
    return bez3;
  }

  /**
   * Sets the field bez3.
   * @param _bez3 the new value of the field bez3.
   */
  public void setBez3(java.lang.String _bez3)
  {
    bez3 = _bez3;
  }

}
