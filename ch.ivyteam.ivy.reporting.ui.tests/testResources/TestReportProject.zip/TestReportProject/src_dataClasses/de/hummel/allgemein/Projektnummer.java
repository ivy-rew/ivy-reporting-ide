package de.hummel.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Projektnummer", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Projektnummer extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -7765810833559765019L;

  private java.lang.String projektnummer;

  /**
   * Gets the field projektnummer.
   * @return the value of the field projektnummer; may be null.
   */
  public java.lang.String getProjektnummer()
  {
    return projektnummer;
  }

  /**
   * Sets the field projektnummer.
   * @param _projektnummer the new value of the field projektnummer.
   */
  public void setProjektnummer(java.lang.String _projektnummer)
  {
    projektnummer = _projektnummer;
  }

}
