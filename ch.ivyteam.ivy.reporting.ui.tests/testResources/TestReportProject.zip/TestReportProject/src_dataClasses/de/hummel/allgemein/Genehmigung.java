package de.hummel.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Genehmigung", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Genehmigung extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -3650889923988445695L;

  private java.lang.String referenz;

  /**
   * Gets the field referenz.
   * @return the value of the field referenz; may be null.
   */
  public java.lang.String getReferenz()
  {
    return referenz;
  }

  /**
   * Sets the field referenz.
   * @param _referenz the new value of the field referenz.
   */
  public void setReferenz(java.lang.String _referenz)
  {
    referenz = _referenz;
  }

  private java.lang.String bemerkung;

  /**
   * Gets the field bemerkung.
   * @return the value of the field bemerkung; may be null.
   */
  public java.lang.String getBemerkung()
  {
    return bemerkung;
  }

  /**
   * Sets the field bemerkung.
   * @param _bemerkung the new value of the field bemerkung.
   */
  public void setBemerkung(java.lang.String _bemerkung)
  {
    bemerkung = _bemerkung;
  }

  private java.lang.String user;

  /**
   * Gets the field user.
   * @return the value of the field user; may be null.
   */
  public java.lang.String getUser()
  {
    return user;
  }

  /**
   * Sets the field user.
   * @param _user the new value of the field user.
   */
  public void setUser(java.lang.String _user)
  {
    user = _user;
  }

  private ch.ivyteam.ivy.scripting.objects.Date datum;

  /**
   * Gets the field datum.
   * @return the value of the field datum; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getDatum()
  {
    return datum;
  }

  /**
   * Sets the field datum.
   * @param _datum the new value of the field datum.
   */
  public void setDatum(ch.ivyteam.ivy.scripting.objects.Date _datum)
  {
    datum = _datum;
  }

}
