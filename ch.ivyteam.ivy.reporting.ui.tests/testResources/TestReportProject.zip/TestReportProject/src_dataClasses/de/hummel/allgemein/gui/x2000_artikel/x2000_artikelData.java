package de.hummel.allgemein.gui.x2000_artikel;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class x2000_artikelData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class x2000_artikelData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -2066760454874193084L;

  private java.lang.String artikelnummer;

  /**
   * Gets the field artikelnummer.
   * @return the value of the field artikelnummer; may be null.
   */
  public java.lang.String getArtikelnummer()
  {
    return artikelnummer;
  }

  /**
   * Sets the field artikelnummer.
   * @param _artikelnummer the new value of the field artikelnummer.
   */
  public void setArtikelnummer(java.lang.String _artikelnummer)
  {
    artikelnummer = _artikelnummer;
  }

  private ch.ivyteam.ivy.scripting.objects.List<de.hummel.x2000.artikel> artikel;

  /**
   * Gets the field artikel.
   * @return the value of the field artikel; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<de.hummel.x2000.artikel> getArtikel()
  {
    return artikel;
  }

  /**
   * Sets the field artikel.
   * @param _artikel the new value of the field artikel.
   */
  public void setArtikel(ch.ivyteam.ivy.scripting.objects.List<de.hummel.x2000.artikel> _artikel)
  {
    artikel = _artikel;
  }

}
