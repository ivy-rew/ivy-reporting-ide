package de.hummel.allgemein.gui.Genehmigung;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class GenehmigungData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class GenehmigungData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -7719893721075395557L;

  private de.hummel.allgemein.Genehmigung genehmigungData;

  /**
   * Gets the field genehmigungData.
   * @return the value of the field genehmigungData; may be null.
   */
  public de.hummel.allgemein.Genehmigung getGenehmigungData()
  {
    return genehmigungData;
  }

  /**
   * Sets the field genehmigungData.
   * @param _genehmigungData the new value of the field genehmigungData.
   */
  public void setGenehmigungData(de.hummel.allgemein.Genehmigung _genehmigungData)
  {
    genehmigungData = _genehmigungData;
  }

  private java.lang.Boolean abbruch;

  /**
   * Gets the field abbruch.
   * @return the value of the field abbruch; may be null.
   */
  public java.lang.Boolean getAbbruch()
  {
    return abbruch;
  }

  /**
   * Sets the field abbruch.
   * @param _abbruch the new value of the field abbruch.
   */
  public void setAbbruch(java.lang.Boolean _abbruch)
  {
    abbruch = _abbruch;
  }

}
