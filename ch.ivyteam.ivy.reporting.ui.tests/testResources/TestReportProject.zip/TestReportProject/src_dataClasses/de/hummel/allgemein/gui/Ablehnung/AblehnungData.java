package de.hummel.allgemein.gui.Ablehnung;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class AblehnungData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class AblehnungData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 6992597599337112661L;

  private de.hummel.allgemein.Ablehnung ablehnung;

  /**
   * Gets the field ablehnung.
   * @return the value of the field ablehnung; may be null.
   */
  public de.hummel.allgemein.Ablehnung getAblehnung()
  {
    return ablehnung;
  }

  /**
   * Sets the field ablehnung.
   * @param _ablehnung the new value of the field ablehnung.
   */
  public void setAblehnung(de.hummel.allgemein.Ablehnung _ablehnung)
  {
    ablehnung = _ablehnung;
  }

  private java.lang.Boolean abbruch;

  /**
   * Gets the field abbruch.
   * @return the value of the field abbruch; may be null.
   */
  public java.lang.Boolean getAbbruch()
  {
    return abbruch;
  }

  /**
   * Sets the field abbruch.
   * @param _abbruch the new value of the field abbruch.
   */
  public void setAbbruch(java.lang.Boolean _abbruch)
  {
    abbruch = _abbruch;
  }

}
