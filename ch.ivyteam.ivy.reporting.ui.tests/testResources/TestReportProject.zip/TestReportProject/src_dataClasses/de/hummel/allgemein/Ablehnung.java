package de.hummel.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class Ablehnung", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class Ablehnung extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = 4536176788822738545L;

  private java.lang.String referenz;

  /**
   * Gets the field referenz.
   * @return the value of the field referenz; may be null.
   */
  public java.lang.String getReferenz()
  {
    return referenz;
  }

  /**
   * Sets the field referenz.
   * @param _referenz the new value of the field referenz.
   */
  public void setReferenz(java.lang.String _referenz)
  {
    referenz = _referenz;
  }

  private java.lang.String ablehnungsgrund;

  /**
   * Gets the field ablehnungsgrund.
   * @return the value of the field ablehnungsgrund; may be null.
   */
  public java.lang.String getAblehnungsgrund()
  {
    return ablehnungsgrund;
  }

  /**
   * Sets the field ablehnungsgrund.
   * @param _ablehnungsgrund the new value of the field ablehnungsgrund.
   */
  public void setAblehnungsgrund(java.lang.String _ablehnungsgrund)
  {
    ablehnungsgrund = _ablehnungsgrund;
  }

  private java.lang.String sonstiges;

  /**
   * Gets the field sonstiges.
   * @return the value of the field sonstiges; may be null.
   */
  public java.lang.String getSonstiges()
  {
    return sonstiges;
  }

  /**
   * Sets the field sonstiges.
   * @param _sonstiges the new value of the field sonstiges.
   */
  public void setSonstiges(java.lang.String _sonstiges)
  {
    sonstiges = _sonstiges;
  }

  private java.lang.String user;

  /**
   * Gets the field user.
   * @return the value of the field user; may be null.
   */
  public java.lang.String getUser()
  {
    return user;
  }

  /**
   * Sets the field user.
   * @param _user the new value of the field user.
   */
  public void setUser(java.lang.String _user)
  {
    user = _user;
  }

  private ch.ivyteam.ivy.scripting.objects.Date datum;

  /**
   * Gets the field datum.
   * @return the value of the field datum; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.Date getDatum()
  {
    return datum;
  }

  /**
   * Sets the field datum.
   * @param _datum the new value of the field datum.
   */
  public void setDatum(ch.ivyteam.ivy.scripting.objects.Date _datum)
  {
    datum = _datum;
  }

}
