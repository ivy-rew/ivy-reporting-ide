package de.hummel.allgemein;

/**
 */
@SuppressWarnings("all")
@javax.annotation.Generated(comments="This is the java file of the ivy data class artikelSelektionData", value={"ch.ivyteam.ivy.scripting.streamInOut.IvyScriptJavaClassBuilder"})
public class artikelSelektionData extends ch.ivyteam.ivy.scripting.objects.CompositeObject
{
  /** SerialVersionUID */
  private static final long serialVersionUID = -3704080158382758883L;

  private de.hummel.x2000.artikel artikel;

  /**
   * Gets the field artikel.
   * @return the value of the field artikel; may be null.
   */
  public de.hummel.x2000.artikel getArtikel()
  {
    return artikel;
  }

  /**
   * Sets the field artikel.
   * @param _artikel the new value of the field artikel.
   */
  public void setArtikel(de.hummel.x2000.artikel _artikel)
  {
    artikel = _artikel;
  }

  private ch.ivyteam.ivy.scripting.objects.List<de.hummel.x2000.artikel> artikelListe;

  /**
   * Gets the field artikelListe.
   * @return the value of the field artikelListe; may be null.
   */
  public ch.ivyteam.ivy.scripting.objects.List<de.hummel.x2000.artikel> getArtikelListe()
  {
    return artikelListe;
  }

  /**
   * Sets the field artikelListe.
   * @param _artikelListe the new value of the field artikelListe.
   */
  public void setArtikelListe(ch.ivyteam.ivy.scripting.objects.List<de.hummel.x2000.artikel> _artikelListe)
  {
    artikelListe = _artikelListe;
  }

}
